const axios = require('axios');

const cheerio = require('cheerio');

async function pinDownloader(url) {

    try {

        // Menggunakan downloader web pihak ketiga sebagai bypass

        const formData = new URLSearchParams();

        formData.append('url', url);

        const res = await axios.post('https://www.expertsphp.com/download.php', formData, {

            headers: {

                'Content-Type': 'application/x-www-form-urlencoded',

                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'

            }

        });

        const $ = cheerio.load(res.data);

        const videoUrl = $('video source').attr('src') || $('video').attr('src');

        const imgUrl = $('img.img-fluid').attr('src');

        const finalUrl = videoUrl || imgUrl;

        if (!finalUrl) {

            throw new Error("Gagal mengekstrak media. Pastikan link benar.");

        }

        return {

            url: finalUrl,

            type: finalUrl.includes('.mp4') ? 'video' : 'image'

        };

    } catch (e) {

        // Fallback ke API cadangan lain jika scraping gagal

        try {

            const alt = await axios.get(`https://api.botcahx.eu.org/api/download/pinterest?url=${url}&apikey=btch-btch`);

            if (alt.data.result) {

                return {

                    url: alt.data.result.url || alt.data.result[0].url,

                    type: (alt.data.result.url || "").includes('.mp4') ? 'video' : 'image'

                };

            }

        } catch (err) {

            throw new Error("Semua jalur download (Scraper & API) sedang diblokir Pinterest.");

        }

    }

}

module.exports = { pinDownloader };