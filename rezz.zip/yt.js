// File: yt.js (Perbaikan Menggunakan Async/Await dan chooseFormat)

// PENTING: Pastikan Anda telah menginstal 'ytdl-core' dan 'yt-search'
const yt = require("ytdl-core");
const yts = require("yt-search"); 

// Helper untuk mengambil metadata
const getMetadata = (info) => {
    const microformat = info.player_response.microformat.playerMicroformatRenderer;
    return {
        title: microformat.title.simpleText,
        thumb: microformat.thumbnail.thumbnails[0].url,
        channel: microformat.ownerChannelName,
        published: microformat.publishDate,
        views: parseInt(microformat.viewCount, 10),
    };
};


async function ytDonlodMp3(url) {
    try {
        const id = yt.getVideoID(url);
        const info = await yt.getInfo(`https://www.youtube.com/watch?v=${id}`);
        
        // Mencari format audio Opus/WebM kualitas tertinggi
        const format = yt.chooseFormat(info.formats, { 
            filter: 'audioonly',
            quality: 'highestaudio'
        });
        
        if (!format || !format.url) {
            throw new Error("Tidak dapat menemukan format audio.");
        }
        
        const metadata = getMetadata(info);

        return {
            ...metadata,
            url: format.url,
            size: format.contentLength ? parseInt(format.contentLength, 10) : 0,
        };
    } catch (error) {
        throw error;
    }
}


async function ytDonlodMp4(url) {
    try {
        const id = yt.getVideoID(url);
        const info = await yt.getInfo(`https://www.youtube.com/watch?v=${id}`);
        
        // Mencari format MP4 yang menggabungkan video dan audio, kualitas tertinggi
        const format = yt.chooseFormat(info.formats, { 
            filter: format => format.container === 'mp4' && format.hasVideo && format.hasAudio,
            quality: 'highest' 
        });

        if (!format || !format.url) {
            throw new Error("Tidak ditemukan format video MP4 yang mengandung video dan audio (Gabungan).");
        }
        
        const metadata = getMetadata(info);

        return {
            ...metadata,
            url: format.url,
            // Penting: Menambahkan size untuk pengecekan batas 50MB di handler
            size: format.contentLength ? parseInt(format.contentLength, 10) : 0,
        };
    } catch (error) {
        throw error;
    }
}


async function ytPlayMp3(query) {
    try {
        const search = await yts(query);
        const video = search.all.find(v => v.type === 'video');

        if (!video) {
            throw new Error("Tidak ada hasil pencarian video.");
        }
        
        const id = yt.getVideoID(video.url);
        const info = await yt.getInfo(`https://www.youtube.com/watch?v=${id}`);
        
        const format = yt.chooseFormat(info.formats, { 
            filter: 'audioonly',
            quality: 'highestaudio'
        });
        
        if (!format || !format.url) {
             throw new Error("Tidak dapat menemukan format audio Opus/Webm.");
        }
        
        const metadata = getMetadata(info);
        
        return {
            status: true,
            code: 200,
            creator: 'Creator Bot Akira',
            ...metadata,
            url: format.url,
            size: format.contentLength ? parseInt(format.contentLength, 10) : 0,
        };
    } catch (error) {
        throw error;
    }
}


async function ytPlayMp4(query) {
    try {
        const search = await yts(query);
        const video = search.all.find(v => v.type === 'video');

        if (!video) {
            throw new Error("Tidak ada hasil pencarian video.");
        }

        const id = yt.getVideoID(video.url);
        const info = await yt.getInfo(`https://www.youtube.com/watch?v=${id}`);
        
        const format = yt.chooseFormat(info.formats, { 
            filter: format => format.container === 'mp4' && format.hasVideo && format.hasAudio,
            quality: 'highest' 
        });

        if (!format || !format.url) {
             throw new Error("Tidak dapat menemukan format video MP4 yang kompatibel.");
        }
        
        const metadata = getMetadata(info);
        
        return {
            ...metadata,
            url: format.url,
            size: format.contentLength ? parseInt(format.contentLength, 10) : 0,
        };
    } catch (error) {
        throw error;
    }
}


async function ytSearch(query) {
    try {
        const data = await yts(query);
        return data.all;
    } catch (error) {
        throw error;
    }
}

module.exports = {
  ytDonlodMp3,
  ytDonlodMp4,
  ytPlayMp3,
  ytPlayMp4,
  ytSearch
};