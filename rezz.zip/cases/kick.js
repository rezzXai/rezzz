// cases/kick.js (FINAL FIX: OWNER MUTLAK, HTML & PENGECEKAN ADMIN LEBIH KUAT)

const settings = require('../setting');

let BOT_ID = null; 

// Helper function untuk memeriksa apakah pengguna adalah owner bot (Pengecekan Mutlak)
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_TELEGRAM_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};

// Helper function untuk mendapatkan status admin
const getMemberStatus = async (bot, chatId, userId) => {
    try {
        const member = await bot.getChatMember(chatId, userId);
        return member.status;
    } catch (e) {
        return 'member'; 
    }
};

module.exports = {
    keyword: '/kick',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        if (BOT_ID === null) {
            try {
                const me = await bot.getMe();
                BOT_ID = me.id.toString();
            } catch (e) {
                return bot.sendMessage(chatId, '❌ <b>Kesalahan:</b> Gagal menginisialisasi ID Bot. Coba restart.', { parse_mode: 'HTML' });
            }
        }
        
        if (msg.chat.type === 'private') {
            return bot.sendMessage(chatId, '❌ <b>Kesalahan:</b> Perintah /kick hanya dapat digunakan di dalam grup.', { parse_mode: 'HTML' });
        }
        if (!msg.reply_to_message) {
            return bot.sendMessage(chatId, '❌ <b>Kesalahan:</b> Silakan balas pesan member yang ingin Anda kick.', { parse_mode: 'HTML' });
        }
        
        const targetId = msg.reply_to_message.from.id;

        if (String(targetId) === String(userId)) {
            return bot.sendMessage(chatId, '🤔 Anda tidak bisa me-kick diri sendiri.', { parse_mode: 'HTML' });
        }
        if (String(targetId) === BOT_ID) {
             return bot.sendMessage(chatId, '🤖 Saya tidak bisa me-kick diri saya sendiri.', { parse_mode: 'HTML' });
        }

        const targetUser = msg.reply_to_message.from;
        
        const userStatus = await getMemberStatus(bot, chatId, userId);
        const isOwnerBot = isOwner(userId, settings); 
        const userIsAdmin = ['administrator', 'creator'].includes(userStatus);

        if (!isOwnerBot && !userIsAdmin) {
            return bot.sendMessage(chatId, '❌ <b>Akses Ditolak:</b> Anda harus menjadi Admin grup atau Owner Bot untuk menggunakan perintah ini.', { parse_mode: 'HTML' });
        }
        
        const targetStatus = await getMemberStatus(bot, chatId, targetId);
        const targetIsAdmin = ['administrator', 'creator'].includes(targetStatus);
        
        if (targetIsAdmin && !isOwnerBot) {
            return bot.sendMessage(chatId, '🛡️ <b>Peringatan:</b> Admin grup tidak bisa me-kick admin lain.', { parse_mode: 'HTML' });
        }
        
        try {
            await bot.banChatMember(chatId, targetId);
            await bot.unbanChatMember(chatId, targetId); 

            const targetUsername = targetUser.username ? `@${targetUser.username}` : targetUser.first_name;
            
            return bot.sendMessage(chatId, 
                `✅ <b>Kick Berhasil!</b>\n\n` +
                `Anggota ${targetUsername} telah dikeluarkan dari grup.`, 
                { parse_mode: 'HTML' }
            );

        } catch (error) {
            let errorMessage = 'Pastikan bot adalah Admin dan memiliki izin "Mengeluarkan Anggota" (Ban Users).';
            if (error.message.includes('not enough rights')) {
                errorMessage = 'Bot tidak memiliki izin "Mengeluarkan Anggota" (Ban Users).';
            }
            return bot.sendMessage(chatId, `❌ <b>Kick Gagal:</b> ${errorMessage}`, { parse_mode: 'HTML' });
        }
    }
};