const { getGithubData, updateGithubData } = require('../lib/github');

module.exports = {
    keyword: 'addlist',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        try {
            // 1. Ambil data dari GitHub
            const github = await getGithubData();
            if (!github) return bot.sendMessage(chatId, "❌ Gagal terhubung ke GitHub.");

            // 2. Cek apakah pengirim ada di daftar "owners" dalam file GitHub
            const isOwner = github.data.owners.includes(String(userId));
            if (!isOwner) {
                return bot.sendMessage(chatId, "<blockquote>❌ <b>AKSES DITOLAK</b>\nperintah ini hanya boleh di gunakan devv.</blockquote>", { parse_mode: 'HTML' });
            }

            // 3. Parsing Argumen
            const args = (msg.text || "").split(' ').slice(1).join(' ').split(',');
            if (args.length < 2) {
                return bot.sendMessage(chatId, "<blockquote>⚠️ <b>FORMAT SALAH</b>\nGunakan: /addlist [ID],[ROLE]</blockquote>", { parse_mode: 'HTML' });
            }

            const targetId = args[0].trim();
            const role = args[1].trim().toUpperCase();

            // 4. Proses Simpan
            if (!github.data.list_buyer) github.data.list_buyer = [];
            const userChat = await bot.getChat(targetId);
            
            github.data.list_buyer.push({
                id: targetId,
                name: userChat.first_name,
                username: userChat.username || 'No_Username',
                role: role
            });

            await updateGithubData(github.data, github.sha);
            bot.sendMessage(chatId, `<blockquote>✅ <b>BERHASIL DITAMBAHKAN</b>\n\n👤 Nama: <b>${userChat.first_name}</b>\n🎖 Role: <b>${role}</b>\n\nVerified by GitHub Owners.</blockquote>`, { parse_mode: 'HTML' });

        } catch (e) {
            bot.sendMessage(chatId, "❌ Terjadi kesalahan atau ID tidak ditemukan.");
        }
    }
};