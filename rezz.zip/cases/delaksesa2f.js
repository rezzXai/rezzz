// /cases/delaksesa2f.js - REVISI MENGGUNAKAN global.isOwner()

const { getAccessList, saveAccessList } = require('../lib/a2f_db');

module.exports = {
    keyword: 'delaksesa2f', 
    keywordAliases: ['/delaksesa2f'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id; // Ambil ID sebagai Number
        
        // --- 1. Cek Keamanan (Gunakan helper global.isOwner yang terdefinisi di rezz.js) ---
        // Pengecekan ini harus menggunakan fungsi global.isOwner() yang ada di rezz.js
        if (typeof global.isOwner !== 'function' || !global.isOwner(senderId)) {
             return bot.sendMessage(chatId, 
                "❌ **Akses Ditolak.** Perintah ini hanya untuk Owner bot.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 2. Ambil Argumen (ID Pengguna) ---
        const args = msg.text.slice(msg.entities[0].length).trim();
        const targetId = args.split(/\s+/)[0]; 
        
        if (!targetId || isNaN(targetId) || targetId.length < 5) {
            return bot.sendMessage(chatId, 
                "❌ **Format Salah.**\n\nGunakan: `/delaksesa2f [ID Telegram]`\nContoh: `/delaksesa2f 123456789`", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const idToDelete = String(targetId);
        let allowedIds = getAccessList();
        
        // --- 3. Cek Keberadaan ID ---
        const initialLength = allowedIds.length;
        // Filter: buat array baru tanpa ID yang akan dihapus
        allowedIds = allowedIds.filter(id => id !== idToDelete); 
        
        if (allowedIds.length === initialLength) {
            return bot.sendMessage(chatId, 
                `⚠️ **Gagal:** ID \`${idToDelete}\` tidak ditemukan dalam daftar akses.`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 4. Simpan Perubahan ---
        const success = saveAccessList(allowedIds);

        if (success) {
            await bot.sendMessage(chatId, 
                `✅ **Sukses!**\n\nAkses untuk ID \`${idToDelete}\` telah **dicabut** dari perintah /a2f.`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else {
             await bot.sendMessage(chatId, 
                "❌ **Error Penyimpanan.** Gagal menyimpan data ke file.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};