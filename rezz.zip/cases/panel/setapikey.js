const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'setapikey',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        if (!global.isOwner(msg.from.id)) return;

        const configPath = path.join(__dirname, '../../lib/panel.js');

        const dbPath = path.join(__dirname, '../../database/cooldown.json');

        // 1. Ambil data waktu terakhir dari file database

        let db = { lastKeyUpdate: 0, lastDomainUpdate: 0 };

        if (fs.existsSync(dbPath)) {

            try {

                db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

            } catch (e) {

                db = { lastKeyUpdate: 0, lastDomainUpdate: 0 };

            }

        }

        const now = Date.now();

        const cooldown = 5 * 60 * 1000; // 5 Menit

        // 2. Cek cooldown (Kita gunakan timer yang sama atau terpisah, di sini saya buat terpisah)

        if (now - db.lastKeyUpdate < cooldown) {

            const remainingMin = Math.ceil((cooldown - (now - db.lastKeyUpdate)) / 1000 / 60);

            return bot.sendMessage(chatId, `⏳ Cooldown.\ntunggu ${remainingMin} menit lagi sebelum tukar API Key baru demi keamanan Panel.`);

        }

        const newKey = msg.text.split(/\s+/)[1];

        if (!newKey) return bot.sendMessage(chatId, "⚠️ Contoh: `/setapikey ptla_xxxxx`", { parse_mode: 'Markdown' });

        try {

            // 3. Update file panel.js

            let content = fs.readFileSync(configPath, 'utf8');

            const regex = /API_KEY:\s*".*?"/;

            content = content.replace(regex, `API_KEY: "${newKey}"`);

            fs.writeFileSync(configPath, content);

            

            // 4. Simpan waktu sekarang ke database cooldown

            db.lastKeyUpdate = now;

            const dbDir = path.join(__dirname, '../../database');

            if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

            await bot.sendMessage(chatId, `✅ API Key Berhasil Diubah!\nBot akan restart otomatis dalam 5 detik agar konfigurasi baru aktif.`, { parse_mode: 'Markdown' });

            

            // Beri jeda agar pesan terkirim dan file selesai ditulis

            setTimeout(() => {

                process.exit(0); 

            }, 5000);

        } catch (e) {

            bot.sendMessage(chatId, "❌ Gagal mengubah API Key: " + e.message);

        }

    }

};