const axios = require('axios');
const fs = require('fs');
const path = require('path');
const configPanel = require('../../lib/panel');

module.exports = {
    keyword: '7gb',
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id.toString();
        const argsRaw = msg.text.split(/\s+/)[1];

        const premPath = path.join(__dirname, '../../database/premium.json');
        const premDb = fs.existsSync(premPath) ? JSON.parse(fs.readFileSync(premPath)) : [];
        if (!global.isOwner(msg.from.id) && !premDb.includes(senderId)) return bot.sendMessage(chatId, "✘ lu blm prem cungg.");

        const ramAmount = 7168;
        const ramDesc = "7GB";

        if (!argsRaw || argsRaw.split(',').length < 2) {
            return bot.sendMessage(chatId, `🚀 **ＴＵＴＯＲ ＣＲＥＡＴＥ ${ramDesc}**\n\nFormat: \`/7gb nama,idtele\`\nContoh: \`/7gb rezi,${senderId}\``, { parse_mode: 'Markdown' });
        }

        const [name, targetId] = argsRaw.split(',').map(v => v.trim());
        const cleanName = name.replace(/[^a-zA-Z0-9]/g, '').toLowerCase();

        bot.sendMessage(chatId, `⏳ Sedang memproses Panel ${ramDesc} untuk ID \`${targetId}\`...`, { parse_mode: 'Markdown' });

        try {
            const uniqueUser = cleanName + Math.floor(Math.random() * 899 + 100);
            const userPass = "User" + Math.floor(Math.random() * 8999 + 1000) + "!";

            // 1. Create User
            const userRes = await axios.post(`${configPanel.DOMAIN}/api/application/users`, {
                email: `${uniqueUser}@reziStore.com`,
                username: uniqueUser,
                first_name: name,
                last_name: "Premium",
                password: userPass
            }, { headers: { 'Authorization': `Bearer ${configPanel.API_KEY}`, 'Content-Type': 'application/json', 'Accept': 'application/json' } });

            const pterouserId = userRes.data.attributes.id;

            // 2. Create Server (Disesuaikan dengan Egg Skyzopedia)
            await axios.post(`${configPanel.DOMAIN}/api/application/servers`, {
                name: `${name}-${ramDesc}`,
                user: pterouserId,
                egg: Number(configPanel.EGG_ID),
                nest: Number(configPanel.NEST_ID),
                docker_image: "ghcr.io/parkervcp/yolks:nodejs_23",
                // Startup diambil dari JSON Egg yang kamu kirim
                startup: "if [[ -d .git ]] && [[ {{AUTO_UPDATE}} == \"1\" ]]; then git pull; fi; if [[ ! -z ${NODE_PACKAGES} ]]; then /usr/local/bin/npm install ${NODE_PACKAGES}; fi; if [[ ! -z ${UNNODE_PACKAGES} ]]; then /usr/local/bin/npm uninstall ${UNNODE_PACKAGES}; fi; if [ -f /home/container/package.json ]; then /usr/local/bin/npm install; fi;  if [[ ! -z ${CUSTOM_ENVIRONMENT_VARIABLES} ]]; then      vars=$(echo ${CUSTOM_ENVIRONMENT_VARIABLES} | tr \";\" \"\\n\");      for line in $vars;     do export $line;     done fi;  /usr/local/bin/${CMD_RUN};",
                limits: { memory: ramAmount, swap: 0, disk: 0, io: 500, cpu: 0 },
                // Environment disesuaikan dengan variabel di Egg kamu
                environment: { 
                    GIT_ADDRESS: "", 
                    BRANCH: "", 
                    USERNAME: "", 
                    ACCESS_TOKEN: "", 
                    CMD_RUN: "npm start" // Command default untuk start bot
                },
                feature_limits: { 
                    databases: 5, 
                    allocations: 5, 
                    backups: 5 
                },
                deploy: { locations: [Number(configPanel.LOCATION_ID)], dedicated_ip: false, port_range: [] }
            }, { headers: { 'Authorization': `Bearer ${configPanel.API_KEY}`, 'Content-Type': 'application/json', 'Accept': 'application/json' } });

            bot.sendMessage(chatId, `✅ **PANEL ${ramDesc} BERHASIL**`, { parse_mode: 'Markdown' });

            const msgPrivat = `🚀 **DETAIL AKUN PANEL ANDA (${ramDesc})**\n\n` +
                `👤 **Username:** \`${uniqueUser}\`\n` +
                `🔑 **Password:** \`${userPass}\`\n` +
                `📟 **RAM:** ${ramDesc}\n` +
                `🌐 **Login:** ${configPanel.DOMAIN}`;
            
            bot.sendMessage(targetId, msgPrivat, { parse_mode: 'Markdown' }).catch(() => {
                bot.sendMessage(chatId, `⚠️ Gagal kirim ke PC \`${targetId}\`. Pastikan dia sudah start bot!`);
            });
        } catch (error) {
            bot.sendMessage(chatId, `❌ **ERROR:** ${error.response?.data?.errors?.[0]?.detail || error.message}`);
        }
    }
};