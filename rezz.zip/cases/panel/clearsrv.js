const axios = require('axios');

const configPanel = require('../../lib/panel');

// Kita gunakan object sementara untuk menyimpan status konfirmasi

let confirmationStatus = {};

module.exports = {

    keyword: 'clearsrv',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        if (!global.isOwner(userId)) return;

        // Jika user mengetik '/clearsrv confirm' setelah pesan peringatan

        if (msg.text.includes('confirm')) {

            if (!confirmationStatus[userId]) {

                return bot.sendMessage(chatId, "⚠️ Silakan ketik `/clearsrv` terlebih dahulu.");

            }

            bot.sendMessage(chatId, "🚀 Menjalankan penghapusan massal... Mohon tunggu.");

            

            try {

                const res = await axios.get(`${configPanel.DOMAIN}/api/application/servers`, {

                    headers: { 'Authorization': `Bearer ${configPanel.API_KEY}`, 'Accept': 'application/json' }

                });

                const servers = res.data.data;

                let success = 0;

                let failed = 0;

                for (let server of servers) {

                    try {

                        await axios.delete(`${configPanel.DOMAIN}/api/application/servers/${server.attributes.id}`, {

                            headers: { 'Authorization': `Bearer ${configPanel.API_KEY}`, 'Accept': 'application/json' }

                        });

                        success++;

                    } catch (e) { failed++; }

                }

                delete confirmationStatus[userId]; // Reset status

                return bot.sendMessage(chatId, `✅ BERHASIL!\n\nTotal: ${servers.length}\nSukses: ${success}\nGagal: ${failed}`);

            } catch (err) {

                return bot.sendMessage(chatId, "❌ Terjadi kesalahan API.");

            }

        }

        // Pesan Peringatan Pertama

        confirmationStatus[userId] = true;

        const warning = `⚠️ WARN! !\n` +

                        `Perintah ini akan menghapus SELURUH SERVER yang ada di panel Pterodactyl kamu tanpa terkecuali.\n\n` +

                        `Jika kamu yakin, ketik:\n\`/clearsrv confirm\``;

        

        bot.sendMessage(chatId, warning, { parse_mode: 'Markdown' });

        // Batalkan status konfirmasi otomatis setelah 30 detik jika tidak ada respon

        setTimeout(() => {

            delete confirmationStatus[userId];

        }, 30000);

    }

};