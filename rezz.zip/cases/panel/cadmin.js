const axios = require('axios');
const configPanel = require('../../lib/panel');

module.exports = {
    keyword: 'cadmin',
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id;
        const text = msg.text ? msg.text.trim() : "";
        const args = text.split(/\s+/)[1];

        // 1. Pengecekan Owner
        if (!global.isOwner(senderId)) {
            return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");
        }

        // 2. Validasi Input (Format: username,idtele)
        if (!args || args.split(',').length < 2) {
            return bot.sendMessage(chatId, "⚠️ **FORMAT CREATE ADMIN**\n\n`/cadmin username,idtele`\nContoh: `/cadmin reza,12345678`", { parse_mode: 'Markdown' });
        }

        const [username, targetId] = args.split(',').map(v => v.trim());
        
        // Email Otomatis
        const autoEmail = `${username}@reziStore.com`;
        // Generate Password Acak
        const password = "Admin" + Math.floor(Math.random() * 8999 + 1000) + "!"; 

        if (isNaN(targetId)) return bot.sendMessage(chatId, "❌ ID Telegram harus berupa angka!");

        bot.sendMessage(chatId, `⏳ Sedang memproses akun Admin untuk ID \`${targetId}\`...`, { parse_mode: 'Markdown' });

        try {
            // 3. Request ke API Application Pterodactyl
            const res = await axios.post(`${configPanel.DOMAIN}/api/application/users`, {
                email: autoEmail,
                username: username,
                first_name: username,
                last_name: "Admin",
                root_admin: true, // Membuat akun jadi Administrator
                password: password
            }, {
                headers: {
                    'Authorization': `Bearer ${configPanel.API_KEY}`,
                    'Accept': 'application/json',
                    'Content-Type': 'application/json'
                }
            });

            // --- PENGIRIMAN PESAN ---

            // A. Notifikasi di Grup
            const msgGrup = `✅ **AKUN ADMINISTRATOR BERHASIL DIBUAT**\n\nDetail login telah dikirim ke chat pribadi ID \`${targetId}\`.`;
            bot.sendMessage(chatId, msgGrup, { parse_mode: 'Markdown' });

            // B. Data Akun ke ID Target (PC)
            const msgPrivat = `🛡️ **DETAIL YOUR ADP**\n\n` +
                `👤 **Username:** \`${res.data.attributes.username}\`\n` +
                `📧 **Email:** \`${autoEmail}\`\n` +
                `🔑 **Password:** \`${password}\`\n` +
                `🌐 **Login:** ${configPanel.DOMAIN}\n\n` +
                `⚠️ Malas yapping,intinya simpen dan jangan di buat aneh'`;
            
            await bot.sendMessage(targetId, msgPrivat, { parse_mode: 'Markdown' });

        } catch (error) {
            // Cek jika ID target belum start bot
            if (error.code === 'ETELEGRAM' || (error.message && error.message.includes('chat not found'))) {
                return bot.sendMessage(chatId, `❌ **GAGAL KIRIM PC:** Akun admin berhasil dibuat di panel, tapi detail gagal dikirim ke ID \`${targetId}\`. Pastikan dia sudah menekan **START** di bot ini!`);
            }

            const msgErr = error.response?.data?.errors?.[0]?.detail || error.message;
            bot.sendMessage(chatId, `❌ **GAGAL:** ${msgErr}`);
        }
    }
};