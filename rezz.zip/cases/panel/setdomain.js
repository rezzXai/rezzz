const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'setdomain',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        if (!global.isOwner(msg.from.id)) return;

        const configPath = path.join(__dirname, '../../lib/panel.js');

        const dbPath = path.join(__dirname, '../../database/cooldown.json');

        // 1. Ambil data waktu terakhir dari file database

        let db = { lastDomainUpdate: 0 };

        if (fs.existsSync(dbPath)) {

            db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

        }

        const now = Date.now();

        const cooldown = 5 * 60 * 1000; // 5 Menit

        // 2. Cek apakah sudah lewat 5 menit

        if (now - db.lastDomainUpdate < cooldown) {

            const remainingMin = Math.ceil((cooldown - (now - db.lastDomainUpdate)) / 1000 / 60);

            return bot.sendMessage(chatId, `🌟  Cooldown.\ntunggu ${remainingMin} menit lagi,ntr malah crash dongo.`);

        }

        let newDomain = msg.text.split(/\s+/)[1];

        if (!newDomain) return bot.sendMessage(chatId, "⚠️ Contoh: `/setdomain https://domain.com`", { parse_mode: 'Markdown' });

        try {

            // 3. Update file panel.js

            let content = fs.readFileSync(configPath, 'utf8');

            const regex = /DOMAIN:\s*".*?"/;

            content = content.replace(regex, `DOMAIN: "${newDomain}"`);

            fs.writeFileSync(configPath, content);

            

            // 4. Simpan waktu sekarang ke database cooldown

            db.lastDomainUpdate = now;

            if (!fs.existsSync(path.join(__dirname, '../../database'))) fs.mkdirSync(path.join(__dirname, '../../database'));

            fs.writeFileSync(dbPath, JSON.stringify(db));

            await bot.sendMessage(chatId, `✅ Domain Berhasil Diubah!\nBot akan restart dalam 5 detik...`, { parse_mode: 'Markdown' });

            

            setTimeout(() => { process.exit(0); }, 5000);

        } catch (e) {

            bot.sendMessage(chatId, "❌ Gagal: " + e.message);

        }

    }

};