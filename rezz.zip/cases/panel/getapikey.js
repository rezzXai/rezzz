const configPanel = require('../../lib/panel');

module.exports = {
    keyword: 'plta',
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // Proteksi: Hanya Owner yang boleh ambil API KEY
        if (!global.isOwner(userId)) {
            return bot.sendMessage(chatId, "✘ Fitur ini khusus Owner, bahaya kalau disebar cung.");
        }

        const response = `🔑 API KEY (PTLA)\n\n` +
                         `\`${configPanel.API_KEY}\`\n\n` +
                         `⚠️ Jangan berikan kunci ini kepada siapa pun!`;

        bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
    }
};