const configPanel = require('../../lib/panel');

module.exports = {
    keyword: 'domain',
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // Proteksi: Hanya Owner/Premium (Opsional, tapi sebaiknya Owner saja)
        if (!global.isOwner(userId)) {
            return bot.sendMessage(chatId, "✘ Khusus Owner.");
        }

        const response = `🌐 DOMAIN\n\n` +
                         `URL: ${configPanel.DOMAIN}\n\n` +
                         `Klik untuk login ke dashboard.`;

        bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
    }
};