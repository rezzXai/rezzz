const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'restart',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        if (!global.isOwner(msg.from.id)) return;

        const dbPath = path.join(__dirname, '../../database/cooldown.json');

        // 1. Ambil data waktu terakhir dari file database

        let db = { lastRestart: 0 };

        if (fs.existsSync(dbPath)) {

            try {

                db = JSON.parse(fs.readFileSync(dbPath, 'utf8'));

            } catch (e) {

                db = { lastRestart: 0 };

            }

        }

        const now = Date.now();

        const cooldown = 2 * 60 * 1000; // Jeda 2 Menit

        // 2. Cek apakah sudah lewat 2 menit sejak restart terakhir

        if (now - db.lastRestart < cooldown) {

            const remainingSec = Math.ceil((cooldown - (now - db.lastRestart)) / 1000);

            return bot.sendMessage(chatId, `⏳ 𝙅𝙀𝘿𝘼 𝙇𝙀𝙆\nBot baru saja direstart.\nMohon tunggu ${remainingSec} detik.`, { parse_mode: 'Markdown' });

        }

        try {

            // 3. Simpan waktu restart sekarang ke database

            db.lastRestart = now;

            const dbDir = path.join(__dirname, '../../database');

            if (!fs.existsSync(dbDir)) fs.mkdirSync(dbDir, { recursive: true });

            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

            await bot.sendMessage(chatId, `🔄 𝙍𝙚𝙨𝙩𝙖𝙧𝙩...\n ɢᴀ ʟᴀᴍᴀ ɪɴɪ ʟᴇᴋ`, { parse_mode: 'Markdown' });

            

            // 4. Proses mematikan bot

            setTimeout(() => {

                process.exit(0); 

            }, 3000);

        } catch (e) {

            bot.sendMessage(chatId, "❌ Gagal menjalankan perintah restart: " + e.message);

        }

    }

};