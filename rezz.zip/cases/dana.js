// cases/dana.js (FIXED: PERBAIKAN MARKDOWN AMAN)

module.exports = {
    keyword: '/dana',
    handler: (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        // --- GANTI DETAIL INI ---
        const detailText = `
**𝗗𝗘𝗧𝗔𝗜𝗟 🜲**
Number pay : \`0895322977616\`
Name pay   : REZI 
Name E-wallet/Bank : Dana

➖➖➖➖➖➖➖➖➖➖➖➖
**sᴇʀᴛᴀᴋᴀɴ ʙᴜᴋᴛɪ ᴛʀᴀɴsғᴇʀ**
        `;
        // PERHATIAN: Karakter * di Name pay dan Name E-wallet/Bank telah dihapus.
        // Format sekarang lebih aman dari error "can't parse entities".

        // Tombol Kembali
        const backKeyboard = {
            inline_keyboard: [
                [{ text: '◀️', callback_data: '/payment' }]
            ]
        };
        
        // Kirim Pesan BARU
        bot.sendMessage(chatId, detailText, {
            parse_mode: 'Markdown',
            reply_markup: backKeyboard
        })
        .catch(e => {
            console.error("Gagal mengirim detail DANA:", e.message);
        });
    }
};