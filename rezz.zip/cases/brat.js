// cases/brat.js (FINAL FIX: DIKEMBALIKAN KE 3 ARGUMEN)

const Jimp = require('jimp');

// --- Fungsi Helper untuk Membungkus Teks (Text Wrapping) ---
function wrapText(text, font, maxWidth) {
    const words = text.split(' ');
    let lines = [];
    let currentLine = '';

    for (let i = 0; i < words.length; i++) {
        const word = words[i];
        const testLine = currentLine === '' ? word : currentLine + ' ' + word;
        const testWidth = Jimp.measureText(font, testLine);

        if (testWidth <= maxWidth) {
            currentLine = testLine;
        } else {
            lines.push(currentLine);
            currentLine = word;
        }
    }
    lines.push(currentLine); // Tambahkan baris terakhir
    return lines;
}

// --- Fungsi Helper untuk Menghapus Emoji (opsional, jika font tidak support) ---
function removeEmojis(text) {
    // Regex ini menghapus sebagian besar emoji Unicode
    return text.replace(/[\u{1F600}-\u{1F64F}\u{1F300}-\u{1F5FF}\u{1F680}-\u{1F6FF}\u{1F1E0}-\u{1F1FF}\u{2600}-\u{26FF}\u{2700}-\u{27BF}\u{1F900}-\u{1F9FF}\u{1FA70}-\u{1FAFF}]/gu, '');
}


module.exports = {
    keyword: '/brat', 
    // PERBAIKAN KRITIS: Mengembalikan ke 3 argumen
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const text = msg.text.trim();
        const args = text.split(' ').slice(1).join(' '); 

        if (!args || args.length === 0) {
            const usageMessage = 
                `❌ **Format salah!**\n` +
                `Contoh penggunaan:\n` +
                `• **/brat** \`textbebas Anda di sini\``;
            return bot.sendMessage(chatId, usageMessage, { parse_mode: 'Markdown' });
        }

        try {
            await bot.sendMessage(chatId, `⏳ Sedang memproses teks "${args}" menjadi gambar...`);

            // --- Konfigurasi Gambar ---
            const IMAGE_BASE_WIDTH = 1200; 
            const IMAGE_BASE_HEIGHT = 800; 
            const PADDING = 80; 
            
            // --- Mendeteksi dan Memuat Font ---
            const font = await Jimp.loadFont(Jimp.FONT_SANS_64_BLACK); 

            // --- Hapus Emoji jika Font tidak Mendukung ---
            const processedText = removeEmojis(args); 

            // --- 1. Bungkus Teks ---
            const wrappedLines = wrapText(processedText, font, IMAGE_BASE_WIDTH - PADDING * 2);
            const finalContent = wrappedLines.join('\n'); 

            // 2. Hitung Ulang Ukuran Teks Setelah Dibungkus
            const textHeight = Jimp.measureTextHeight(font, finalContent, IMAGE_BASE_WIDTH - PADDING * 2);

            // 3. Tentukan Ukuran Gambar Akhir
            const finalWidth = IMAGE_BASE_WIDTH;
            const finalHeight = Math.max(IMAGE_BASE_HEIGHT, textHeight + PADDING * 2); 

            // 4. Buat Gambar
            const image = await new Jimp(finalWidth, finalHeight, 0xFFFFFFFF); // Background putih

            // 5. Tulis Teks yang Sudah Dibungkus
            image.print(
                font, 
                PADDING, 
                PADDING, 
                { 
                    text: finalContent, 
                    alignmentX: Jimp.HORIZONTAL_ALIGN_CENTER, 
                    alignmentY: Jimp.VERTICAL_ALIGN_MIDDLE
                }, 
                finalWidth - PADDING * 2, 
                finalHeight - PADDING * 2 
            );

            // 6. Dapatkan buffer gambar dan kirim
            const imageBuffer = await image.getBufferAsync(Jimp.MIME_PNG);

            await bot.sendPhoto(chatId, imageBuffer, {
                caption: `🖼️ Hasil /brat oleh @${msg.from.username || 'user'}`
            });

        } catch (error) {
            console.error('Error saat membuat gambar Brat:', error);
            bot.sendMessage(chatId, 
                `❌ **Gagal membuat gambar Brat.**\n` +
                `Error: ${error.message || 'Terjadi kesalahan saat memproses gambar.'}\n` +
                `Cek log Pterodactyl untuk detail.`
            );
        }
    }
};