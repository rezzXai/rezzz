const scraper = require('../scraper');

const Axios = require('axios');

const settings = require('../setting'); // Mengambil data dari settings.js

module.exports = {

    keyword: 'tiktok',

    keywordAliases: ['tt', 'tiktokmp3'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text.split(' ');

        // --- VALIDASI OWNER (Format Array: [ID1, ID2]) ---

        // Menggunakan .includes() untuk mengecek apakah ID pengirim ada di dalam kurung [ ]

        if (!settings.OWNER_ID.includes(userId)) {

            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.", { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        }

        // --- VALIDASI INPUT ---

        if (text.length < 2) return bot.sendMessage(chatId, "❌ Masukkan link TikTok!");

        const url = text[1];

        const loading = await bot.sendMessage(chatId, "⏳ Sedang mendownload video...");

        try {

            const result = await scraper.tiktokdownload(url);

            if (result && result.nowm) {

                // Download video ke Buffer agar aman dikirim ke Telegram

                const response = await Axios.get(result.nowm, { 

                    responseType: 'arraybuffer',

                    headers: { 'User-Agent': 'Mozilla/5.0' }

                });

                const videoBuffer = Buffer.from(response.data, 'binary');

                await bot.sendVideo(chatId, videoBuffer, { 

                    caption: `✅ **TikTok Download Success**\n\n📝 ${result.title || '-'}\n\n_Eksklusif Owner RezzXai_`,

                    parse_mode: 'Markdown'

                });

            } else {

                bot.sendMessage(chatId, "❌ Semua server scraper sedang gangguan.");

            }

        } catch (e) {

            console.error("Detail Error:", e.message);

            bot.sendMessage(chatId, "⚠️ Terjadi kesalahan saat memproses file.");

        } finally {

            if (loading) {

                bot.deleteMessage(chatId, loading.message_id).catch(() => {});

            }

        }

    }

};