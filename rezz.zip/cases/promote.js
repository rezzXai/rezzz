const { OWNER_ID } = require('../setting');

module.exports = {
    keyword: 'promote',
    keywordAliases: ['/promote', '/admin', '/promot'],
    
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        // 1. Cek apakah di grup
        if (msg.chat.type === 'private') {
            return bot.sendMessage(chatId, "❌ <pre>Perintah ini khusus di dalam grup!</pre>", { parse_mode: 'HTML' });
        }

        try {
            // 2. Cek Hak Akses (Owner Bot ATAU Admin Grup)
            const chatMember = await bot.getChatMember(chatId, userId);
            const isOwnerBot = Number(userId) === Number(OWNER_ID);
            const isGroupAdmin = chatMember.status === 'administrator' || chatMember.status === 'creator';
            
            if (!isOwnerBot && !isGroupAdmin) {
                return bot.sendMessage(chatId, 
`❌ <b>ACCESS DENIED</b>
<pre>
━━━━━━━━━━━━━━━━━━━━
INFO: Hanya Owner Bot atau
      Admin Grup yang bisa
      menggunakan ini.
━━━━━━━━━━━━━━━━━━━━
</pre>`, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
            }

            // 3. Menentukan Target (Reply atau Mention)
            let targetUserId;
            let targetName;

            if (msg.reply_to_message) {
                targetUserId = msg.reply_to_message.from.id;
                targetName = msg.reply_to_message.from.first_name;
            } else {
                // Mencari mention di teks
                const match = msg.text.match(/@(\w+)/);
                if (!match) {
                    return bot.sendMessage(chatId, "⚠️ <pre>Reply pesan target atau tag orangnya!</pre>", { parse_mode: 'HTML' });
                }
                // Jika pakai tag, bot perlu mengambil data user (lebih stabil pakai reply)
                return bot.sendMessage(chatId, "⚠️ <pre>Sangat disarankan menggunakan REPLY pesan target.</pre>", { parse_mode: 'HTML' });
            }

            // 4. Proses Promosi
            await bot.promoteChatMember(chatId, targetUserId, {
                can_change_info: true,
                can_delete_messages: true,
                can_invite_users: true,
                can_restrict_members: true,
                can_pin_messages: true,
                can_manage_chat: true,
                can_manage_video_chats: true
            });

            // 5. Kirim Konfirmasi Rapi
            const successMsg = 
`✅ <b>PROMOTE SUCCESS</b>
<pre>
━━━━━━━━━━━━━━━━━━━━
TARGET : ${targetName}
ID     : ${targetUserId}
STATUS : Administrator
━━━━━━━━━━━━━━━━━━━━
</pre>
<i>Berhasil mengangkat admin baru!</i>`;

            bot.sendMessage(chatId, successMsg, { 
                parse_mode: 'HTML', 
                reply_to_message_id: msg.message_id 
            });

        } catch (error) {
            console.error("Error promote:", error.message);
            bot.sendMessage(chatId, 
`❌ <b>FAILED TO PROMOTE</b>
<pre>
REASON:
- Bot bukan admin grup.
- Bot tidak punya hak
  'Add new admins'.
- Target sudah admin.
</pre>`, { parse_mode: 'HTML' });
        }
    }
};