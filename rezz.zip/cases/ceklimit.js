const fs = require('fs');
const path = require('path');

const dbLimitPath = path.join(__dirname, '../database/adddbtoken.json');

module.exports = {
    keyword: 'ceklimit',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text || "";

        // --- 1. PROTEKSI OWNER ---
        const ownerIds = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID.map(id => Number(id)) : [Number(settings.OWNER_ID)];
        if (!ownerIds.includes(Number(userId))) {
            return bot.sendMessage(chatId, "<blockquote>❌ <b>AKSES KHUSUS OWNER</b></blockquote>", { parse_mode: 'HTML' });
        }

        const args = text.split(' ');
        const targetId = args[1];

        if (!targetId || isNaN(targetId)) {
            return bot.sendMessage(chatId, "<blockquote>⚠️ <b>FORMAT SALAH</b>\nGunakan: <code>/ceklimit [ID_TELE]</code></blockquote>", { parse_mode: 'HTML' });
        }

        // --- 2. AMBIL DATA TELEGRAM TARGET (Nama, Username, Bio) ---
        let userInfo = { name: "Tidak Ditemukan", username: "-", bio: "-" };
        try {
            const chat = await bot.getChat(targetId);
            userInfo.name = (chat.first_name || "") + (chat.last_name ? " " + chat.last_name : "");
            userInfo.username = chat.username ? `@${chat.username}` : "-";
            userInfo.bio = chat.bio || "-";
        } catch (e) {
            // Jika bot belum pernah interaksi dengan user tersebut
        }

        // --- 3. BACA DATABASE (Disamakan dengan cekid.js) ---
        if (!fs.existsSync(dbLimitPath)) {
            return bot.sendMessage(chatId, "<blockquote>❌ Database limit tidak ditemukan.</blockquote>", { parse_mode: 'HTML' });
        }

        try {
            const dbLimit = JSON.parse(fs.readFileSync(dbLimitPath));
            const userData = dbLimit[targetId]; // Mengambil berdasarkan ID target

            if (!userData) {
                return bot.sendMessage(chatId, `<blockquote>🔍 <b>USER TIDAK DITEMUKAN</b>\nID <code>${targetId}</code> belum terdaftar di sistem limit.</blockquote>`, { parse_mode: 'HTML' });
            }

            // --- 4. LOGIKA PERHITUNGAN DATA ---
            const sisa = userData.limit || 0;
            const terpakai = userData.usedTotal || 0; 
            const total = sisa + terpakai;
            const freeTrial = userData.usedFree ? "✅ Sudah Diambil" : "❌ Belum Diambil";

            // --- 5. TAMPILAN BLOCKQUOTE SESUAI REQUEST ---
            const response = 
                `📌 <b>INFO LIMIT USER</b>\n` +
                `<blockquote>` +
                `👤 <b>Nama:</b> ${userInfo.name}\n` +
                `📛 <b>Username:</b> ${userInfo.username}\n` +
                `🆔 <b>ID Tele:</b> <code>${targetId}</code>\n` +
                `📝 <b>Bio:</b> <i>${userInfo.bio}</i>\n\n` +
                `📊 <b>Total Limit:</b> ${total}\n` +
                `📉 <b>Terpakai:</b> ${terpakai}\n` +
                `🎫 <b>Sisa Limit:</b> ${sisa}x\n` +
                `🎁 <b>Free Trial:</b> ${freeTrial}` +
                `</blockquote>\n\n` +
                `<i>Sistem Monitoring @ziistr</i>`;

            return bot.sendMessage(chatId, response, { parse_mode: 'HTML' });

        } catch (error) {
            return bot.sendMessage(chatId, "<blockquote>❌ Terjadi kesalahan saat memproses data.</blockquote>", { parse_mode: 'HTML' });
        }
    }
};