const fs = require('fs');
const path = require('path');
const Pengguna = require('../lib/pengguna'); 
const { findProduct, updateStock } = require('../lib/stokdb'); 
const { getVoucher, saveVoucher } = require('../lib/voucherdb');

if (!global.unconfirmedTransactions) global.unconfirmedTransactions = {};

const CHANNEL_ID = '-1002927416845';

const qrisStokHandler = {
    keyword: 'stok_detail', 
    keywordAliases: ['/qrisstok', 'stok_detail_panel', 'pay_saldo', 'process_qris', 'cancel_order'], 
    
    handler: async (bot, msg, settings) => {
        const callbackQuery = msg.callbackQuery;
        const chatId = callbackQuery ? callbackQuery.message.chat.id : msg.chat.id;
        const userId = callbackQuery ? callbackQuery.from.id : msg.from.id;
        const name = callbackQuery ? callbackQuery.from.first_name : msg.from.first_name;
        
        // Ambil username, jika tidak ada gunakan nama depan sebagai fallback
        const username = callbackQuery ? (callbackQuery.from.username || name) : (msg.from.username || name);
        const data = callbackQuery ? callbackQuery.data : (msg.text || "");
        
        let messageId = callbackQuery ? callbackQuery.message.message_id : msg.message_id;

        // --- 1. LOGIKA BATALKAN PESANAN ---
        if (data.startsWith('cancel_order_')) {
            const targetId = data.split('_')[2];
            
            if (userId != targetId) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Ini bukan pesanan Anda!", show_alert: true });
            }

            if (global.unconfirmedTransactions[userId]) {
                delete global.unconfirmedTransactions[userId];
            }

            await bot.deleteMessage(chatId, messageId).catch(() => {});
            return bot.sendMessage(chatId, "<blockquote>❌ <b>Pesanan telah dibatalkan.</b></blockquote>", { parse_mode: 'HTML' });
        }

        // --- 2. BAGIAN DETAIL PRODUK ---
        if (data.startsWith('stok_detail_')) {
            const parts = data.replace('stok_detail_', '').trim().split('_');
            const stockKey = parts[0].toUpperCase();
            const diskon = parseInt(parts[1]) || 0;
            const vName = parts[2] || "NONE";

            const product = findProduct(stockKey); 
            if (!product || (product.count || 0) <= 0) return bot.sendMessage(chatId, '⚠️ Stok habis.');

            const hargaFinal = product.price - (product.price * (diskon / 100));
            const menuText = `<blockquote>🛒 <b>KONFIRMASI PEMBELIAN</b>\n\n📦 Produk: <b>${product.nameDisplay}</b>\n💰 Harga: <b>Rp ${hargaFinal.toLocaleString('id-ID')}</b></blockquote>`;
            
            const keyboard = {
                inline_keyboard: [
                    [{ text: "💳 BAYAR PAKAI SALDO", callback_data: `pay_saldo_${stockKey}_${hargaFinal}_${vName}` }],
                    [{ text: "🖼️ BAYAR VIA QRIS", callback_data: `process_qris_${stockKey}_${diskon}_${vName}` }],
                    [{ text: "☜ Kembali", callback_data: "stok" }]
                ]
            };

            return bot.editMessageCaption(menuText, { 
                chat_id: chatId, 
                message_id: messageId, 
                parse_mode: 'HTML', 
                reply_markup: keyboard 
            }).catch(() => bot.sendMessage(chatId, menuText, { parse_mode: 'HTML', reply_markup: keyboard }));
        }

        // --- 3. BAGIAN BAYAR PAKAI SALDO ---
        if (data.startsWith('pay_saldo_')) {
            const parts = data.split('_');
            const stockKey = parts[2];
            const price = parseInt(parts[3]);
            const vName = parts[4];

            let user = Pengguna.ambil(userId);
            if (user.saldo < price) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: `❌ Saldo kurang!`, show_alert: true });
            }

            const product = findProduct(stockKey);
            if (!product || product.count <= 0) return bot.sendMessage(chatId, "⚠️ Stok habis.");

            Pengguna.tambahSaldo(userId, -price);
            updateStock(product.name, product.count - 1);

            if (vName !== 'NONE') {
                const vDb = getVoucher();
                if (vDb.list[vName]) { 
                    vDb.list[vName].used += 1; 
                    saveVoucher(vDb); 
                }
            }

            await bot.sendMessage(chatId, `<blockquote>✅ <b>PEMBAYARAN SALDO BERHASIL</b>\n\n📦 Produk: ${product.nameDisplay}\n💰 Harga: Rp ${price.toLocaleString()}</blockquote>`, { parse_mode: 'HTML' });
            
            const item = product.fileId || product.extraItems;
            if (product.fileType === 'document') { 
                await bot.sendDocument(chatId, item); 
            } else { 
                await bot.sendMessage(chatId, `<blockquote>📦 <b>DATA PRODUK:</b>\n<code>${item}</code></blockquote>`, { parse_mode: 'HTML' }); 
            }

            return bot.sendMessage(CHANNEL_ID, `<blockquote>🔔 <b>PRODUK TERJUAL (SALDO)</b>\n\n👤 Buyer: @${username}\n📦 Produk: ${product.nameDisplay}\n✅ Status: Sukses</blockquote>`, { parse_mode: 'HTML' });
        }

        // --- 4. BAGIAN PROCESS QRIS (FIX USERNAME UNDEFINED) ---
        if (data.startsWith('process_qris_')) {
            const parts = data.replace('process_qris_', '').split('_');
            const stockKey = parts[0];
            const diskon = parseInt(parts[1]) || 0;
            const voucherUsed = parts[2] !== 'NONE' ? parts[2] : null;

            const selectedProduct = findProduct(stockKey);
            const hargaFinal = selectedProduct.price - (selectedProduct.price * (diskon / 100));
            const totalBayar = hargaFinal + (Math.floor(Math.random() * 800) + 100);
            
            // Simpan data lengkap ke objek global agar bisa dipanggil di konfirmasi.js
            global.unconfirmedTransactions[userId] = {
                chatId: chatId,
                userId: userId,
                username: username, 
                stockKey: selectedProduct.name, 
                stockName: selectedProduct.nameDisplay,
                price: totalBayar,
                voucherUsed: voucherUsed,
                status: 'AWAITING_PROOF'
            };

            const qrisPath = path.join(__dirname, '..', 'qris.jpg');
            const messageText = `<blockquote>🛒 <b>DETAIL PESANAN</b>\n\n` +
                                `📦 Produk: <b>${selectedProduct.nameDisplay}</b>\n` +
                                `💰 <b>TOTAL BAYAR:</b> <b>Rp ${totalBayar.toLocaleString('id-ID')}</b>\n\n` +
                                `⚠️ <b>INSTRUKSI:</b>\n` +
                                `1. Transfer sesuai nominal di atas.\n` +
                                `2. Kirim <b>FOTO BUKTI TRANSFER</b> disini.\n` +
                                `3. Klik Batal jika tidak jadi membeli.</blockquote>`;

            const keyboard = {
                inline_keyboard: [
                    [{ text: "❌ BATALKAN PESANAN", callback_data: `cancel_order_${userId}` }]
                ]
            };

            if (callbackQuery) await bot.deleteMessage(chatId, messageId).catch(() => {});
            
            return bot.sendPhoto(chatId, qrisPath, { 
                caption: messageText, 
                parse_mode: 'HTML', 
                reply_markup: keyboard 
            });
        }
    }
};

module.exports = qrisStokHandler;