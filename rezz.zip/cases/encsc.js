const JavaScriptObfuscator = require('javascript-obfuscator');

const fs = require('fs');

const path = require('path');

const axios = require('axios');

const { OWNER_ID } = require('../setting');

const tempDir = path.join(__dirname, '../temp');

if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

module.exports = {

    keyword: 'encsc',

    keywordAliases: ['/encsc'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const replyMsg = msg.reply_to_message;

        // PROTEKSI OWNER

        if (Number(userId) !== Number(OWNER_ID)) {

            return bot.sendMessage(chatId, 

`❌ <b>ACCESS DENIED</b>

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS : REJECTED

INFO   : Fitur ini dikunci.

━━━━━━━━━━━━━━━━━━━━

</pre>`, { parse_mode: 'HTML' });

        }

        if (!replyMsg || !replyMsg.document) {

            return bot.sendMessage(chatId, " <pre>✘ Reply file .js yang mau dikunci!</pre>", { parse_mode: 'HTML' });

        }

        try {

            const fileLink = await bot.getFileLink(replyMsg.document.file_id);

            const response = await axios.get(fileLink);

            

            const obfuscated = JavaScriptObfuscator.obfuscate(response.data, {

                compact: true,

                controlFlowFlattening: true,

                numbersToExpressions: true,

                simplify: true

            }).getObfuscatedCode();

            const fileName = `enc_${replyMsg.document.file_name}`;

            const filePath = path.join(tempDir, fileName);

            fs.writeFileSync(filePath, obfuscated);

            await bot.sendDocument(chatId, filePath, {

                caption: `🔐 <b>𝙎𝘾𝙍𝙄𝙋𝙏 𝙇𝙊𝘾𝙆𝙀𝘿</b>\n<pre>\nSTATUS : SUCCESS\nRESULT : ${fileName}\n</pre>`,

                parse_mode: 'HTML'

            });

            if (fs.existsSync(filePath)) fs.unlinkSync(filePath);

        } catch (e) {

            bot.sendMessage(chatId, `<pre>ERROR: ${e.message}</pre>`, { parse_mode: 'HTML' });

        }

    }

};