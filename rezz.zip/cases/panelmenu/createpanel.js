const axios = require('axios');
const fs = require('fs');
const path = require('path');
const configPanel = require('../../lib/panel');

const sessionPath = path.join(__dirname, '../../database/session_order.json');
if (!fs.existsSync(sessionPath)) fs.writeFileSync(sessionPath, JSON.stringify({}));

const PATH_QRIS = path.join(__dirname, '../../qris.jpg');
const TIMEOUT_MS = 5 * 60 * 1000; // 5 Menit

const sizeMap = {
    '1': { ram: 1024, harga: 500, desc: '1GB' },
    '2': { ram: 2048, harga: 1000, desc: '2GB' },
    '3': { ram: 3072, harga: 1500, desc: '3GB' },
    '4': { ram: 4096, harga: 2000, desc: '4GB' },
    '5': { ram: 5120, harga: 2500, desc: '5GB' },
    '6': { ram: 6144, harga: 3000, desc: '6GB' },
    '7': { ram: 7168, harga: 3500, desc: '7GB' },
    '8': { ram: 8192, harga: 4000, desc: '8GB' },
    '9': { ram: 9216, harga: 4500, desc: '9GB' },
    '0': { ram: 0, harga: 6000, desc: 'Unlimited' },
    'adp': { ram: 0, harga: 10000, desc: 'Admin Panel (ADP)' }
};

module.exports = {
    keyword: 'buypanel',

    handler: async (bot, msg) => {
        const userId = msg.from.id;
        const chatId = msg.chat.id;
        const firstName = msg.from.first_name || "Buyer";

        // --- ANTI BENTROK: Hapus sesi di fitur lain ---
        const otherSessions = [
            path.join(__dirname, '../../database/session_subdo.json'),
            path.join(__dirname, '../../database/session_ress.json')
        ];
        otherSessions.forEach(p => {
            if (fs.existsSync(p)) {
                let s = JSON.parse(fs.readFileSync(p));
                if (s[userId]) { delete s[userId]; fs.writeFileSync(p, JSON.stringify(s)); }
            }
        });

        let sessions = JSON.parse(fs.readFileSync(sessionPath));
        sessions[userId] = { 
            step: 'WAITING_USERNAME', 
            firstName: firstName,
            createdAt: Date.now() // Tambah Timestamp
        }; 

        fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
        return bot.sendMessage(chatId, "🛒 <b>ORDER PANEL PTERODACTYL</b>\n\nSilakan ketik <b>Username</b> untuk panel kamu:\n\n⚠️ <i>Sesi berlaku 5 menit.</i>", { parse_mode: 'HTML' });
    },

    onMessage: async (bot, msg, settings) => {
        const userId = msg.from.id;
        const chatId = msg.chat.id;
        let sessions = JSON.parse(fs.readFileSync(sessionPath));
        const userSession = sessions[userId];

        if (!userSession) return false;

        // --- LOGIKA TIMEOUT ---
        if (Date.now() - userSession.createdAt > TIMEOUT_MS) {
            delete sessions[userId];
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
            await bot.sendMessage(chatId, "⏰ <b>Waktu Sesi Habis!</b>\nSilakan ketik ulang /buypanel.", { parse_mode: 'HTML' });
            return true;
        }

        // Step 1: Username Input
        if (userSession.step === 'WAITING_USERNAME' && msg.text) {
            userSession.username = msg.text.trim().replace(/\s+/g, '').toLowerCase();
            userSession.step = 'WAITING_RAM';
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            const keyboard = Object.keys(sizeMap).map(key => ([{
                text: `${sizeMap[key].desc} - Rp${sizeMap[key].harga}`,
                callback_data: `buyram_${key}_${userId}`
            }]));

            await bot.sendMessage(chatId, `✅ Username: <b>${userSession.username}</b>\n\nSekarang pilih <b>Kapasitas RAM / Akses</b>:`, {
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: keyboard }
            });
            return true;
        }

        // Step 2: Proof of Payment (Photo)
        if (userSession.step === 'WAITING_PAYMENT' && msg.photo) {
            const photoId = msg.photo[msg.photo.length - 1].file_id;
            userSession.step = 'PENDING_OWNER';
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            await bot.sendMessage(chatId, "⏳ <b>Bukti dikirim!</b> Mohon tunggu konfirmasi Owner.", { parse_mode: 'HTML' });

            const ownerId = configPanel.OWNER_ID || 8064092635;
            await bot.sendPhoto(ownerId, photoId, {
                caption: `🔔 <b>KONFIRMASI PEMBAYARAN PANEL</b>\n\n👤 User: ${userSession.firstName}\n📟 Paket: ${userSession.ramDesc}\n💰 Harga: Rp${userSession.harga}\n👤 User Panel: ${userSession.username}`,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [{ text: "✅ ACC", callback_data: `accpan_${userId}` }, { text: "❌ TOLAK", callback_data: `rejpan_${userId}` }]
                    ]
                }
            });
            return true;
        }
        return false;
    },

    callbackHandler: async (bot, callbackQuery, settings) => {
        const { data, from, message } = callbackQuery;
        const userId = from.id;
        const chatId = message.chat.id;
        let sessions = JSON.parse(fs.readFileSync(sessionPath));

        if (data.startsWith('buyram_')) {
            const [_, ramKey, targetId] = data.split('_');
            if (userId != targetId) return bot.answerCallbackQuery(callbackQuery.id, { text: "Bukan sesi Anda!", show_alert: true });

            const selected = sizeMap[ramKey];
            sessions[userId] = { ...sessions[userId], ram: selected.ram, harga: selected.harga, ramDesc: selected.desc, step: 'WAITING_PAYMENT' };
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            await bot.deleteMessage(chatId, message.message_id);

            const captionQris = `💳 <b>PEMBAYARAN ${selected.desc}</b>\n\n` +
                                `👤 Username: <code>${sessions[userId].username}</code>\n` +
                                `💰 Harga: <b>Rp${selected.harga.toLocaleString()}</b>\n\n` +
                                `Silakan transfer ke QRIS di atas, lalu kirim <b>FOTO BUKTI</b>.`;

            if (fs.existsSync(PATH_QRIS)) {
                await bot.sendPhoto(chatId, fs.createReadStream(PATH_QRIS), { caption: captionQris, parse_mode: 'HTML' });
            } else {
                await bot.sendMessage(chatId, captionQris + `\n\n⚠️ File QRIS tidak ditemukan.`);
            }
            return true;
        }

        if (data.startsWith('accpan_')) {
            const targetId = data.split('_')[1];
            const order = sessions[targetId];
            if (!order) return bot.answerCallbackQuery(callbackQuery.id, { text: "Sesi kedaluwarsa.", show_alert: true });

            await bot.editMessageCaption("⏳ <b>Sedang memproses...</b>", { chat_id: chatId, message_id: message.message_id, parse_mode: 'HTML' });

            try {
                const finalUsername = (order.username + targetId).substring(0, 15).toLowerCase();
                const finalPassword = "User" + Math.floor(Math.random() * 8999 + 1000) + "!";
                const isAdmin = order.ramDesc.includes('ADP');

                // 1. Create User
                const userRes = await axios.post(`${configPanel.DOMAIN}/api/application/users`, {
                    email: `${order.username}${targetId}@reziStore.com`,
                    username: finalUsername,
                    first_name: order.username, 
                    last_name: "Zii", 
                    password: finalPassword,
                    root_admin: isAdmin
                }, { headers: { 'Authorization': `Bearer ${configPanel.API_KEY}`, 'Content-Type': 'application/json', 'Accept': 'application/json' } });

                // 2. Create Server (Hanya jika bukan ADP)
                if (!isAdmin) {
                    await axios.post(`${configPanel.DOMAIN}/api/application/servers`, {
                        name: `${order.username}-${order.ramDesc}`,
                        user: userRes.data.attributes.id,
                        egg: configPanel.EGG_ID, nest: configPanel.NEST_ID, docker_image: "ghcr.io/parkervcp/yolks:nodejs_23",
                        startup: "npm start",
                        limits: { memory: order.ram, swap: 0, disk: 0, io: 500, cpu: 0 },
                        environment: { CMD_RUN: "npm start", AUTO_UPDATE: "0" },
                        feature_limits: { databases: 0, allocations: 1, backups: 0 },
                        deploy: { locations: [configPanel.LOCATION_ID], dedicated_ip: false, port_range: [] }
                    }, { headers: { 'Authorization': `Bearer ${configPanel.API_KEY}`, 'Content-Type': 'application/json', 'Accept': 'application/json' } });
                }

                const suksesTeks = `Hai ${order.firstName}!\n\n` +
                    `👑 <b>DETAIL DATA ${isAdmin ? 'ADP' : 'PANEL'} ANDA :</b>\n` +
                    `🌐 <b>Login :</b> <tg-spoiler>${configPanel.DOMAIN}</tg-spoiler>\n` +
                    `💣 <b>Username :</b> <code>${finalUsername}</code>\n` +
                    `🔑 <b>Password :</b> <code>${finalPassword}</code>\n\n` +
                    `©️ <b>ReziStore</b>`;

                await bot.sendPhoto(targetId, configPanel.IMAGE_URL, { caption: suksesTeks, parse_mode: 'HTML' });
                await bot.sendMessage(chatId, `✅ Sukses untuk <code>${finalUsername}</code>`);

                // Log Saluran
                const logChannel = `📢 <b>NOTIFIKASI PENJUALAN</b>\n\n👤 <b>Pembeli:</b> ${order.firstName}\n📦 <b>Produk:</b> Panel ${order.ramDesc}\n💰 <b>Harga:</b> Rp ${order.harga.toLocaleString()}\n✅ <b>Status:</b> Sukses\n\n©️ <b>ReziStore</b>`;
                bot.sendPhoto(configPanel.CHANNEL_ID, configPanel.IMAGE_URL, { caption: logChannel, parse_mode: 'HTML' }).catch(() => {});

                delete sessions[targetId];
                fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            } catch (err) {
                const msgErr = err.response?.data?.errors?.[0]?.detail || err.message;
                bot.sendMessage(chatId, "❌ <b>Gagal:</b> " + msgErr);
            }
            return true;
        }

        if (data.startsWith('rejpan_')) {
            const targetId = data.split('_')[1];
            await bot.sendMessage(targetId, "❌ Maaf, bukti pembayaran panel kamu ditolak.");
            delete sessions[targetId];
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
            await bot.deleteMessage(chatId, message.message_id);
            return true;
        }
        return false;
    }
};