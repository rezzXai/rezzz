const axios = require('axios');

const configPanel = require('../../lib/panel'); // Mengambil domain & API Key dari config panel

module.exports = {

    keyword: 'delsrv',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text ? msg.text.trim() : "";

        const args = text.split(/\s+/);

        const serverId = args[1]; // Mengambil ID Server dari argumen

        // 1. Pengecekan Owner

        if (!global.isOwner(userId)) {

            return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        }

        // 2. Validasi Input ID

        if (!serverId) {

            return bot.sendMessage(chatId, "⚠️ Format Salah!\n\nGunakan: `/delsrv [ID_SERVER]`\nContoh: `/delsrv 45`", { parse_mode: 'Markdown' });

        }

        bot.sendMessage(chatId, `⏳ Sedang menghapus server dengan ID: \`${serverId}\`...`, { parse_mode: 'Markdown' });

        try {

            // 3. Eksekusi Hapus Server (API Application Pterodactyl)

            // Menggunakan endpoint DELETE /api/application/servers/{id}

            await axios.delete(`${configPanel.DOMAIN}/api/application/servers/${serverId}`, {

                headers: {

                    'Authorization': `Bearer ${configPanel.API_KEY}`,

                    'Accept': 'application/json',

                    'Content-Type': 'application/json'

                }

            });

            // 4. Notifikasi Sukses

            const sukses = `✅ BERHASIL DIHAPUS\n\nServer dengan ID \`${serverId}\` telah dihapus permanen dari panel.`;

            bot.sendMessage(chatId, sukses, { parse_mode: 'Markdown' });

        } catch (error) {

            // Menangkap pesan error dari API Pterodactyl

            const msgErr = error.response?.data?.errors?.[0]?.detail || error.message;

            bot.sendMessage(chatId, `❌ GAGAL MENGHAPUS: 
${msgErr}`);

        }

    }

};