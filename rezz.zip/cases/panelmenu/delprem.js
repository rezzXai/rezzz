const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'delprem',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.split(/\s+/);

        const targetId = args[1];

        if (!global.isOwner(userId)) return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        if (!targetId) return bot.sendMessage(chatId, "⚠️ Format: `/delprem ID_TELEGRAM`", { parse_mode: 'Markdown' });

        const premPath = path.join(__dirname, '../../database/premium.json');

        

        // Cek jika database ada

        if (!fs.existsSync(premPath)) {

            return bot.sendMessage(chatId, "📭 Daftar Premium masih kosong.");

        }

        let premDb = JSON.parse(fs.readFileSync(premPath));

        if (premDb.includes(targetId)) {

            // Filter untuk menghapus ID target

            premDb = premDb.filter(id => id !== targetId);

            fs.writeFileSync(premPath, JSON.stringify(premDb, null, 2));

            bot.sendMessage(chatId, `✅ Berhasil menghapus \`${targetId}\` dari daftar Premium.`, { parse_mode: 'Markdown' });

        } else {

            bot.sendMessage(chatId, "⚠️ ID tersebut tidak ditemukan di daftar Premium.");

        }

    }

};