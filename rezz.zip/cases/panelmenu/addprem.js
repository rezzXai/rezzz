const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'addprem',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.split(/\s+/);

        const targetId = args[1];

        if (!global.isOwner(userId)) return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        if (!targetId) return bot.sendMessage(chatId, "⚠️ Format: `/addprem ID_TELEGRAM`", { parse_mode: 'Markdown' });

        const premPath = path.join(__dirname, '../../database/premium.json');

        if (!fs.existsSync(premPath)) fs.writeFileSync(premPath, JSON.stringify([]));

        

        let premDb = JSON.parse(fs.readFileSync(premPath));

        if (!premDb.includes(targetId)) {

            premDb.push(targetId);

            fs.writeFileSync(premPath, JSON.stringify(premDb, null, 2));

            bot.sendMessage(chatId, `✅ Berhasil menambah \`${targetId}\` ke daftar Premium.`, { parse_mode: 'Markdown' });

        } else {

            bot.sendMessage(chatId, "⚠️ User tersebut sudah Premium.");

        }

    }

}; 