const axios = require('axios');

const configPanel = require('../../lib/panel');

module.exports = {

    keyword: 'delusr',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text ? msg.text.trim() : "";

        const args = text.split(/\s+/);

        const targetUserId = args[1];

        if (!global.isOwner(userId)) return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        if (!targetUserId) {

            return bot.sendMessage(chatId, "⚠️ Format Salah!\n\nGunakan: `/delusr [USER_ID]`\nContoh: `/delusr 5`", { parse_mode: 'Markdown' });

        }

        bot.sendMessage(chatId, `⏳ Sedang menghapus User ID: \`${targetUserId}\`...`);

        try {

            await axios.delete(`${configPanel.DOMAIN}/api/application/users/${targetUserId}`, {

                headers: {

                    'Authorization': `Bearer ${configPanel.API_KEY}`,

                    'Accept': 'application/json'

                }

            });

            bot.sendMessage(chatId, `✅ BERHASIL!\nUser ID \`${targetUserId}\` dan seluruh servernya telah dihapus dari panel.`, { parse_mode: 'Markdown' });

        } catch (error) {

            const msgErr = error.response?.data?.errors?.[0]?.detail || error.message;

            bot.sendMessage(chatId, `❌ GAGAL MENGHAPUS: ${msgErr}`);

        }

    }

};