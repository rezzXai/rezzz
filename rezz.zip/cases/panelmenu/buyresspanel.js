const fs = require('fs');
const path = require('path');
const configPanel = require('../../lib/panel');

// Path database sesi khusus Reseller
const sessionPath = path.join(__dirname, '../../database/session_ress.json');
if (!fs.existsSync(sessionPath)) fs.writeFileSync(sessionPath, JSON.stringify({}));

// Path file QRIS
const PATH_QRIS = path.join(__dirname, '../../qris.jpg');

// Biaya pendaftaran Reseller
const HARGA_RESS = 5000; 
const TIMEOUT_MS = 5 * 60 * 1000; // 5 Menit

module.exports = {
    keyword: 'buyresspanel',

    handler: async (bot, msg) => {
        const userId = msg.from.id;
        const chatId = msg.chat.id;
        const firstName = msg.from.first_name || "Buyer";

        // --- ANTI BENTROK: Hapus sesi di fitur lain jika ada ---
        const otherSessions = [
            path.join(__dirname, '../../database/session_order.json'),
            path.join(__dirname, '../../database/session_subdo.json')
        ];
        otherSessions.forEach(p => {
            if (fs.existsSync(p)) {
                let s = JSON.parse(fs.readFileSync(p));
                if (s[userId]) { delete s[userId]; fs.writeFileSync(p, JSON.stringify(s)); }
            }
        });

        let sessions = JSON.parse(fs.readFileSync(sessionPath));
        
        // Simpan sesi dengan Timestamp
        sessions[userId] = { 
            step: 'WAITING_PAYMENT_RESS', 
            firstName: firstName,
            createdAt: Date.now() 
        }; 
        fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

        const captionMsg = `👑 <b>BUY RESSPANEL</b>\n\n` +
            `Keuntungan Menjadi Reseller:\n` +
            `✅ Harga Panel Jauh Lebih Murah\n` +
            `✅ Akses Grup Khusus Reseller\n` +
            `✅ Update Script & Egg Terbaru\n` +
            `✅ Support Langsung dari Owner\n` +
            `✅ Jual panel tanpa modal vps\n` +
            `✅ Server bagus dan aman\n` +
            `✅ Free sc pushkontak\n\n` +
            `💰 Biaya Pendaftaran: <b>Rp${HARGA_RESS.toLocaleString()}</b>\n\n` +
            `⚠️ <i>Sesi ini berlaku selama 5 menit.</i>\n` +
            `Silakan transfer ke QRIS di atas, lalu kirim <b>FOTO BUKTI PEMBAYARAN</b> ke sini.`;

        if (fs.existsSync(PATH_QRIS)) {
            return bot.sendPhoto(chatId, fs.createReadStream(PATH_QRIS), {
                caption: captionMsg,
                parse_mode: 'HTML'
            });
        } else {
            return bot.sendMessage(chatId, `⚠️ File <code>qris.jpg</code> tidak ditemukan.\n\n${captionMsg}`, { parse_mode: 'HTML' });
        }
    },

    onMessage: async (bot, msg, settings) => {
        const userId = msg.from.id;
        const chatId = msg.chat.id;
        let sessions = JSON.parse(fs.readFileSync(sessionPath));
        const userSession = sessions[userId];

        if (!userSession) return false;

        // --- LOGIKA TIMEOUT ---
        if (Date.now() - userSession.createdAt > TIMEOUT_MS) {
            delete sessions[userId];
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
            await bot.sendMessage(chatId, "⏰ <b>Waktu Sesi Habis!</b>\nSilakan ketik kembali /buyresspanel untuk memulai ulang.", { parse_mode: 'HTML' });
            return true;
        }

        // Menerima Foto Bukti Pembayaran
        if (userSession.step === 'WAITING_PAYMENT_RESS' && msg.photo) {
            const photoId = msg.photo[msg.photo.length - 1].file_id;
            userSession.step = 'PENDING_OWNER_RESS';
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            await bot.sendMessage(chatId, "⏳ <b>Bukti pembayaran telah dikirim!</b>\nMohon tunggu konfirmasi dari Owner.", { parse_mode: 'HTML' });

            const ownerId = configPanel.OWNER_ID || 8064092635;
            await bot.sendPhoto(ownerId, photoId, {
                caption: `🔔 <b>KONFIRMASI RESELLER BARU</b>\n\n👤 Pembeli: ${userSession.firstName}\n🆔 ID: <code>${userId}</code>\n💰 Produk: Reseller Panel Access`,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: "✅ ACC & KIRIM LINK", callback_data: `acc_ress_${userId}` },
                            { text: "❌ TOLAK", callback_data: `rej_ress_${userId}` }
                        ]
                    ]
                }
            });
            return true;
        }
        return false;
    },

    callbackHandler: async (bot, callbackQuery, settings) => {
        const { data, message } = callbackQuery;
        const chatId = message.chat.id;
        let sessions = JSON.parse(fs.readFileSync(sessionPath));

        if (data.startsWith('acc_ress_')) {
            const targetId = data.split('_')[2];
            const order = sessions[targetId];

            if (!order) return bot.answerCallbackQuery(callbackQuery.id, { text: "Sesi expired atau tidak ditemukan.", show_alert: true });

            await bot.editMessageCaption("⏳ <b>Sedang membuat link grup khusus...</b>", { chat_id: chatId, message_id: message.message_id, parse_mode: 'HTML' });

            try {
                // Link Invite expire dalam 5 menit, limit 1 orang
                const expireTimestamp = Math.floor(Date.now() / 1000) + 300; 
                
                const inviteLink = await bot.createChatInviteLink(configPanel.GROUP_RESS_ID, {
                    member_limit: 1,
                    expire_date: expireTimestamp,
                    name: `Reseller ${order.firstName}`
                });

                const suksesTeks = `Selamat ${order.firstName}!\n\n` +
                    `✅ <b>PEMBAYARAN RESELLER DITERIMA</b>\n\n` +
                    `Silakan klik link di bawah ini untuk bergabung ke grup khusus reseller kami:\n` +
                    `🔗 ${inviteLink.invite_link}\n\n` +
                    `⚠️ <b>PERINGATAN:</b>\n` +
                    `- Link ini hanya bisa digunakan 1x\n` +
                    `- Link akan hangus dalam 5 Menit\n` +
                    `- Segera bergabung sebelum link expired!\n\n` +
                    `©️ <b>ReziStore</b>`;

                await bot.sendPhoto(targetId, configPanel.IMAGE_RESS || configPanel.IMAGE_URL, { 
                    caption: suksesTeks, 
                    parse_mode: 'HTML' 
                });
                
                await bot.sendMessage(chatId, `✅ Sukses mengirim link grup ke ${order.firstName}`, { parse_mode: 'HTML' });

                // Log Saluran
                const logChannel = `👑 <b>RESSPANEL BARU BERGABUNG</b>\n\n` +
                    `👤 <b>Nama:</b> ${order.firstName}\n` +
                    `🆔 <b>User ID:</b> <code>${targetId}</code>\n` +
                    `✅ <b>Status:</b> Member Aktif\n\n` +
                    `©️ <b>ReziStore</b>`;

                bot.sendPhoto(configPanel.CHANNEL_ID, configPanel.IMAGE_RESS || configPanel.IMAGE_URL, {
                    caption: logChannel,
                    parse_mode: 'HTML'
                }).catch(() => {});

                delete sessions[targetId];
                fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            } catch (err) {
                console.error("Error Create Invite Link:", err);
                bot.sendMessage(chatId, "❌ <b>Gagal membuat link invite:</b> " + err.message, { parse_mode: 'HTML' });
            }
            return true;
        }

        if (data.startsWith('rej_ress_')) {
            const targetId = data.split('_')[2];
            await bot.sendMessage(targetId, "❌ Maaf, bukti pembayaran pendaftaran Reseller kamu ditolak.");
            
            delete sessions[targetId];
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
            
            await bot.deleteMessage(chatId, message.message_id);
            return true;
        }
        return false;
    }
};