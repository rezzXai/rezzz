const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'listprem',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        if (!global.isOwner(userId)) return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        const premPath = path.join(__dirname, '../../database/premium.json');

        

        if (!fs.existsSync(premPath)) {

            return bot.sendMessage(chatId, "📭 Daftar Premium masih kosong.");

        }

        let premDb = JSON.parse(fs.readFileSync(premPath));

        if (premDb.length === 0) {

            return bot.sendMessage(chatId, "📭 Tidak ada user di dalam daftar Premium.");

        }

        let response = "📋 DAFTAR USER PREMIUM\n\n";

        premDb.forEach((id, index) => {

            response += `${index + 1}. ID: \`${id}\`\n`;

        });

        response += `\nTotal: ${premDb.length} User`;

        bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });

    }

};