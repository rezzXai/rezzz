const axios = require('axios');

const configPanel = require('../../lib/panel');

module.exports = {

    keyword: 'listusr',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        if (!global.isOwner(userId)) return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        bot.sendMessage(chatId, "⏳ Mengambil daftar pengguna dari panel...");

        try {

            const res = await axios.get(`${configPanel.DOMAIN}/api/application/users`, {

                headers: {

                    'Authorization': `Bearer ${configPanel.API_KEY}`,

                    'Accept': 'application/json'

                }

            });

            const users = res.data.data;

            if (users.length === 0) {

                return bot.sendMessage(chatId, "📭 Tidak ada pengguna yang ditemukan.");

            }

            let response = "👥 DAFTAR USER PANEL\n\n";

            users.forEach((usr, index) => {

                const attr = usr.attributes;

                const role = attr.root_admin ? "🔴 Admin" : "🔵 Customer";

                

                response += `${index + 1}. 🆔 ID: \`${attr.id}\`\n`;

                response += `   👤 Username: \`${attr.username}\`\n`;

                response += `   📧 Email: \`${attr.email}\`\n`;

                response += `   🛡️ Role: ${role}\n`;

                response += `   ━━━━━━━━━━━━━━━━\n`;

            });

            response += `\nTotal: ${users.length} User Terdaftar`;

            bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });

        } catch (error) {

            const msgErr = error.response?.data?.errors?.[0]?.detail || error.message;

            bot.sendMessage(chatId, `❌ **GAGAL:** ${msgErr}`);

        }

    }

};