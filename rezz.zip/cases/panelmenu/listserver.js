const axios = require('axios');

const configPanel = require('../../lib/panel'); // Mengambil domain & API Key dari config panel

module.exports = {

    keyword: 'listsrv',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // Pengecekan Owner (Hanya owner yang bisa melihat semua server di panel)

        if (!global.isOwner(userId)) return bot.sendMessage(chatId, "✘ Owner doang yang bisa pakai cungg");

        bot.sendMessage(chatId, "⏳ Mengambil daftar server dari panel...");

        try {

            // Mengambil data server melalui API Application Pterodactyl

            const res = await axios.get(`${configPanel.DOMAIN}/api/application/servers`, {

                headers: {

                    'Authorization': `Bearer ${configPanel.API_KEY}`,

                    'Accept': 'application/json'

                }

            });

            const servers = res.data.data;

            if (servers.length === 0) {

                return bot.sendMessage(chatId, "📭 Tidak ada server yang ditemukan di panel.");

            }

            let response = "🖥 DAFTAR SERVER PTERODACTYL\n\n";

            servers.forEach((srv, index) => {

                const attr = srv.attributes;

                const ram = attr.limits.memory === 0 ? "Unlimited" : `${attr.limits.memory}MB`; //

                

                response += `${index + 1}. 🆔 ID: \`${attr.id}\`\n`;

                response += `   📛 Nama: \`${attr.name}\`\n`;

                response += `   📟 RAM: ${ram}\n`;

                response += `   👤 User ID: ${attr.user}\n`;

                response += `   ━━━━━━━━━━━━━━━━\n`;

            });

            response += `\nTotal: ${servers.length} Server Aktif`;

            bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });

        } catch (error) {

            const msgErr = error.response?.data?.errors?.[0]?.detail || error.message;

            bot.sendMessage(chatId, `❌ GAGAL MENGAMBIL DATA: ${msgErr}`);

        }

    }

};