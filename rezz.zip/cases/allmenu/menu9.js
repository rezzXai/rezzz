// cases/menu9.js - Kebutuhan Hosting (Gaya Blockquote Premium)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

const DEVV_TELEGRAM_LINK = 'https://t.me/ziistr'; 
const MENU_IMAGE_PATH = path.join(__dirname, '..', '..', 'menu.jpg'); 

function getMenuContent() {
     const responseCaption = 
        `<b>📜 𝗔𝗟𝗟 𝗞𝗘𝗕𝗨𝗧𝗨𝗛𝗔𝗡 𝗛𝗢𝗦𝗧𝗜𝗡𝗚</b>\n` + 
        `➖➖➖➖➖➖➖➖➖➖➖➖\n\n` +
        
        `<blockquote><b>[ ☁️ 𝗛𝗢𝗦𝗧𝗜𝗡𝗚 𝗦𝗘𝗥𝗩𝗜𝗖𝗘𝗦 ]</b>\n` +
        `• ᴘʟᴀᴛғᴏʀᴍ: ʜɪɢʜ-sᴘᴇᴇᴅ ᴄʟᴏᴜᴅ\n` +
        `• ᴜᴘᴛɪᴍᴇ: 99.9% ɢᴜᴀʀᴀɴᴛᴇᴇ\n` +
        `• sᴜᴘᴘᴏʀᴛ: 24/7 ᴀᴜᴛᴏ ᴏʀᴅᴇʀ\n\n` +
        `<b>[ ⚡ 𝗪𝗛𝗬 𝗨𝗦? ]</b>\n` +
        `ᴅɪʙᴀɴɢᴜɴ ᴅᴇɴɢᴀɴ ᴘʀեսɪsɪ ᴛɪɴɢɢɪ\n` +
        `ᴜɴᴛᴜᴋ ᴋᴇᴄᴇᴘᴀᴛᴀɴ & ᴋᴇᴀᴍᴀɴᴀɴ\n` +
        `ᴛʀᴀɴsᴀᴋsɪ ᴀɴᴅᴀ ᴀᴅᴀʟᴀʜ ᴘʀɪᴏʀɪᴛᴀs.</blockquote>\n\n` +
        
        `➖➖➖➖➖➖➖➖➖➖➖➖\n` +
        `<b><a href="${DEVV_TELEGRAM_LINK}">[ 𝘼𝙏𝙈𝙄𝙉 𝙏𝘼𝙈𝙁𝘼𝙉 𖠡 ]</a></b>`;

    const inlineKeyboard = {
        inline_keyboard: [
            [
                { text: '↯ ʙᴜʏ ᴠᴘs', callback_data: '/menu5_callback' },
                { text: '↯ ᴘʀɪᴄᴇ sᴜʙᴅᴏ', callback_data: '/menu4_callback' }
            ],        
            [
                { text: '↯ ɪɴsᴛᴀʟ ᴘᴀɴᴇʟ', callback_data: '/menu3_callback' }, 
                { text: '↯ ᴘʀɪᴄᴇ ᴘɴʟ', callback_data: '/menu7_callback' }
            ],         
            [
                { text: '↺ ᗷᗩᑕK', callback_data: '/menu1_callback' }
            ]
        ]
    };
    
    return { responseCaption, inlineKeyboard };
}

module.exports = {
    keyword: '/menu9',
    keywordAliases: ['/menu9', '/menu9_callback', 'menu9'], 
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id; 
        const imageExists = fs.existsSync(MENU_IMAGE_PATH);
        const { responseCaption, inlineKeyboard } = getMenuContent();
        
        const sendOptions = { 
            caption: responseCaption, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard
        };

        if (isCallback) {
             try {
                 await bot.editMessageCaption(responseCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                 });
                 await bot.answerCallbackQuery(msg.callbackQuery.id).catch(() => {});
             } catch(e) { 
                 if (imageExists) {
                     await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions);
                 } else {
                     await bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                 }
             }
        } else {
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_IMAGE_PATH, { ...sendOptions, reply_to_message_id: msg.message_id }).catch(() => {
                    bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                 bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};