// cases/fitur.js (REVISI FINAL: Merapikan Teks dan Mengubah Format)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

const DEVV_TELEGRAM_LINK = 'https://t.me/ziistr'; 
const MENU_IMAGE_PATH = path.join(__dirname, '..', 'menu.jpg'); 

// --- Fungsi untuk menghasilkan konten pesan (agar bisa dipakai berulang) ---
function getMenuContent() {
     const responseCaption = 
        `<b>𝙎𝙐𝘽𝘿𝙊 𝙈𝙀𝙉𝙐 (𝘿𝙊𝙈𝘼𝙄𝙉) </b>` + 
        `\n➖➖➖➖➖➖➖➖➖➖➖➖\n\n` +
        
        `<pre>` +
        ` •/delsubdo\n` +  
        `  ➥owner only\n` + 
        ` •/listsubdo\n` +  
        `  ➥owner only\n` + 
        `\n` +  
        `ＰＲＩＣＥ?２.５Ｋ \n` +          
        
          `\n` +   

        `𝘙𝘜𝘓𝘌𝘚\n` +    
        `➮no ddos ip\n` +    
        `➮ip wajib on di vps\n` +
        `➮buat node tinggal tambah node di depan username\n` +  
        `➮Harga buy sudah yang terbaik✰\n` +  
        `</pre>` +
        
        `\n➖➖➖➖➖➖➖➖➖➖➖➖\n` +
        `<b><a href="${DEVV_TELEGRAM_LINK}">𝘼𝙏𝙈𝙄𝙉</a></b> `; // Menggunakan <a> tag untuk membuat teks tampak biru (link)

    
    // Inline Keyboard Disesuaikan untuk mencakup Group Menu dan Back
    const inlineKeyboard = {
        inline_keyboard: [
               [
                { text: '↯ ʙᴜʏ sᴜʙᴅᴏ', callback_data: 'buysubdo' }
            ],        
              [
                { text: '↺ ᗷᗩᑕK', callback_data: '/menu9_callback' }
            ]
        ]
    };
    
    return { responseCaption, inlineKeyboard };
}


module.exports = {
    keyword: '/menu4',
    keywordAliases: ['/menu4', '/menu4_callback'], 
    
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id; 

        const imageExists = fs.existsSync(MENU_IMAGE_PATH);
        const { responseCaption, inlineKeyboard } = getMenuContent();
        
        const sendOptions = { 
            caption: responseCaption, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard,
            reply_to_message_id: isCallback ? undefined : msg.message_id
        };

        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
             // Aksi: EDIT CAPTION pesan yang ada
             try {
                 await bot.editMessageCaption(responseCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                 });
                 // Tambahkan ini agar callback tidak terus berputar
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             } catch(e) { 
                 console.warn(`Gagal mengedit pesan /fitur: ${e.message}. Mencoba mengirim baru.`);
                 // Fallback: Kirim pesan baru
                 if (imageExists) {
                     await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions);
                 } else {
                     await bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                 }
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             }
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /fitur diketik)
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions)
                .catch(error => {
                    console.error(`Gagal mengirim foto menu: ${error.message}`);
                    bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                 bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};