// cases/fitur.js (REVISI FINAL: Merapikan Teks dan Mengubah Format)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

const DEVV_TELEGRAM_LINK = 'https://t.me/ziistr'; 
const MENU_IMAGE_PATH = path.join(__dirname, '..', 'menu.jpg'); 

// --- Fungsi untuk menghasilkan konten pesan (agar bisa dipakai berulang) ---
function getMenuContent() {
     const responseCaption = 
        `<b>𝙄𝙉𝙎𝙏𝘼𝙇𝘼𝙎𝙄 𝙋𝘼𝙉𝙀𝙇 𝙈𝙀𝙉𝙐</b>` + 
        `\n➖➖➖➖➖➖➖➖➖➖➖➖\n\n` +
        
        `<pre>` +
        ` •/instalpanel\n` +
        `  ➥versi os 22.04/24.04\n` +       
        ` •/instalnode\n` +  
        `  ➥include dengan instal wings\n` + 
        ` •/uninstallpanel\n` +  
        `  ➥hapus panel dan semua database\n` + 
        ` •/vpspass\n` +  
        `  ➥ubah password vps\n` +   
        ` •/getegg\n` +     
        `  ➥ambil egg panel,node js hingga 24\n` +           
        
          `\n` +   
        `✎𝙄𝙉𝙎𝙏𝘼𝙇 𝙋𝘼𝙉𝙀𝙇 = 3.000\n` + 
        `✎𝙄𝙉𝙎𝙏𝘼𝙇 𝙉𝙊𝘿𝙀+𝙒𝙄𝙉𝙂𝙎 = 3.000\n` +   
        `✎𝙐𝙉𝙄𝙉𝙎𝙏𝘼𝙇𝙇 𝙋𝘼𝙉𝙀𝙇 = 2.000\n` +      
        `✎𝘾𝙃𝘼𝙉𝙂𝙀 𝙋𝘼𝙎𝙒𝙊𝙍𝘿 𝙑𝙋𝙎 = 1.000\n` +           
        `➢deposit saldo ketik /deposit\n` + 
        `➢cek saldo ketik /ceksaldo\n` +         
        `\n` +            
        `𝘙𝘜𝘓𝘌𝘚\n` +    
        `➮no spam\n` +    
        `➮instal panel jeda\n` +
        `➮jangan instal panel barengan sama node\n` +  
        `➮pastikan vps fresh create (bukan bekas)\n` +  
        `➮dns record harus terhubung dengan vps yang sama\n` +    
        `➮EROR DI TANGGUNG PENGGUNA\n` + 
        `➮Kesulitan Dalam Memahami? hubungi owner @ziistr\n` +       
        `</pre>` +
        
        `\n➖➖➖➖➖➖➖➖➖➖➖➖\n` +
        `<b><a href="${DEVV_TELEGRAM_LINK}">𝙏𝙐𝙏𝙊𝙍 𝙋𝘼𝙆𝘼𝙄 𝙑𝙄𝙏𝙐𝙍 𝙄𝙉𝙄</a></b> `; // Menggunakan <a> tag untuk membuat teks tampak biru (link)

    
    // Inline Keyboard Disesuaikan untuk mencakup Group Menu dan Back
    const inlineKeyboard = {
        inline_keyboard: [
              [
                { text: '↺ ᗷᗩᑕK', callback_data: '/menu9_callback' }
            ]
        ]
    };
    
    return { responseCaption, inlineKeyboard };
}


module.exports = {
    keyword: '/menu3',
    keywordAliases: ['/menu3', '/menu3_callback'], 
    
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id; 

        const imageExists = fs.existsSync(MENU_IMAGE_PATH);
        const { responseCaption, inlineKeyboard } = getMenuContent();
        
        const sendOptions = { 
            caption: responseCaption, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard,
            reply_to_message_id: isCallback ? undefined : msg.message_id
        };

        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
             // Aksi: EDIT CAPTION pesan yang ada
             try {
                 await bot.editMessageCaption(responseCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                 });
                 // Tambahkan ini agar callback tidak terus berputar
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             } catch(e) { 
                 console.warn(`Gagal mengedit pesan /fitur: ${e.message}. Mencoba mengirim baru.`);
                 // Fallback: Kirim pesan baru
                 if (imageExists) {
                     await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions);
                 } else {
                     await bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                 }
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             }
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /fitur diketik)
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions)
                .catch(error => {
                    console.error(`Gagal mengirim foto menu: ${error.message}`);
                    bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                 bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};