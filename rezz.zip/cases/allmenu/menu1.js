// cases/fitur.js (REVISI FINAL: Merapikan Teks dan Mengubah Format)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

const DEVV_TELEGRAM_LINK = 'https://t.me/ziistr'; 
const MENU_IMAGE_PATH = path.join(__dirname, '..', 'menu.jpg'); 

// --- Fungsi untuk menghasilkan konten pesan (agar bisa dipakai berulang) ---
function getMenuContent() {
     const responseCaption = 
        `<b>📜 𝗗𝗘𝗩𝗘𝗟𝗢𝗣𝗘𝗥 𝗝𝗢𝗨𝗥𝗡𝗘𝗬</b>` + 
        `\n➖➖➖➖➖➖➖➖➖➖➖➖\n\n` +
        
        `<pre>` +
        `   [ 𝘚𝘠𝘚𝘛𝘌𝘔 𝘋𝘌𝘚𝘊𝘙𝘐𝘗𝘛𝘐𝘖𝘕 ]\n` +
        `Bot ini bukan sekadar kode,\n` +
        `melainkan manifestasi dari\n` +
        `logika dan dedikasi tinggi.\n` +
        `Dibangun untuk kecepatan,\n` +
        `ketepatan, dan kemudahan\n` +
        `transaksi Anda secara 24/7.\n` +
        `Semua sistem "Auto Order"\n` +
        `bekerja tanpa lelah.\n` +
        ` \n` +
        `   [ 𝘚𝘖𝘓𝘖 𝘋𝘌𝘝𝘌𝘓𝘖𝘗𝘌𝘙 ]\n` +
        `Dibuat oleh tangan dingin\n` +
        `seorang pengembang tunggal.\n` +
        `Menghabiskan ribuan jam\n` +
        `menghadapi baris kode,\n` +
        `memperbaiki bug di tengah\n` +
        `malam, dan memastikan\n` +
        `setiap fitur berjalan\n` +
        `sempurna demi kepuasan\n` +
        `pengguna.\n` +
        ` \n` +
        `"Karya kecil dari hati\n` +
        ` untuk solusi yang besar."\n` +
        `</pre>` +
        
        `\n➖➖➖➖➖➖➖➖➖➖➖➖\n` +
        `<b><a href="${DEVV_TELEGRAM_LINK}">[ 𝘼𝙏𝙈𝙄𝙉 𝙏𝘼𝙈𝙁𝘼𝙉 𖠡 ]</a></b> `; // Menggunakan <a> tag untuk membuat teks tampak biru (link)

    
    // Inline Keyboard Disesuaikan untuk mencakup Group Menu dan Back
    const inlineKeyboard = {
        inline_keyboard: [
            [ 
                { text: '📩 𝗞𝗢𝗧𝗔𝗞 𝗦𝗨𝗥𝗔𝗧', callback_data: 'chatowner' },
                { text: '⚙️ 𝗨𝗦𝗘𝗥𝗦', callback_data: '/cekuserbot' }
            ],   
             [
                { text: '👥 𝗦𝗨𝗣𝗣𝗢𝗥𝗧', url: settings.LINK_GROUP || 'https://t.me/example' }, 
                { text: '📢 𝗖𝗛𝗔𝗡𝗡𝗘𝗟', url: settings.LINK_CHANNEL || 'https://t.me/example' }
            ],
             [
                { text: '🔥 𝗔𝗕𝗦𝗘𝗡', callback_data: 'absen' },
                { text: '☯︎ 𝗔𝗨𝗧𝗢 𝗥𝗘𝗣𝗟𝗔𝗬', callback_data: '/menu11_callback' }          
            ],            
             [
                { text: '⚙️ 𝗧𝗨𝗧𝗢𝗥𝗜𝗔𝗟', callback_data: '/tutor_callback' },
                { text: '🌟 𝗠𝗬 𝗦𝗨𝗣𝗣𝗢𝗥𝗧', callback_data: 'support' }                
              ],        
              [
                { text: '↺ ᗷᗩᑕK', callback_data: '/start_callback' },
                 { text: '➮ ᑎᗴ᙭T', callback_data: '/menu9_callback' }               
            ]
        ]
    };
    
    return { responseCaption, inlineKeyboard };
}


module.exports = {
    keyword: '/menu1',
    keywordAliases: ['/menu1', '/menu1_callback'], 
    
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id; 

        const imageExists = fs.existsSync(MENU_IMAGE_PATH);
        const { responseCaption, inlineKeyboard } = getMenuContent();
        
        const sendOptions = { 
            caption: responseCaption, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard,
            reply_to_message_id: isCallback ? undefined : msg.message_id
        };

        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
             // Aksi: EDIT CAPTION pesan yang ada
             try {
                 await bot.editMessageCaption(responseCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                 });
                 // Tambahkan ini agar callback tidak terus berputar
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             } catch(e) { 
                 console.warn(`Gagal mengedit pesan /fitur: ${e.message}. Mencoba mengirim baru.`);
                 // Fallback: Kirim pesan baru
                 if (imageExists) {
                     await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions);
                 } else {
                     await bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                 }
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             }
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /fitur diketik)
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions)
                .catch(error => {
                    console.error(`Gagal mengirim foto menu: ${error.message}`);
                    bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                 bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};