// cases/fitur.js (REVISI FINAL: Merapikan Teks dan Mengubah Format)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

const DEVV_TELEGRAM_LINK = 'https://t.me/ziistr'; 
const MENU_IMAGE_PATH = path.join(__dirname, '..', 'menu.jpg'); 

// --- Fungsi untuk menghasilkan konten pesan (agar bisa dipakai berulang) ---
function getMenuContent() {
     const responseCaption = 
        `📖 <b>AUTO REPLAY</b>
┏━━━━━━━━━━━━━━━━━━━━┓
  ⚡ <i>cimaw</i>
┗━━━━━━━━━━━━━━━━━━━━┛
<pre>
Oᗯᑎᗴᖇ OᑎᒪY
➯/addautoreplay [pesan],[balasan]
➯/delautoreolay [pesan]
➯/listautoreplay [cek list]

autoreplay adalah cara bot berinteraksi kepada siapapun dengan pesan dan jawaban yang sudah di atur.
</pre>
 <i> </i>`; // Menggunakan <a> tag untuk membuat teks tampak biru (link)

    
    // Inline Keyboard Disesuaikan untuk mencakup Group Menu dan Back
    const inlineKeyboard = {
        inline_keyboard: [
            [
                { text: '↺ ᗷᗩᑕK', callback_data: '/menu1_callback' }
            ]
        ]
    };
    
    return { responseCaption, inlineKeyboard };
}


module.exports = {
    keyword: '/menu11',
    keywordAliases: ['/menu11', '/menu11_callback'], 
    
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id; 

        const imageExists = fs.existsSync(MENU_IMAGE_PATH);
        const { responseCaption, inlineKeyboard } = getMenuContent();
        
        const sendOptions = { 
            caption: responseCaption, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard,
            reply_to_message_id: isCallback ? undefined : msg.message_id
        };

        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
             // Aksi: EDIT CAPTION pesan yang ada
             try {
                 await bot.editMessageCaption(responseCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                 });
                 // Tambahkan ini agar callback tidak terus berputar
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             } catch(e) { 
                 console.warn(`Gagal mengedit pesan /fitur: ${e.message}. Mencoba mengirim baru.`);
                 // Fallback: Kirim pesan baru
                 if (imageExists) {
                     await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions);
                 } else {
                     await bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                 }
                 await bot.answerCallbackQuery(msg.callbackQuery.id); 
             }
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /fitur diketik)
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions)
                .catch(error => {
                    console.error(`Gagal mengirim foto menu: ${error.message}`);
                    bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                 bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};