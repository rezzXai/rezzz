// cases/fitur.js (REVISI FINAL: Struktur Rapi & List Lengkap)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

const DEVV_TELEGRAM_LINK = 'https://t.me/ziistr'; 
const MENU_IMAGE_PATH = path.join(__dirname, '..', '..', 'menu.jpg'); 

function getMenuContent() {
    const responseCaption = 
        `<b>𝗧𝗢𝗢𝗟𝗦 𝗠𝗘𝗡𝗨 𖣐</b>\n` + 
        `➖➖➖➖➖➖➖➖➖➖➖➖\n\n` +
        
        `<b>◈ ᴅᴏᴡɴʟᴏᴀᴅᴇʀ</b>\n` +
        `<blockquote>` +
        `• /ai          • /tiktok\n` +
        `• /pindl       • /pincari\n` +
        `• /youtube     • /igdl\n` + 
        `• /play [query]</blockquote>\n` + 
        
        `<b>◈ ᴛᴏᴏʟs ᴠɪᴛᴜʀ</b>\n` +
        `<blockquote>` +
        `• /ascii       • /cuaca\n` +
        `• /remind      • /makeqr\n` +
        `• /qr          • /cekname\n` +
        `• /cekip       • /cekid\n` +
        `• /id          • /world\n` +
        `• /cekkendaraan • /cekkhodam\n` +
        `• /artinama    • /ping\n` +
        `• /brat        • /sticker\n` +
        `• /checkurl    • /tourl\n` +
        `• /math        • /spoiler\n` +
        `• /font        • /short\n` +    
        `• /rename      • /delenc\n` +   
        `• /soundmp3    • /quotes\n` +     
        `• /gempa       • /tr\n` +   
        `• /sholat      • /tomp3</blockquote>\n` +
        
        `<b>◈ ᴏᴡɴᴇʀ ᴘʀɪᴠᴀᴛᴇ</b>\n` +
        `<blockquote>` +
        `• /a2f         • /addaksesa2f\n` + 
        `• /dellaksesa2f • /findcmd\n` + 
        `• /listaksesa2f • /listcmd\n` + 
        `• /addstok     • /delstok\n` + 
        `• /delstok     • /addfile\n` + 
        `• /bc          • /delfile\n` +
        `• /wiki        • /getfile\n` +    
        `• /openzip     • /addegg\n` +
        `• /encsc       • /cekjackpot\n` + 
        `• /cleantmp    • /mt\n` +       
        `• /backup      • /acc list\n` +   
        `• /voucher     • /acc\n` +
        `• /cekvoucher  • /bypaslink\n` + 
        `• /getcode     • /text\n` +  
        `• /delvoucher  • /mediafiredl</blockquote>\n` +
        
        `➖➖➖➖➖➖➖➖➖➖➖➖\n` +
        `<b><a href="${DEVV_TELEGRAM_LINK}">[ 𝘼𝙏𝙈𝙄𝙉 𝙏𝘼𝙈𝙁𝘼𝙉 𖠡 ]</a></b> | ᴇɴᴊᴏʏ ᴠɪᴛᴜʀ`;

    const inlineKeyboard = {
        inline_keyboard: [
            [{ text: 'ᴄᴇᴋ ᴋᴇsᴇʜᴀᴛᴀɴ', callback_data: 'cekhabit' }],
            [{ text: '↺ ᗷᗩᑕK', callback_data:'/start_callback' }]
        ]
    };
    
    return { responseCaption, inlineKeyboard };
}

module.exports = {
    keyword: '/fitur',
    keywordAliases: ['/fitur', '/fitur_callback', 'fitur'], 
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id; 
        const imageExists = fs.existsSync(MENU_IMAGE_PATH);
        const { responseCaption, inlineKeyboard } = getMenuContent();
        
        const sendOptions = { 
            caption: responseCaption, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard
        };

        if (isCallback) {
             try {
                 await bot.editMessageCaption(responseCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                 });
                 await bot.answerCallbackQuery(msg.callbackQuery.id).catch(() => {}); 
             } catch(e) { 
                 if (imageExists) {
                     await bot.sendPhoto(chatId, MENU_IMAGE_PATH, sendOptions);
                 } else {
                     await bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                 }
             }
        } else {
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_IMAGE_PATH, { ...sendOptions, reply_to_message_id: msg.message_id }).catch(() => {
                    bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                 bot.sendMessage(chatId, responseCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};