// cases/menu.js (REVISI: FOTO + EDIT MESSAGE + SHORT LIST)

const settings = require('../../setting');
const path = require('path');
const fs = require('fs');

// Path menuju file foto (pastikan file 11.jpg ada di root folder bot)
const MENU_GRUP_IMAGE_PATH = path.join(__dirname, '..', '11.jpg'); 

function getMenuContent(settings) {
    // Perintah tetap lengkap namun disingkat agar tidak melebihi limit caption (1024 karakter)
    const text = `
<b>𝗚𝗥𝗢𝗨𝗣 𝗠𝗘𝗡𝗨 𖣐</b>

<pre>
MODERASI & KEAMANAN:
• /h (tag all) | /poll | /pin
• /kick | /ban | /unban
• /promote | /demote
• /grub (open/close)
• /setdesk | /deldesk | /usernameedit

PROTEKSI (ON/OFF):
• /antilink | /antitag | /antispam
• /antifoto | /antivideo | /badword

SISTEM & LAINNYA:
• /welcome | /setwelcome | /setout
• /addsewa | /delsewa | /ceksewa
• /kuis (hiburan) | /tebakgambar
• /tod (truth or dare)
</pre>
<i>Hanya Admin & Owner yang dapat menggunakan fitur ini.</i>`;

    const inlineKeyboard = {
        inline_keyboard: [[{ text: '↺ ᗷᗩᑕK', callback_data: '/start' }]]
    };
    
    return { text, inlineKeyboard };
}

module.exports = {
    keyword: '/menu',
    keywordAliases: ['/menu_callback'], 
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id;
        const imageExists = fs.existsSync(MENU_GRUP_IMAGE_PATH); 
        const { text, inlineKeyboard } = getMenuContent(settings);
        
        const options = {
            caption: text, 
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard
        };

        if (isCallback) {
            // MENGGUNAKAN EDIT CAPTION AGAR TIDAK HAPUS PESAN
            try {
                await bot.editMessageCaption(text, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                });
            } catch (e) {
                if (e.message.includes('message is not modified')) return;
                
                // Jika gagal edit (misal pesan lama bukan foto), kirim baru
                if (imageExists) {
                    await bot.sendPhoto(chatId, MENU_GRUP_IMAGE_PATH, options);
                } else {
                    await bot.sendMessage(chatId, text, options);
                }
            }
        } else {
            // KIRIM PESAN BARU
            if (imageExists) {
                await bot.sendPhoto(chatId, MENU_GRUP_IMAGE_PATH, options).catch(() => {
                    bot.sendMessage(chatId, text, options);
                });
            } else {
                bot.sendMessage(chatId, text, options);
            }
        }
    }
};