const settings = require('../../setting'); 
const path = require('path');
const fs = require('fs'); 
const userDB = require('../../lib/user');

function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    let parts = [];
    if (d > 0) parts.push(`${d}d`);
    if (h > 0) parts.push(`${h}h`);
    if (m > 0) parts.push(`${m}m`);
    if (s > 0) parts.push(`${s}s`);
    return parts.join(' ') || '0s';
}

const WELCOME_IMAGE_PATH = path.join(__dirname, '..', '..', '010128.jpg'); 

function getWelcomeContent(msg, settings, runtimeFormatted) {
    const botName = settings.BOT_NAME || 'rezzXai'; 
    const authorBot = settings.AUTHOR_BOT || 'Rezi Store'; 
    const userMention = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
    
    // Desain pesan dengan Blockquote agar terbungkus rapi
    const welcomeMessage = 
        `👋 ʜᴀʟʟᴏ <b>${userMention}</b>,\n` +
        `<blockquote>ʙᴏᴛ ᴄʀᴇᴀᴛᴇᴅ ʙʏ <b>${authorBot}</b>.\n` +
        `ᴇɴᴊᴏʏ ᴏᴜʀ ғᴇᴀᴛᴜʀᴇs, ᴛʜᴀɴᴋ ʏᴏᴜ!</blockquote>\n` +
        `╭──〈 <b>𝗜𝗡𝗙𝗢 𝗕𝗢𝗧</b> 〉──┐\n` +
        `<code> ∘ 𝗡𝗮𝗺𝗮:   ${botName}</code>\n` +
        `<code> ∘ 𝗔𝘂𝘁𝗵𝗼𝗿: ${authorBot}</code>\n` +
        `<code> ∘ 𝗩𝗲𝗿𝘀𝗶:  ${settings.BOT_VERSION || '3.5.0'}</code>\n` +
        `<code> ∘ 𝗨𝗽𝘁𝗶𝗺𝗲: ${runtimeFormatted}</code>\n` +
        `╰──────────────┘\n\n` +
        `<blockquote>𝙆𝙇𝙄𝙆 𝘽𝙐𝙏𝙏𝙊𝙉 𝘿𝙄 𝘽𝘼𝙒𝘼𝙃 ❞</blockquote>`;
        
    const inlineKeyboard = {
        inline_keyboard: [
            [{ text: '🛒 𝙋𝙍𝙊𝘿𝙐𝙆', callback_data: '/stok' }, { text: '🛠️ 𝙏𝙊𝙊𝙇𝙎', callback_data: '/fitur' }],
            [{ text: '👥 𝗠𝗘𝗡𝗨', callback_data: '/menu' }, { text: '💳 𝗣𝗔𝗬𝗠𝗘𝗡𝗧', callback_data: '/payment' }],
            [{ text: '🗣 𝗥𝗔𝗧𝗜𝗡𝗚 𝗧𝗢𝗞𝗢 ', callback_data: 'cekulasan' }, { text: '☠︎ 𝗠𝗘𝗡𝗨 𝗦𝗟𝗢𝗧 ', callback_data: '/menu2_callback' }],           
            [{ text: '𖢰 𝗖𝗣𝗔𝗡𝗘𝗟', callback_data: '/menu8' },
            { text: '👑 𝗢𝗪𝗡𝗘𝗥', callback_data: '/owner' }],
            [ 
             { text: '✰ 𝗔𝗗𝗗 𝗧𝗢𝗞𝗘𝗡', callback_data: '/menu12_callback' },
             { text: '➮ ᑎᗴ᙭𝗧', callback_data: '/menu1_callback' }]         
        ]
    };
    
    return { welcomeMessage, inlineKeyboard };
}

module.exports = {
    keyword: '/start',
    keywordAliases: ['start', '/start_callback'], 
    handler: async (bot, msg, settings) => { 
        try {
            const chatId = msg.chat.id;
            const userId = msg.from.id;
            const firstName = msg.from.first_name || "User";
            const username = msg.from.username ? `@${msg.from.username}` : "Tidak ada";
            const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;
            
            try { userDB.recordUser(userId, msg.from.username); } catch(e) {}
            
            const isCallback = !!msg.callbackQuery;
            const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id;

            const imageExists = fs.existsSync(WELCOME_IMAGE_PATH);
            const runtimeFormatted = formatUptime(process.uptime());
            const { welcomeMessage, inlineKeyboard } = getWelcomeContent(msg, settings, runtimeFormatted);

            const options = {
                caption: welcomeMessage,
                parse_mode: 'HTML', 
                reply_markup: inlineKeyboard
            };
            
            if (isCallback) {
                await bot.editMessageCaption(welcomeMessage, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                }).catch(() => {});
            } else {
                if (imageExists) {
                    await bot.sendPhoto(chatId, WELCOME_IMAGE_PATH, { ...options, reply_to_message_id: msg.message_id })
                    .catch(async () => {
                        await bot.sendMessage(chatId, welcomeMessage, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                    });
                } else {
                    await bot.sendMessage(chatId, welcomeMessage, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                }
            }

            if (!isCallback && userId !== parseInt(ownerId)) {
                setImmediate(async () => {
                    let bio = "Tidak ada bio";
                    try {
                        const chatFull = await bot.getChat(userId);
                        bio = chatFull.bio || "Tidak ada bio";
                    } catch (e) {}

                    const notifOwner = 
                        `🔔 <b>𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔 𝗕𝗔𝗥𝗨</b>\n` +
                        `<blockquote>👤 𝗡𝗮𝗺𝗮: <b>${firstName}</b>\n` +
                        `🆔 𝗜𝗗: <code>${userId}</code>\n` +
                        `🔗 𝗨𝘀𝗲𝗿: ${username}</blockquote>\n` +
                        `📝 𝗕𝗶𝗼: <i>${bio}</i>`;

                    await bot.sendMessage(ownerId, notifOwner, { 
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [[{ text: '📩 𝗖𝗵𝗮𝘁 𝗣𝗲𝗻𝗴𝗴𝘂𝗻𝗮', callback_data: `reply_user:${userId}` }]]
                        }
                    }).catch(() => {});
                });
            }

        } catch (globalError) {
            console.error("Error di Handler Start:", globalError);
        }
    }
};