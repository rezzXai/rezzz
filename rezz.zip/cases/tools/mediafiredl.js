const { mediafireDl } = require('../../mediafire'); 

const axios = require('axios');

const settings = require('../../setting');

module.exports = {

    keyword: 'mediafiredl',

    keywordAliases: ['mfdl', 'mediafire'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.trim().split(/\s+/);

        if (!settings.OWNER_ID.includes(userId)) return;

        if (args.length < 2) return bot.sendMessage(chatId, "✘ Masukkan link Mediafire!");

        const url = args[1];

        const loadingMsg = await bot.sendMessage(chatId, "⏳ Memproses file...");

        try {

            const result = await mediafireDl(url);

            

            const sizeStr = result.size.toUpperCase();

            const sizeNum = parseFloat(sizeStr);

            const isMB = sizeStr.includes('MB');

            const isGB = sizeStr.includes('GB');

            // Proteksi RAM 122MiB: Tetap batasi maksimal 15MB agar bot tidak mati

            if (isGB || (isMB && sizeNum > 15)) {

                return await bot.editMessageText(

                    `⚠️ **File Terlalu Besar (${result.size})**\n\nUntuk menjaga RAM, silakan download manual:`,

                    {

                        chat_id: chatId,

                        message_id: loadingMsg.message_id,

                        reply_markup: {

                            inline_keyboard: [[{ text: "📥 Download Manual", url: result.link }]]

                        }

                    }

                );

            }

            // Download ke Buffer

            const response = await axios.get(result.link, { 

                responseType: 'arraybuffer',

                headers: { 'User-Agent': 'Mozilla/5.0' }

            });

            const buffer = Buffer.from(response.data, 'binary');

            const fileName = result.name.toLowerCase();

            const caption = `✅ 𝘿𝙤𝙬𝙣𝙡𝙤𝙖𝙙 𝙎𝙪𝙘𝙘𝙚𝙨\n📄 ${result.name}\n⚖️ ${result.size}`;

            // --- LOGIKA PEMILIHAN JENIS PENGIRIMAN ---

            if (fileName.endsWith('.mp4') || fileName.endsWith('.mkv') || fileName.endsWith('.mov')) {

                // Kirim sebagai Video Player

                await bot.sendVideo(chatId, buffer, { caption: caption }, { filename: result.name });

            } else if (fileName.endsWith('.jpg') || fileName.endsWith('.jpeg') || fileName.endsWith('.png')) {

                // Kirim sebagai Foto

                await bot.sendPhoto(chatId, buffer, { caption: caption });

            } else {

                // Kirim sebagai Dokumen (untuk zip, apk, dll)

                await bot.sendDocument(chatId, buffer, { caption: caption }, { filename: result.name });

            }

            // Hapus loading setelah sukses

            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

        } catch (e) {

            console.error(`🔴 MFDL Error: ${e.message}`);

            bot.editMessageText(`❌ Gagal mengirim otomatis. Link download:\n${url}`, {

                chat_id: chatId,

                message_id: loadingMsg.message_id

            }).catch(() => {});

        }

    }

};