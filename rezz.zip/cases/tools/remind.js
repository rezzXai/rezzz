// cases/remind.js (Timer dan Pengingat - DENGAN PENGULANGAN)

// Fungsi untuk menguraikan string waktu (misal: '10m', '2h') menjadi milidetik
const parseTime = (timeString) => {
    const timeRegex = /^(\d+)([smh])$/; 
    const match = timeString.match(timeRegex);

    if (!match) {
        return null;
    }

    const value = parseInt(match[1], 10);
    const unit = match[2];
    let milliseconds = 0;

    switch (unit) {
        case 's': // detik
            milliseconds = value * 1000;
            break;
        case 'm': // menit
            milliseconds = value * 60 * 1000;
            break;
        case 'h': // jam
            milliseconds = value * 60 * 60 * 1000;
            break;
        default:
            return null;
    }

    const maxDelay = 24 * 60 * 60 * 1000; 
    if (milliseconds > maxDelay) {
         throw new Error('Maksimum waktu pengingat yang diizinkan adalah 24 jam.');
    }

    return milliseconds;
};

// ===============================================

module.exports = {
    keyword: 'remind',
    keywordAliases: ['/remind', '/alarm', '/timer'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const args = msg.text.split(' ').slice(1); // Ambil semua argumen setelah /remind
        
        if (args.length < 2) {
            return bot.sendMessage(chatId, 
                "❌ **Format Salah.** Harap gunakan format:\n" +
                "`/remind [waktu] [pesan] [ulangi_jumlah]`\n" +
                "Contoh: `/remind 10s Bangun Sekarang! 5` (pesan akan dikirim 5 kali).\n" +
                "Jika `ulangi_jumlah` dihilangkan, pesan akan dikirim 1 kali.",
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const timeString = args[0];
        let delayMs;
        let repeatCount = 1; // Default
        let reminderMessage;
        
        // Cek apakah argumen terakhir adalah angka untuk pengulangan
        const lastArg = args[args.length - 1];
        const potentialCount = parseInt(lastArg, 10);

        if (args.length >= 3 && !isNaN(potentialCount) && potentialCount > 0) {
            repeatCount = Math.min(potentialCount, 50); // Batasi maks 50 untuk menghindari flood
            reminderMessage = args.slice(1, args.length - 1).join(' '); // Ambil pesan di antara waktu dan hitungan
        } else {
            reminderMessage = args.slice(1).join(' '); // Semua setelah waktu adalah pesan
        }

        if (repeatCount > 10 && repeatCount < 50) {
            repeatCount = 50; // Batasi maks 50
            console.warn(`[REMINDER] Jumlah ulangan terlalu banyak, dibatasi menjadi 50.`);
        } else if (repeatCount > 50) {
            repeatCount = 50;
        }


        try {
            delayMs = parseTime(timeString);
        } catch (e) {
             return bot.sendMessage(chatId, `❌ ${e.message}`, { reply_to_message_id: msg.message_id });
        }

        if (delayMs === null) {
             return bot.sendMessage(chatId, 
                "✘ Format waktu tidak sesuai.Gunakan: s,m,h [detik,menit,jam]",
                { reply_to_message_id: msg.message_id });
        }

        if (delayMs < 1000) { 
             return bot.sendMessage(chatId, "❌ Pengingat harus lebih dari 1 detik.", { reply_to_message_id: msg.message_id });
        }
        
        // Konversi milidetik kembali ke format yang mudah dibaca untuk konfirmasi
        const hours = Math.floor(delayMs / 3600000);
        const minutes = Math.floor((delayMs % 3600000) / 60000);
        const seconds = Math.floor((delayMs % 60000) / 1000);
        
        let readableTime = '';
        if (hours > 0) readableTime += `${hours} jam `;
        if (minutes > 0) readableTime += `${minutes} menit `;
        if (seconds > 0) readableTime += `${seconds} detik`;
        readableTime = readableTime.trim();

        // 3. SET TIMER dengan LOGIKA PENGULANGAN
        setTimeout(async () => {
            const baseMessage = `🔔 _${reminderMessage}_`;
            const totalSends = repeatCount;
            
            for (let i = 0; i < totalSends; i++) {
                try {
                    const finalMessage = totalSends > 1 
                        ? `${baseMessage} **[${i + 1}/${totalSends}]**`
                        : baseMessage;
                        
                    await bot.sendMessage(chatId, finalMessage, { parse_mode: 'Markdown' });
                    
                    // JEDA KECIL (200ms) untuk mencegah flood/ban oleh Telegram
                    if (totalSends > 1) {
                         await new Promise(resolve => setTimeout(resolve, 200));
                    }
                } catch (error) {
                    console.error(`Gagal mengirim pesan pengingat ke-${i + 1}: ${error.message}`);
                    // Hentikan loop jika ada error serius (misal: bot diblokir)
                    break; 
                }
            }

        }, delayMs);
        
        // 4. Kirim Konfirmasi
        const repeatInfo = repeatCount > 1 ? `sebanyak **${repeatCount}** kali` : `1 kali`;
        
        return bot.sendMessage(chatId, 
            `✅ **Pengingat berhasil diatur!**\n` +
            `Saya akan mengirim pesan "${reminderMessage}" dalam waktu **${readableTime}** ${repeatInfo} dari sekarang.`,
            { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
    }
};