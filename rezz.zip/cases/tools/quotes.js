module.exports = {

    keyword: 'quotes',

    keywordAliases: ['quote', 'katabijak', 'motivasi'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const quotesList = [

            "Pekerjaanmu akan mengisi sebagian besar hidupmu, lakukan apa yang kamu yakini besar.",

            "Jangan biarkan opini orang lain menenggelamkan suara hatimu sendiri.",

            "Cintai apa yang kamu lakukan untuk hasil yang hebat.",

            "Inovasi membedakan antara pemimpin dan pengikut.",

            "Waktumu terbatas, jangan jalani hidup orang lain.",

            "Stay hungry, stay foolish.",

            "Hiduplah seolah mati besok, belajarlah seolah hidup selamanya.",

            "Kekuatan datang dari kemauan yang gigih.",

            "Jadilah perubahan yang ingin kamu lihat di dunia ini.",

            "Lemah lembutlah pada diri sendiri, kamu sudah melakukan yang terbaik.",

            "Masa depan milik mereka yang percaya pada keindahan mimpi.",

            "Hari buruk memberimu pengalaman, hari baik memberimu kebahagiaan.",

            "Sukses adalah berjalan dari kegagalan ke kegagalan tanpa hilang semangat.",

            "Kegagalan adalah kesempatan memulai lagi dengan lebih cerdas.",

            "Jangan menunggu, waktunya tidak akan pernah benar-benar tepat.",

            "Tindakan adalah kunci dasar untuk semua kesuksesan.",

            "Kesulitan adalah peluang menunjukkan kemampuan terbaik.",

            "Mimpi butuh keringat, tekad, dan kerja keras.",

            "Disiplin adalah jembatan antara tujuan dan pencapaian.",

            "Bandingkan dirimu dengan siapa kamu kemarin, bukan orang lain.",

            "Rahasia untuk maju adalah memulai.",

            "Percayalah kamu bisa, itu sudah setengah jalan.",

            "Kebahagiaan berasal dari tindakanmu sendiri.",

            "Ubah pikiranmu dan kamu akan mengubah duniamu.",

            "Hanya aku yang bisa mengubah hidupku sendiri.",

            "Optimisme adalah kepercayaan yang mengarah pada pencapaian.",

            "Masalah adalah petunjuk arah, bukan tanda berhenti.",

            "Jangan biarkan hari kemarin menyita terlalu banyak hari ini.",

            "Kita boleh kalah, tapi tidak boleh dikalahkan.",

            "Cara terbaik memprediksi masa depan adalah menciptakannya.",

            "Segala sesuatu yang dapat dibayangkan adalah nyata.",

            "Buatlah hari-harimu berhitung, jangan hanya menghitung hari.",

            "Keberanian adalah rahmat di bawah tekanan.",

            "Lakukan sesuatu yang baru untuk hasil yang baru.",

            "Tidak mendapatkan keinginan terkadang adalah keberuntungan.",

            "Mulailah sekarang untuk menjadi hebat nanti.",

            "Batas hari esok adalah keraguan kita hari ini.",

            "Berpikirlah besar dan abaikan mereka yang meragukanmu.",

            "Kreativitas adalah kecerdasan yang sedang bersenang-senang.",

            "Kualitas adalah sebuah kebiasaan, bukan tindakan sekali saja.",

            "Lakukan apa yang kamu bisa dengan apa yang kamu miliki.",

            "Batas antara kamu dan tujuanmu adalah alasan yang kamu buat sendiri.",

            "Lepaskan yang baik demi mengejar yang terbaik.",

            "Hidup terjadi saat kamu sibuk membuat rencana lain.",

            "Perjalanan seribu mil dimulai dengan satu langkah.",

            "Kita adalah apa yang kita pikirkan.",

            "Kesuksesan adalah jumlah upaya kecil yang diulang terus-menerus.",

            "Bekerjalah seolah orang lain mencoba mengambil posisi darimu.",

            "Tujuan hidup adalah hidup dengan tujuan.",

            "Jangan biarkan kegagalan kemarin merusak hari ini.",

            "Ketekunan mengalahkan bakat saat bakat tidak bekerja keras.",

            "Fokuslah pada hasil, bukan pada hambatan.",

            "Hidup membaik karena perubahan, bukan kebetulan.",

            "Jangan menyerah pada mimpi hanya karena waktu yang lama.",

            "Setiap pagi kita lahir kembali untuk berbuat lebih baik.",

            "Kebahagiaan berlipat ganda saat dibagikan.",

            "Balas dendam terbaik adalah sukses besar.",

            "Jadilah dirimu sendiri karena orang lain sudah ada.",

            "Kadang kita menang, kadang kita belajar.",

            "Jika bisa memimpikannya, kamu bisa melakukannya.",

            "Kecemerlangan sejati adalah melakukan hal biasa secara luar biasa.",

            "Semakin keras bekerja, semakin beruntung rasanya.",

            "Jangan biarkan suara dunia luar mengaburkan intuisimu.",

            "Masa depan diciptakan oleh apa yang dilakukan hari ini.",

            "Lakukan sesuatu hari ini agar dirimu di masa depan berterima kasih.",

            "Kebesaran adalah bangkit setiap kali jatuh.",

            "Jangan batasi dirimu karena imajinasi orang lain yang terbatas.",

            "Satu-satunya kegagalan nyata adalah tidak mencoba.",

            "Bangun mimpimu sendiri atau orang lain akan menyewamu membangun mimpi mereka.",

            "Jangan biarkan kekurangan menghalangi kelebihanmu.",

            "Kebahagiaan adalah kunci kesuksesan.",

            "Berhenti meragukan diri, mulai bekerja keras.",

            "Jadilah alasan seseorang tersenyum hari ini.",

            "Hidup singkat, habiskan bersama orang yang membuatmu tertawa.",

            "Keberanian adalah suara kecil yang mencoba lagi besok.",

            "Ilmu adalah satu hal yang tidak bisa dicuri darimu.",

            "Hidup tidak pernah berhenti mengajar, jangan berhenti belajar.",

            "Kesalahan adalah bukti bahwa kamu sedang mencoba.",

            "Hidup adalah petualangan yang berani atau tidak sama sekali.",

            "Apa yang kamu tanam sekarang akan kamu tuai nanti.",

            "Bersyukurlah atas apa yang kamu punya sekarang.",

            "Tantangan membuat hidup bermakna.",

            "Jangan biarkan rasa takut kalah menghalangi semangat menang.",

            "Hidup sekali saja cukup jika dilakukan dengan benar.",

            "Segalanya tampak mustahil sampai itu selesai.",

            "Gunakan senyummu untuk mengubah dunia.",

            "Sukses adalah mencintai diri sendiri dan pekerjaanmu.",

            "Jangan hanya bermimpi, segera kerjakan.",

            "Jangan jelaskan dirimu pada pembencimu.",

            "Cintai dirimu sendiri agar segalanya selaras.",

            "Percayalah pada setiap proses yang kamu lalui.",

            "Ketenangan adalah kekuatan tertinggi.",

            "Tidak ada kata terlambat untuk memulai kembali.",

            "Energi positif membawa hasil yang positif.",

            "Jangan berhenti sampai kamu merasa bangga.",

            "Kesabaran memang pahit, tapi buahnya manis.",

            "Awal besar dimulai dari hal-hal kecil.",

            "Berikan dampak, bukan hanya sekadar pendapatan.",

            "Jadilah versi terbaik dari dirimu.",

            "Keajaiban ada bagi mereka yang tidak menyerah.",

            "Tetap rendah hati dan tetap semangat.",

            "Langkah kecil hari ini adalah perubahan besar esok hari.",

            "Keberhasilan tidak datang secara instan.",

            "Fokus pada kemajuan, bukan kesempurnaan.",

            "Setiap tantangan adalah peluang yang menyamar.",

            "Hidup adalah cermin dari pikiran kita sendiri.",

            "Jangan biarkan emosi mengendalikan logika.",

            "Kerja keras mengalahkan keberuntungan.",

            "Kesabaran adalah kunci segala kemenangan.",

            "Dunia ini penuh dengan peluang, carilah satu.",

            "Jangan biarkan kritik menjatuhkan semangatmu.",

            "Hargai setiap detik waktu yang kamu miliki.",

            "Keberanian adalah melangkah meski merasa takut.",

            "Jujur pada diri sendiri adalah awal kebijaksanaan.",

            "Berani bermimpi, berani mewujudkan.",

            "Kebaikan yang kamu beri akan kembali padamu.",

            "Jangan biarkan masa lalu menghantui masa depan.",

            "Berpikir positif adalah separuh dari solusi.",

            "Keyakinan adalah mesin penggerak kesuksesan.",

            "Bersabarlah dalam setiap kesulitan.",

            "Kesuksesan sejati adalah ketenangan hati.",

            "Jadilah terang di tengah kegelapan.",

            "Jangan pernah menyerah sebelum mencoba segalanya.",

            "Keikhlasan adalah jalan menuju kebahagiaan.",

            "Tetapkan tujuan dan kejarlah tanpa henti.",

            "Kebijaksanaan dimulai dengan rasa ingin tahu.",

            "Bersyukur membuat hidup terasa cukup.",

            "Tersenyumlah meski dunia sedang tidak ramah.",

            "Jangan biarkan kegagalan menghentikan langkahmu.",

            "Setiap kesulitan pasti ada kemudahan.",

            "Berbuat baiklah tanpa mengharap imbalan.",

            "Ilmu adalah pelita dalam kegelapan.",

            "Hormati waktu karena ia tidak bisa diputar kembali.",

            "Kesehatan adalah kekayaan yang paling berharga.",

            "Kedamaian dimulai dengan satu senyuman.",

            "Kejujuran adalah fondasi dari kepercayaan.",

            "Jangan sombong saat berada di puncak.",

            "Jangan putus asa saat berada di bawah.",

            "Kesuksesan adalah proses, bukan tujuan akhir.",

            "Berusahalah sebaik mungkin dalam segala hal.",

            "Berdoa dan berusaha adalah kunci sukses.",

            "Hargai orang lain jika ingin dihargai.",

            "Kedisiplinan membawa kebebasan.",

            "Kreativitas tidak mengenal batas.",

            "Jadilah pribadi yang bermanfaat bagi sesama.",

            "Jangan pernah berhenti bermimpi besar.",

            "Semangat yang membara adalah modal utama.",

            "Percaya pada diri sendiri adalah kunci utama.",

            "Setiap hari adalah kesempatan baru untuk sukses.",

            "Jaga pikiranmu tetap positif setiap saat.",

            "Sukses diraih oleh mereka yang berani mencoba."

        ];

        // Memilih secara acak tanpa urutan

        const randomQuote = quotesList[Math.floor(Math.random() * quotesList.length)];

        const pesan = ` 𝙌𝙐𝙊𝙏𝙀𝙎\n\n"${randomQuote}"\n\n_Semangat hari ini, Rezz!_`;

        try {

            await bot.sendMessage(chatId, pesan, { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        } catch (e) {

            console.error(`🔴 Quotes Error: ${e.message}`);

        }

    }

};