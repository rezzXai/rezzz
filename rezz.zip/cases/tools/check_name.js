// cases/check_name.js

const axios = require('axios');

// Asumsi path ke settings.js yang benar sesuai logika router Anda

const settings = require('../../setting'); 

// Pastikan konfigurasi providers tersedia

const providers = settings.NAME_CHECK_PROVIDERS || [];

// Fungsi inti untuk mengecek ketersediaan di satu provider

const checkAvailability = async (provider, username) => {

    const fullUrl = provider.url + username;

    

    // Konfigurasi Axios

    const config = {

        method: 'head', // Gunakan HEAD request untuk memuat lebih cepat

        url: fullUrl,

        validateStatus: (status) => true, // Terima semua kode status

        timeout: 5000 // Timeout 5 detik

    };

    try {

        const response = await axios(config);

        const status = response.status;

        // Logika untuk status 404/Redirect/Used

        if (status === provider.statusValid) {

            // Status 404 atau status yang didefinisikan sebagai 'Tersedia'

            return { providerName: provider.name, available: true, status: status, url: fullUrl };

        } 

        

        // Status lain (200 OK, 3xx Redirect, 4xx/5xx Error lain) dianggap sudah digunakan

        return { providerName: provider.name, available: false, status: status, url: fullUrl, reason: 'Used' };

    } catch (error) {

        // Penanganan error jaringan/timeout (anggap sedang digunakan atau tidak bisa diakses)

        return { providerName: provider.name, available: false, status: 'Error', url: fullUrl, reason: 'Network Error/Timeout' };

    }

};

const checkNameHandler = async (bot, msg, settings) => {

    const chatId = msg.chat.id;

    const text = msg.text || '';

    

    // 🔥 PARSING ARGS DILAKUKAN DI SINI

    // Mengambil semua teks setelah /cekname

    const username = text.split(/\s+/).slice(1).join(' ').trim();

    

    if (!username || providers.length === 0) {

        let errorText = '✘ **ᴋᴇsᴀʟᴀʜᴀɴ ᴘᴇɴɢɢᴜɴᴀᴀɴ.**\n\nᴄᴀʀᴀ ɢᴜɴᴀ: `/cekname <username_yang_ingin_dicek>`\nᴄᴏɴᴛᴏʜ: `/cekname rezzTampan`';

        if (providers.length === 0) {

            errorText += '\n\n⚠️ **ᴇʀᴏʀ:** ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴘʀᴏᴠɪᴅᴇʀ ʏᴀɴɢ ᴅɪ ᴘʀᴏsᴇs.';

        }

        return bot.sendMessage(chatId, errorText, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });

    }

    

    const processingMessage = await bot.sendMessage(chatId, 

        `⏳ ᴘʀᴏsᴇs ᴘᴇɴɢᴇᴄᴇᴋᴀɴ ${username} ᴅɪ ${providers.length} ᴘʀᴏᴠɪᴅᴇʀ...`, 

        { reply_to_message_id: msg.message_id });

    // --- 1. Jalankan Semua Pengecekan secara Paralel ---

    const checkPromises = providers.map(provider => checkAvailability(provider, username));

    const results = await Promise.all(checkPromises);

    // --- 2. Analisis Hasil ---

    let responseText = `☄︎ **𝘾𝙀𝙆 𝙎𝙐𝘾𝘾𝙀𝙎:** \`${username}\`\n\n`;

    let isGloballyAvailable = true;

    

    const availableList = [];

    const usedList = [];

    results.forEach(result => {

        if (result.available) {

            availableList.push(`✅ **${result.providerName}**`);

        } else {

            // Status ditambahkan hanya untuk debugging, bisa dihapus jika tidak diperlukan

            usedList.push(`❌ ${result.providerName} (${result.status})`);

            isGloballyAvailable = false;

        }

    });

    // --- 3. Format Output ---

    

    if (isGloballyAvailable) {

        // Output jika valid di SEMUA platform

        responseText = `
Nama: \`${username}\`

✔ **ᴜsᴇʀ ᴛᴇʀsᴇʙᴜᴛ ʙᴇʟᴜᴍ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴘʀᴏᴠɪᴅᴇʀ ᴍᴀɴᴀᴘᴜɴ:**

${availableList.join('\n')}

        `;

    } else {

        // Output jika ada yang sudah digunakan

        responseText += `

ᴛᴇʀsᴇᴅɪᴀ (${availableList.length} ᴅᴀʀɪ ${providers.length}):

${availableList.join('\n') || '*(Tidak tersedia di provider mana pun)*'}

sᴜᴅᴀʜ ᴅɪ ɢᴜɴᴀᴋᴀɴ (${usedList.length}):

${usedList.join('\n')}

        `;

    }

    // Hapus pesan tunggu dan kirim hasil

    await bot.deleteMessage(chatId, processingMessage.message_id).catch(() => {});

    

    bot.sendMessage(chatId, responseText, { parse_mode: 'Markdown' });

};

module.exports = {

    keyword: ['cekname'], // Hanya keyword tanpa '/'

    keywordAliases: ['/cekname'], // Alias dengan '/'

    handler: checkNameHandler

};