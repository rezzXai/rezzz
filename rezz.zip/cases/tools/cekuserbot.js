// cases/cekuserbot.js (REVISI FINAL: Mempertahankan Gambar dan Edit Caption)

const { OWNER_USERNAME, BOT_NAME } = require('../../setting'); 
const userDB = require('../../lib/user'); 
const path = require('path'); // <<< BARIS BARU: IMPORT PATH
const fs = require('fs');

// --- PATH FILE LOKAL (SAMA DENGAN start.js) ---
const WELCOME_IMAGE_PATH = path.join(__dirname, '..', '010128.jpg'); 


// --- Helper Function: Uptime (Waktu Aktif Bot) ---
function formatUptime(seconds) {
    const d = Math.floor(seconds / (3600 * 24));
    const h = Math.floor((seconds % (3600 * 24)) / 3600);
    const m = Math.floor((seconds % 3600) / 60);
    const s = Math.floor(seconds % 60);
    
    let parts = [];
    if (d > 0) parts.push(`${d} hari`);
    if (h > 0) parts.push(`${h} jam`);
    if (m > 0) parts.push(`${m} menit`);
    if (s > 0) parts.push(`${s} detik`);
    return parts.join(', ') || 'Baru saja dimulai';
}

// --- FUNGSI NYATA: Hitung Pengguna (Mengambil dari lib/user.js) ---
function getRegisteredUserCount() {
    return userDB.getTotalUserCount(); 
}

// --- Fungsi untuk menghasilkan konten pesan ---
function getStatusContent(msg, pingMs) {
    const user = msg.from;
    const runtimeFormatted = formatUptime(process.uptime());
    const totalUsers = getRegisteredUserCount(); 
    
    const userName = user.username ? `@${user.username}` : user.first_name;
    
    const statusText = 
        `𝗧𝗢𝗧𝗔𝗟 𝗣𝗘𝗡𝗚𝗚𝗨𝗡𝗔 𖠂\n\n` +
        `<pre>` +
        ` ∘ Nama Bot:    ${BOT_NAME || 'rezzBot'}\n` +
        ` ∘ User bot:   ${userName}\n` +
        ` ∘ ID bot:     ${user.id}\n` +
        ` -------------------------------------\n` +
        ` ∘ Total User:  ${totalUsers} pengguna\n` +
        ` ∘ Runtime Bot: ${runtimeFormatted}\n` +
        ` ∘ Ping Bot:    ${pingMs || 'N/A'} ms\n` +
        `</pre>`;
        
    const inlineKeyboard = {
        inline_keyboard: [
            [
                { text: '☜ʙᴀᴄᴋ', callback_data: '/menu1_callback' } 
            ]
        ]
    };
    
    return { statusText, inlineKeyboard };
}


module.exports = {
    keyword: '/cekuserbot',
    keywordAliases: ['/cekuserbot_callback'], 
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id;
        const imageExists = fs.existsSync(WELCOME_IMAGE_PATH); // Cek keberadaan foto

        // --- 1. Ukur Ping ---
        let pingMs = null;
        if (!isCallback) {
            const start = Date.now();
            await bot.sendChatAction(chatId, 'typing'); 
            pingMs = Date.now() - start;
        }

        const { statusText, inlineKeyboard } = getStatusContent(msg, pingMs);

        const options = {
            chat_id: chatId,
            message_id: messageId,
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard,
            // caption diperlukan jika mengirim foto baru
            caption: statusText 
        };

        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
            // Aksi: EDIT CAPTION (Jika dipicu dari tombol, kita asumsikan pesan asalnya adalah foto)
            try {
                // Menggunakan editMessageCaption untuk mengedit teks sambil mempertahankan foto
                await bot.editMessageCaption(statusText, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                }); 
            } catch (e) {
                console.warn(`Gagal mengedit caption (/cekuserbot): ${e.message}. Mencoba mengirim ulang.`);
                
                // Fallback: Jika edit gagal (misal pesan terlalu tua), kirim ulang pesan dengan foto
                 if (imageExists) {
                    await bot.sendPhoto(chatId, WELCOME_IMAGE_PATH, options);
                } else {
                    await bot.sendMessage(chatId, statusText, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                }
            }
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /cekuserbot diketik)
            // Mengirim sebagai pesan foto baru (jika ada)
            if (imageExists) {
                await bot.sendPhoto(chatId, WELCOME_IMAGE_PATH, options)
                .catch(async error => {
                    console.warn(`Gagal mengirim foto status lokal: ${error.message}. Mengirim sebagai teks.`);
                    await bot.sendMessage(chatId, statusText, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                });
            } else {
                await bot.sendMessage(chatId, statusText, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};