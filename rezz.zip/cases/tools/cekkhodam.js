// cases/cekkhodam.js (FITUR BARU: Cek Khodam Random)

module.exports = {
    keyword: 'cekkhodam', 
    keywordAliases: ['/cekkhodam'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const senderName = msg.from.first_name || 'Anda';
        const senderId = msg.from.id;

        // --- DAFTAR KHODAM (DATA) ---
        // Anda bisa menambahkan atau mengurangi nama-nama khodam di sini
        const khodamList = [
            "Naga Terbang",
            "Ular Bermahkota",
            "Kucing Oren Barbar",
            "Buaya Darat Senior",
            "Kumbang Jati",
            "Tikus Got Juara",
            "Kecoa Terbang Malam",
            "Jin Ifrit Galau",
            "Kadal Gurun Sunmori",
            "Pocong Anti-Gaya",
            "Tukang Cilok Keliling",
            "Setan Kredit Online",
            "Macan Putih OVT",
            "Burung Hantu Rebahan",
            "Sendal Jepit Abadi",
            "Kosong (Belum Terisi)", 
            "Mimi Peri Jatuh Cinta"
        ];
        
        // --- LOGIKA RANDOM ---
        const randomIndex = Math.floor(Math.random() * khodamList.length);
        const khodamName = khodamList[randomIndex];
        
        // --- PESAN RESPON ---
        let responseMessage = 
            `🔮 **CEK KHODAM ONLINE!** 🔮\n\n` +
            `Hasil penerawangan untuk *${senderName}* (ID: \`${senderId}\`):\n\n` +
            `Khodam yang melindungi Anda adalah:\n\n` +
            `✨ **${khodamName.toUpperCase()}** ✨\n\n` +
            `Jaga energi Khodam Anda!`;

        try {
            await bot.sendMessage(chatId, responseMessage, { 
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id 
            });
        } catch (error) {
            console.error(`Gagal mengirim pesan khodam: ${error.message}`);
        }
    }
};