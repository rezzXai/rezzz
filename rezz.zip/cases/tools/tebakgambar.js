const fs = require('fs');

const path = require('path');

// Lokasi folder gambar (Sesuaikan dengan nama folder baru kamu)

const folderGambar = path.join(__dirname, '../../TEBAKGAMBAR');

if (!global.tebakgambar) global.tebakgambar = {};

module.exports = {

    keyword: 'tebakgambar',

    keywordAliases: ['tg', 'nyerah'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const text = msg.text ? msg.text.toLowerCase() : '';

        // FITUR MENYERAH

        if (text.includes('nyerah')) {

            if (!global.tebakgambar[chatId]) return bot.sendMessage(chatId, "✘ Tidak ada game aktif.");

            const jawabanBenar = global.tebakgambar[chatId].jawaban;

            clearTimeout(global.tebakgambar[chatId].timeout);

            delete global.tebakgambar[chatId];

            return bot.sendMessage(chatId, `𝙔𝙀𝙐 𝙏𝙊𝙇𝙊𝙇\nJawabannya: ${jawabanBenar}`);

        }

        if (global.tebakgambar[chatId]) {

            return bot.sendMessage(chatId, "⚠️ Selesaikan soal yang ada!");

        }

        try {

            // Cek apakah folder ada

            if (!fs.existsSync(folderGambar)) {

                return bot.sendMessage(chatId, "✘ Folder `TEBAKGAMBAR` tidak ditemukan di direktori utama.");

            }

            // 1. Baca semua file di folder TEBAKGAMBAR

            const files = fs.readdirSync(folderGambar).filter(file => 

                file.endsWith('.jpg') || file.endsWith('.png') || file.endsWith('.jpeg') || file.endsWith('.webp')

            );

            if (files.length === 0) {

                return bot.sendMessage(chatId, "✘ Folder `TEBAKGAMBAR` masih kosong. Masukkan gambar dulu!");

            }

            // 2. Pilih file secara acak

            const fileAcak = files[Math.floor(Math.random() * files.length)];

            

            // 3. Ambil jawaban dari nama file

            const jawabanBenar = path.parse(fileAcak).name.toUpperCase();

            const pathGambar = path.join(folderGambar, fileAcak);

            // 4. Simpan sesi game

            global.tebakgambar[chatId] = {

                jawaban: jawabanBenar,

                timeout: setTimeout(() => {

                    if (global.tebakgambar[chatId]) {

                        bot.sendMessage(chatId, `𝙒𝘼𝙆𝙏𝙐 𝙃𝘼𝘽𝙄𝙎\nJawabannya: ${jawabanBenar}`);

                        delete global.tebakgambar[chatId];

                    }

                }, 60000)

            };

            // 5. Kirim gambar lokal ke Telegram

            await bot.sendPhoto(chatId, pathGambar, {

                caption: ` 𝙏𝙀𝘽𝘼𝙆 𝙂𝘼𝙈𝘽𝘼𝙍\n\nPetunjuk: ${jawabanBenar.length} Huruf\nWaktu: 60 detik.\n\n_Ketik jawaban langsung atau /nyerah_`,

                parse_mode: 'Markdown'

            });

        } catch (e) {

            console.error(e);

            bot.sendMessage(chatId, "✘ Gagal membaca folder gambar.");

        }

    }

};