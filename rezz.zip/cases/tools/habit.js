// cases/habit.js (REVISI: Format <pre> pada cekhabit)

const fs = require('fs');

const path = require('path');

const dbPath = path.join(__dirname, '../database/habit.json');

// Inisialisasi Database

if (!fs.existsSync(dbPath)) {

    if (!fs.existsSync(path.join(__dirname, '../database'))) fs.mkdirSync(path.join(__dirname, '../database'));

    fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));

}

const loadDb = () => JSON.parse(fs.readFileSync(dbPath));

const saveDb = (data) => fs.writeFileSync(dbPath, JSON.stringify(data, null, 2));

module.exports = {

    keyword: 'habit',

    keywordAliases: ['addhabit', 'done', 'cekhabit', 'delhabit'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.split(' ');

        const command = args[0].toLowerCase().replace('/', '');

        if (msg.chat.type !== 'private') {

            return bot.sendMessage(chatId, "✘ ᴡʟᴇᴇ.");

        }

        let db = loadDb();

        if (!db[userId]) db[userId] = [];

        const today = new Date().toLocaleDateString('id-ID');

        // 1. TAMBAH HABIT BARU (/addhabit)

        if (command === 'addhabit') {

            const habitName = args.slice(1).join(' ');

            if (!habitName) return bot.sendMessage(chatId, "✘ ɢᴜɴᴀᴋᴀɴ: `/addhabit Nama Kebiasaan` ");

            

            db[userId].push({ name: habitName, streak: 0, lastDone: null });

            saveDb(db);

            return bot.sendMessage(chatId, `✔ sᴜᴄᴄᴇs ᴀᴅᴅ: ${habitName}`);

        }

        // 2. CENTANG HABIT SELESAI (/done)

        if (command === 'done') {

            if (db[userId].length === 0) return bot.sendMessage(chatId, "Belum ada habit. Buat dengan /addhabit");

            

            const habitIndex = parseInt(args[1]) - 1;

            if (isNaN(habitIndex) || !db[userId][habitIndex]) {

                let list = "📝 ᴘɪʟɪʜ ɴᴏᴍᴏʀ ʏᴀɴɢ sᴜᴅᴀʜ sᴇʟᴇsᴀɪ:\n";

                db[userId].forEach((h, i) => {

                    list += `${i + 1}. ${h.lastDone === today ? "✅" : "⏳"} ${h.name}\n`;

                });

                return bot.sendMessage(chatId, list + "\nᴋᴇᴛɪᴋ: `/done [nomor]`");

            }

            if (db[userId][habitIndex].lastDone === today) return bot.sendMessage(chatId, "✔ ᴀʟʜᴀᴍᴅᴜʟɪʟʟᴀʜ ᴋᴇʟᴀʀ ʟᴇᴋᴋ");

            

            db[userId][habitIndex].streak += 1;

            db[userId][habitIndex].lastDone = today;

            saveDb(db);

            return bot.sendMessage(chatId, `⚡︎ sᴇʟᴇsᴀɪ ᴄᴜʏ ᴀʟʜᴀᴍᴅᴜʟɪʟʟᴀʜ: ${db[userId][habitIndex].streak} Hari.`);

        }

        // 3. CEK PROGRESS (/cekhabit) - FORMAT SESUAI PERMINTAAN

        if (command === 'cekhabit' || command === 'habit') {

            let progress = "";

            if (db[userId].length === 0) {

                progress = "Belum ada habit yang tercatat.";

            } else {

                db[userId].forEach((h, i) => {

                    const status = h.lastDone === today ? "✔" : "✘";

                    progress += `${i + 1}. ${status} ${h.name} (${h.streak} Hari)\n`;

                });

            }

            const response = `

📊 𝙆𝙀𝙂𝙄𝘼𝙏𝘼𝙉 𝙆𝙀𝙎𝙀𝙃𝘼𝙏𝘼𝙉

<pre>

${progress}

--------------------------------

List Perintah:

• /addhabit [nama] - Tambah habit

• /delhabit [no]   - Hapus habit

• /done [nomor]    - Centang habit

• /cekhabit    - Cek daftar kegiatan

--------------------------------

</pre>

            `;

            return bot.sendMessage(chatId, response, { parse_mode: 'HTML' });

        }

        // 4. HAPUS HABIT (/delhabit)

        if (command === 'delhabit') {

            const index = parseInt(args[1]) - 1;

            if (isNaN(index) || !db[userId][index]) return bot.sendMessage(chatId, "ᴄᴏɴᴛᴏʜ: `/delhabit 1` ");

            

            db[userId].splice(index, 1);

            saveDb(db);

            return bot.sendMessage(chatId, "☢︎ ᴅᴀғᴛᴀʀ ᴋᴇsᴇʜᴀᴛᴀɴ ᴅɪ ʜᴀᴘᴜs.");

        }

    }

};