// cases/getid.js (FITUR BARU: Mendapatkan Chat ID dari Username)

module.exports = {
    keyword: 'id', 
    keywordAliases: ['/id'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        // Ambil argumen setelah /id, lalu hapus '@' (jika ada)
        const args = msg.text.slice(msg.entities[0].length).trim().replace(/^@/, '');
        



        if (!args) {
            // Jika tidak ada argumen, kembalikan ID chat saat ini
            const currentChatId = msg.chat.id;
            const response = 
                `🆔 **ID Chat Saat Ini:** \`${currentChatId}\`\n\n` +
                `Gunakan format: \`/id [username_grup]\` untuk mencari ID lain.`;
                
            return bot.sendMessage(chatId, response, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        // --- Proses Pencarian ID Berdasarkan Username ---
        const targetUsername = `@${args}`; // Tambahkan '@' kembali untuk pencarian API
        
        let responseMessage = ``;
        
        try {
            // Gunakan metode getChat untuk mencari info chat berdasarkan username
            const targetChat = await bot.getChat(targetUsername);

            if (targetChat && targetChat.id) {
                
                let chatType = targetChat.type.toUpperCase();
                
                // Kustomisasi nama grup/channel
                let chatTitle = targetChat.title || targetChat.username;
                
                // Kustomisasi tipe channel/supergroup/private
                if (targetChat.type === 'channel') chatType = 'CHANNEL PUBLIK';
                if (targetChat.type === 'supergroup') chatType = 'SUPERGROUP';
                if (targetChat.type === 'group') chatType = 'GRUP LAMA';


                responseMessage = 
                    `✅ **ID Ditemukan!**\n\n` +
                    `*Username:* ${targetUsername}\n` +
                    `*Nama Chat:* ${chatTitle}\n` +
                    `*Tipe:* ${chatType}\n\n` +
                    `*ID NUMERIK:* \n\`${targetChat.id}\``;
                
                // Note: Jika channel ID dimulai dengan -100, itu adalah ID yang valid untuk broadcast
            } else {
                 responseMessage = `✘ ᴜsᴇʀɴᴀᴍᴇ ᴛɪᴅᴀᴋ ᴅᴀᴘᴀᴛ ᴅɪ ᴛᴇᴍᴜᴋᴀɴ`;
            }

        } catch (error) {
            console.error(`Gagal mendapatkan chat ID untuk ${targetUsername}:`, error.message);
            
            // Tangkap error umum API Telegram (400 Bad Request: chat not found)
            if (error.response && error.response.body && error.response.body.description.includes('chat not found')) {
                responseMessage = `✘ ᴘᴀsᴛɪᴋᴀɴ ᴜsᴇʀɴᴀᴍᴇ ɢʀᴜʙ ʙᴇɴᴀʀ.`;
            } else {
                 responseMessage = `✘ ᴋᴇsᴀʟᴀʜᴀɴ sᴀᴀᴛ ᴍᴇɴᴄᴀʀɪ ɪᴅ ɢʀᴜʙ/ᴄʜᴀɴɴᴇʟ.`;
            }
        }
        
        await bot.sendMessage(chatId, responseMessage, { 
            parse_mode: 'Markdown',
            reply_to_message_id: msg.message_id 
        });
    }
};