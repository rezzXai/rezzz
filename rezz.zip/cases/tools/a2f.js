// /cases/a2f.js (REVISI MENGGUNAKAN global.isOwner() DAN isAllowed())

const { TOTP } = require('otpauth');
const { isAllowed } = require('../../lib/a2f_db'); // <-- Import fungsi DB

module.exports = {
    keyword: 'a2f', 
    keywordAliases: ['_', '/2fa'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const args = msg.text.slice(msg.entities[0].length).trim().toUpperCase().replace(/ /g, '');
        
        // --- 1. Cek Akses Pengguna (Owner & Whitelisted Users) ---
        
        // PENTING: Gunakan global.isOwner() dari rezz.js untuk cek Owner
        const isOwner = typeof global.isOwner === 'function' ? global.isOwner(userId) : false;
        
        // Cek jika BUKAN Owner DAN BUKAN Whitelisted
        if (!isOwner && !isAllowed(userId)) {
             return bot.sendMessage(chatId, 
                "**✘ 𝘼𝘾𝘾𝙀𝙎 𝙉𝙊𝙏 𝙁𝙊𝙐𝙉𝘿.**\n\nAnda tidak memiliki izin untuk menggunakan perintah ini.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 2. Validasi Secret ---
        if (!args || args.length < 16) {
            return bot.sendMessage(chatId, 
                " **✘ 𝙎𝘼𝙇𝘼𝙃 𝙊𝙈 𝙆𝙐𝙐.**\n\n" +
                "𝙣𝙜𝙚𝙣𝙚 𝙤𝙢 𝙠𝙪: `/a2f [Kunci Rahasia]`\n" +
                "𝙘𝙤𝙣𝙩𝙤𝙝: `/a2f CTD26OOSAY57UQWA4KM4Q4KC7IIHWDPZ`", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        const secretBase32 = args;
        
        try {
            // --- 3. Hitung Kode 2FA (Sama seperti sebelumnya) ---
            const totp = new TOTP({
                secret: secretBase32, 
                digits: 6,
                period: 30,
                algorithm: 'SHA1',
            });

            const token = totp.generate();
            // Hitung sisa waktu dengan lebih akurat
            const remainingTime = Math.ceil(totp.period - (Date.now() / 1000 % totp.period));

            const response = 
                `🔑 **Kode Autentikasi 2FA Anda:**\n\n` +
                `\`${token}\`\n\n` +
                `*Kode ini berlaku selama ${remainingTime} detik (dan akan dihapus untuk keamanan).*\n\n` +
                `**PERHATIAN:** Jangan bagikan kode ini kepada siapapun.`;
            
            // --- 4. Kirim Pesan dan Simpan ID-nya ---
            const sentMessage = await bot.sendMessage(chatId, response, {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id 
            });

            // --- 5. Atur Timer Penghapusan Pesan ---
            const deletionDelay = remainingTime * 1000 + 1000; // Tambah 1 detik buffer
            
            setTimeout(async () => {
                const expiredNotice = `[🗑️] Kode 2FA untuk *${secretBase32.substring(0, 4)}...* telah **kedaluwarsa** dan pesan aslinya telah dihapus.`;
                
                try {
                    await bot.deleteMessage(chatId, sentMessage.message_id);
                } catch (e) { /* ignore error */ }

                await bot.sendMessage(chatId, expiredNotice, { parse_mode: 'Markdown' });
                
            }, deletionDelay); 

        } catch (error) {
            console.error(`🔴 Error saat menghitung 2FA: ${error.message}`);
            await bot.sendMessage(chatId, 
                "❌ **Error:** Gagal menghitung kode 2FA. Pastikan Secret Base32 yang Anda masukkan sudah benar.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};