const axios = require('axios');

module.exports = {

    keyword: 'short',

    keywordAliases: ['shortlink', 'pendekkan', '/short'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const text = msg.text || "";

        const args = text.split(' ');

        // 1. Validasi: Apakah user memasukkan link?

        if (args.length < 2) {

            return bot.sendMessage(chatId, 

                "✘ <b>𝙎𝘼𝙇𝘼𝙃 𝙊𝙈</b>\n\n" +

                "Gunakan format: <code>/short [link]</code>\n" +

                "Contoh: <code>/short https://google.com</code>", 

                { parse_mode: 'HTML' }

            );

        }

        const urlAsli = args[1];

        // 2. Validasi: Apakah format link benar (harus diawali http/https)?

        const urlPattern = /^(http|https):\/\/[^ "]+$/;

        if (!urlPattern.test(urlAsli)) {

            return bot.sendMessage(chatId, "❌ <b>Link Tidak Valid!</b>\nPastikan link diawali dengan <code>http://</code> atau <code>https://</code>", { parse_mode: 'HTML' });

        }

        // Kirim status "typing" agar bot terlihat sedang memproses

        bot.sendChatAction(chatId, 'typing');

        try {

            // 3. Eksekusi Shorten Link menggunakan API TinyURL

            // Timeout diset 10 detik agar bot tidak menunggu selamanya jika server lambat

            const response = await axios.get(`https://tinyurl.com/api-create.php?url=${encodeURIComponent(urlAsli)}`, {

                timeout: 10000 

            });

            const linkPendek = response.data;

            // 4. Kirim Hasil ke User

            let caption = `

✔ <b>LINK BERHASIL DIPENDEKKAN</b>

━━━━━━━━━━━━━━━━━━

🔗 <b>Link Asli:</b>

<pre>${urlAsli}</pre>

🚀 <b>Link Pendek:</b>

<code>${linkPendek}</code>

━━━━━━━━━━━━━━━━━━

<i>Silakan salin link di atas!</i>

            `;

            return bot.sendMessage(chatId, caption, { 

                parse_mode: 'HTML',

                disable_web_page_preview: true // Agar tidak muncul preview link asli yang besar

            });

        } catch (error) {

            // 5. Penanganan Eror (Error Handling)

            console.error("Shortlink Error:", error.message);

            

            let errMsg = "❌ <b>Terjadi Kesalahan!</b>\n";

            if (error.code === 'ECONNABORTED') {

                errMsg += "Server pemendek link terlalu lama merespon (Timeout).";

            } else {

                errMsg += "Gagal menghubungi server. Pastikan link bisa diakses atau coba lagi nanti.";

            }

            return bot.sendMessage(chatId, errMsg, { parse_mode: 'HTML' });

        }

    }

};