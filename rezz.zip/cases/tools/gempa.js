const axios = require('axios');

module.exports = {

    keyword: 'gempa',

    keywordAliases: ['infogempa', 'bmkg'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        try {

            // Mengambil data dari XML BMKG dan dikonversi ke JSON melalui API gratis

            const response = await axios.get('https://data.bmkg.go.id/DataMKG/TEWS/autogempa.json');

            const gempa = response.data.Infogempa.gempa;

            const caption = `

⚠️ **INFO GEMPA TERKINI** ⚠️

📅 **Tanggal**: ${gempa.Tanggal}

🕒 **Waktu**: ${gempa.Jam}

📏 **Magnitudo**: ${gempa.Magnitude} SR

📉 **Kedalaman**: ${gempa.Kedalaman}

📍 **Lokasi**: ${gempa.Wilayah}

🧭 **Koordinat**: ${gempa.Coordinates}

🌊 **Potensi**: ${gempa.Potensi}

📢 *Sumber: BMKG Indonesia*

`.trim();

            // Link gambar peta pusat gempa dari BMKG

            const petaGempa = `https://data.bmkg.go.id/DataMKG/TEWS/${gempa.Shakemap}`;

            // Kirim gambar beserta detail teksnya

            await bot.sendPhoto(chatId, petaGempa, { 

                caption: caption,

                parse_mode: 'Markdown' 

            });

        } catch (e) {

            console.error(`🔴 Error BMKG: ${e.message}`);

            bot.sendMessage(chatId, "❌ Gagal mengambil data dari server BMKG. Silakan coba lagi nanti.");

        }

    }

};