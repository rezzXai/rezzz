// cases/tourl.js (REVISI: Mendukung MP3 & Voice Note)

const axios = require('axios');
const FormData = require('form-data');
const settings = require('../../setting'); 

module.exports = {
    keyword: 'tourl',
    keywordAliases: ['/tourl'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const reply = msg.reply_to_message;
        let waitMessageId = null; 
        
        // --- 1. Validasi Reply Pesan ---
        if (!reply) {
            return bot.sendMessage(chatId, 
                '✘ ᴘᴀsᴛɪᴋᴀɴ ᴀɴᴅᴀ ᴍᴇʀᴇᴘʟᴀʏ ɢᴀᴍʙᴀʀ, ᴠɪᴅᴇᴏ, ᴀᴜᴅɪᴏ, ᴀᴛᴀᴜ ғɪʟᴇ', 
                { reply_to_message_id: msg.message_id, parse_mode: 'Markdown' });
        }
        
        let fileId;
        let fileName;
        let mimeType;
        
        // --- 2. Dapatkan File ID berdasarkan Tipe Media ---
        if (reply.photo) {
            const fileObject = reply.photo[reply.photo.length - 1]; 
            fileId = fileObject.file_id;
            fileName = `${fileId}.jpg`;
            mimeType = 'image/jpeg';
        } else if (reply.video) {
            fileId = reply.video.file_id;
            fileName = reply.video.file_name || `${fileId}.mp4`;
            mimeType = reply.video.mime_type || 'video/mp4';
        } else if (reply.audio) { // <--- TAMBAHAN UNTUK MP3/AUDIO
            fileId = reply.audio.file_id;
            fileName = reply.audio.file_name || `${fileId}.mp3`;
            mimeType = reply.audio.mime_type || 'audio/mpeg';
        } else if (reply.voice) { // <--- TAMBAHAN UNTUK VOICE NOTE
            fileId = reply.voice.file_id;
            fileName = `${fileId}.ogg`;
            mimeType = reply.voice.mime_type || 'audio/ogg';
        } else if (reply.document) {
            fileId = reply.document.file_id;
            fileName = reply.document.file_name || `${fileId}.file`;
            mimeType = reply.document.mime_type || 'application/octet-stream';
        } else {
            return bot.sendMessage(chatId, 
                '✘ Format media tidak didukung. Kirim/Reply Gambar, Video, atau Audio.', 
                { reply_to_message_id: msg.message_id, parse_mode: 'Markdown' });
        }
        
        if (!fileId) {
             return bot.sendMessage(chatId, 
                `✘ ɢᴀɢᴀʟ sᴀᴀᴛ ᴍᴇɴɢᴜʙᴀʜ [ᴋɪʀɪᴍ ᴜʟᴀɴɢ].`, 
                { reply_to_message_id: msg.message_id, parse_mode: 'Markdown' });
        }
        
        await bot.sendChatAction(chatId, 'upload_document'); 

        try {
            const waitMessage = await bot.sendMessage(chatId, 
                `⏳ ᴘʀᴏsᴇs ᴘᴇɴᴄᴇᴛᴀᴋᴀɴ ᴜʀʟ....`, 
                { reply_to_message_id: msg.message_id, parse_mode: 'Markdown' });
            waitMessageId = waitMessage.message_id;
        } catch (e) {
            console.error("🔴 Gagal mengirim pesan tunggu: ", e.message);
        }

        try {
            // --- A. Unduh Media dari Telegram ---
            const fileLink = await bot.getFileLink(fileId);
            const { data: mediaBuffer } = await axios.get(fileLink, { responseType: 'arraybuffer' });
            
            // --- B. Unggah Media ke Catbox.moe ---
            const formData = new FormData();
            formData.append('reqtype', 'fileupload');
            formData.append('fileToUpload', mediaBuffer, {
                filename: fileName, 
                contentType: mimeType, 
            });

            const uploadResponse = await axios.post(settings.CATBOX_API_URL || 'https://catbox.moe/user/api.php', formData, {
                headers: formData.getHeaders(),
                timeout: 120000 // Ditambah jadi 2 menit untuk file audio/video besar
            });
            
            const catboxUrl = uploadResponse.data.trim(); 

            if (!catboxUrl || !catboxUrl.startsWith('http')) {
                throw new Error(`Respons Catbox tidak valid: ${catboxUrl}`);
            }
            
            // --- C. Kirim URL Hasil ke Pengguna ---
            const responseText = 
                `✅ **Media Berhasil Diunggah!**\n` +
                `----------------------------------------\n` +
                `🏷️ **Tipe:** \`${mimeType}\`\n` +
                `🔗 **URL:** [Klik Disini](${catboxUrl})\n\n` +
                `\`${catboxUrl}\``;
            
            if (waitMessageId) {
                try {
                    await bot.editMessageText(responseText, {
                        chatId: chatId,
                        messageId: waitMessageId,
                        parse_mode: 'Markdown',
                        disable_web_page_preview: false
                    });
                } catch (e) {
                    bot.sendMessage(chatId, responseText, { reply_to_message_id: msg.message_id, parse_mode: 'Markdown' });
                }
            } else {
                 bot.sendMessage(chatId, responseText, { reply_to_message_id: msg.message_id, parse_mode: 'Markdown' });
            }

        } catch (error) {
            console.error(`🔴 Error dalam /tourl:`, error.message);
            const errorMsg = `❌ **Gagal Mengunggah:** ${error.message.includes('400') ? 'File terlalu besar' : 'Terjadi gangguan koneksi'}.`;
            
            if (waitMessageId) {
                bot.editMessageText(errorMsg, { chatId, messageId: waitMessageId, parse_mode: 'Markdown' }).catch(() => {});
            } else {
                bot.sendMessage(chatId, errorMsg, { parse_mode: 'Markdown' });
            }
        }
    }
};