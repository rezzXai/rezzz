const axios = require('axios');

module.exports = {

    keyword: 'cuaca',

    keywordAliases: ['weather', 'cekcuaca'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const args = msg.text.trim().split(/\s+/);

        if (args.length < 2) {

            return bot.sendMessage(chatId, "✘ Format: <code>/cuaca Jakarta</code>", { parse_mode: 'HTML' });

        }

        const city = args.slice(1).join(' ');

        const loadingMsg = await bot.sendMessage(chatId, `🔍 <i>Memantau ${city}...</i>`, { parse_mode: 'HTML' });

        try {

            const response = await axios.get(`https://wttr.in/${encodeURIComponent(city)}?format=j1`);

            const data = response.data;

            const current = data.current_condition[0];

            const area = data.nearest_area[0];

            // --- Logika Waktu WIB (UTC+7) ---

            const date = new Date();

            const wib = new Date(date.getTime() + (7 * 60 * 60 * 1000));

            const jamWib = wib.toISOString().replace('T', ' ').substring(0, 16) + " WIB";

            const weatherText = `

🌍 <b>𝗖𝗨𝗔𝗖𝗔: ${area.areaName[0].value.toUpperCase()}</b>

<code>∘ Status : ${current.weatherDesc[0].value}</code>

<code>∘ Suhu   : ${current.temp_C}°C (${current.FeelsLikeC}°C)</code>

<code>∘ Lembap : ${current.humidity}%</code>

<code>∘ Angin  : ${current.windspeedKmph} km/h</code>

🕒 <b>${jamWib}</b>`.trim();

            await bot.sendMessage(chatId, weatherText, { 

                parse_mode: 'HTML',

                reply_to_message_id: msg.message_id 

            });

            setTimeout(() => {

                bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

            }, 1000);

        } catch (e) {

            bot.editMessageText("❌ Kota tidak ditemukan.", {

                chat_id: chatId,

                message_id: loadingMsg.message_id

            });

        }

    }

};