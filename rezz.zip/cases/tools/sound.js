const googleTTS = require('google-tts-api');

module.exports = {

    keyword: 'soundmp3',

    keywordAliases: ['/soundmp3', 'sound'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const text = msg.text.split(' ').slice(1).join(' ');

        if (!text) {

            return bot.sendMessage(chatId, "✘ Silakan masukkan pesan setelah command.\nContoh: `/soundmp3 Halo kak, selamat belanja!`", { parse_mode: 'Markdown' });

        }

        if (text.length > 200) {

            return bot.sendMessage(chatId, "⚠️ Pesan terlalu panjang, maksimal 200 karakter.");

        }

        try {

            // Memberikan notifikasi bahwa bot sedang merekam suara

            await bot.sendChatAction(chatId, 'upload_voice');

            // Mendapatkan URL audio dari Google TTS (Bahasa Indonesia)

            const url = googleTTS.getAudioUrl(text, {

                lang: 'id',

                slow: false,

                host: 'https://translate.google.com',

            });

            // Mengirim sebagai Voice Note (.ogg/voice)

            // Jika ingin dikirim sebagai file MP3 biasa, ganti sendVoice menjadi sendAudio

            await bot.sendVoice(chatId, url);

        } catch (error) {

            console.error("Error SoundMP3:", error);

            bot.sendMessage(chatId, "✘ Gagal memproses suara. Coba lagi nanti.");

        }

    }

};