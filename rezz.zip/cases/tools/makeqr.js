// cases/makeqr.js (Pembuatan Kode QR - FIXED: Menggunakan URL Unduhan untuk Media)

const QRCode = require('qrcode');
const fs = require('fs');
const path = require('path');

// Folder sementara untuk menyimpan gambar QR
const TEMP_DIR = path.join(__dirname, '..', 'temp');

// Pastikan folder temp ada
if (!fs.existsSync(TEMP_DIR)){
    fs.mkdirSync(TEMP_DIR);
}

module.exports = {
    keyword: 'makeqr',
    keywordAliases: ['/makeqr', '/qrgen'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const repliedMsg = msg.reply_to_message;
        const args = msg.text.split(' ').slice(1).join(' ').trim();
        let qrData = '';
        let mediaType = ''; // Untuk caption

        const waitMessage = await bot.sendMessage(chatId, `⏳ Mempersiapkan data untuk Kode QR...`, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });

        // 1. Tentukan data apa yang akan dimasukkan ke dalam Kode QR
        try {
            if (args) {
                // Data diambil dari argumen yang diketik pengguna (Teks/Link)
                qrData = args;
                mediaType = 'Teks/Link';
            } else if (repliedMsg) {
                // Cek jika reply adalah teks
                if (repliedMsg.text) {
                    qrData = repliedMsg.text;
                    mediaType = 'Teks Pesan';
                } 
                // Cek jika reply adalah media (Foto, Video, Dokumen, Audio)
                else if (repliedMsg.photo || repliedMsg.video || repliedMsg.document || repliedMsg.audio) {
                    
                    const media = repliedMsg.photo ? repliedMsg.photo[repliedMsg.photo.length - 1] : 
                                  (repliedMsg.video || repliedMsg.document || repliedMsg.audio);
                    
                    if (!media || !media.file_id) {
                        throw new Error("File ID tidak ditemukan pada media yang di-reply.");
                    }

                    // *** INI LOGIKA PENTINGNYA: AMBIL URL UNDUHAN ***
                    qrData = await bot.getFileLink(media.file_id); 
                    // Tipe media
                    if (repliedMsg.photo) mediaType = 'Foto (URL Unduhan)';
                    else if (repliedMsg.video) mediaType = 'Video (URL Unduhan)';
                    else mediaType = 'File Media (URL Unduhan)';

                }
            }
            
            // Jika data tidak ditemukan setelah semua pengecekan
            if (!qrData) {
                await bot.deleteMessage(chatId, waitMessage.message_id).catch(() => {});
                return bot.sendMessage(chatId, 
                    "❌ **Format Salah.** Anda harus memberikan data atau me-*reply* pesan/media:\n" +
                    "Contoh:\n" +
                    "1. `/makeqr linkanda.com`\n" +
                    "2. `/makeqr` (sambil *reply* ke teks/gambar)", 
                    { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }

        } catch (error) {
            console.error(`🔴 Error saat mendapatkan link file: ${error.message}`);
            await bot.deleteMessage(chatId, waitMessage.message_id).catch(() => {});
            return bot.sendMessage(chatId, 
                `❌ **Gagal Mengolah File.** Pastikan bot memiliki izin untuk mengakses link file tersebut. Error: ${error.message}`, 
                { reply_to_message_id: msg.message_id });
        }


        // Lanjutkan proses pembuatan QR
        await bot.editMessageText(`⏳ Membuat Kode QR dari ${mediaType}...`, {
             chat_id: chatId,
             message_id: waitMessage.message_id,
             parse_mode: 'Markdown'
        });
        
        let tempFilePath = '';

        try {
            // 2. Buat Kode QR sebagai file PNG sementara
            const fileName = `qr_${Date.now()}.png`;
            tempFilePath = path.join(TEMP_DIR, fileName);
            
            // Konversi data (yang kini berupa URL unduhan atau teks) menjadi Kode QR
            await QRCode.toFile(tempFilePath, qrData, {
                width: 512,
                margin: 2,
                color: {
                    dark: '#000000ff',  
                    light: '#ffffffff'
                }
            });
            
            // 3. Kirim Gambar Kode QR
            const displayData = qrData.length > 200 ? qrData.substring(0, 200) + '...' : qrData;

            const caption = 
                `✅ **Kode QR Berhasil Dibuat!**\n\n` +
                `*Jenis Data:* ${mediaType}\n` +
                `*Data yang Terenkripsi:* \`${displayData}\``;

            await bot.sendPhoto(chatId, tempFilePath, {
                caption: caption,
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id
            });

            // 4. Hapus pesan tunggu
            await bot.deleteMessage(chatId, waitMessage.message_id).catch(() => {});

        } catch (error) {
            console.error(`🔴 Error saat membuat/mengirim QR Code: ${error.message}`);
            
            // Edit pesan tunggu menjadi pesan error
             if (waitMessage && waitMessage.message_id) {
                 await bot.editMessageText(`❌ **Gagal Membuat QR Code.** Error: ${error.message}`, {
                    chat_id: chatId,
                    message_id: waitMessage.message_id,
                    parse_mode: 'Markdown'
                });
            } else {
                bot.sendMessage(chatId, `❌ **Gagal Membuat QR Code.** Coba lagi.`, { reply_to_message_id: msg.message_id });
            }
        
        } finally {
            // 5. Hapus file sementara
            if (fs.existsSync(tempFilePath)) {
                fs.unlinkSync(tempFilePath);
            }
        }
    }
};