// cases/quiz.js (FIX ERROR - Menggunakan Data Lokal untuk Stabilitas)

const settings = require('../../setting'); 

// === DATA PERTANYAAN (Dibuat Lokal untuk menghindari error require) ===
const riddles = [
    { question: "Hewan apa yang bersaudara?", answer: "katak" },
    { question: "Apa yang selalu datang tapi tidak pernah tiba?", answer: "besok" },
    { question: "Apa yang ada di ujung langit?", answer: "huruf t" },
    { question: "Kalau disiram malah mati. Apakah itu?", answer: "api" },
    { question: "Saya punya 4 jari, 1 ibu jari. Siapakah saya?", answer: "sarung tangan" },
    { question: "Kenapa hantu tidak boleh menikah?", answer: "karena suka menghantui" },
    { question: "Gajah apa yang belalainya pendek?", answer: "gajah duduk" },
];

if (!global.tebakKataGames) {
    global.tebakKataGames = {};
}

const GAME_DURATION = 5 * 60 * 1000; // 5 Menit
const normalizeAnswer = (text) => {
    // Normalisasi jawaban: lowercase dan menghilangkan spasi/karakter non-alphanumeric
    return text.toLowerCase().replace(/[^a-z0-9\s]/g, '').replace(/\s/g, '');
};

// ===================================================

module.exports = {
    keyword: 'quiz',
    keywordAliases: ['/kuis'], 
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        if (!Array.isArray(riddles) || riddles.length === 0) {
             return bot.sendMessage(chatId, '❌ Maaf, data kuis kosong.', { reply_to_message_id: msg.message_id });
        }
        
        if (global.tebakKataGames[chatId]) {
            return bot.sendMessage(chatId, '⚠️ Permainan sudah berjalan. Jawab pertanyaan sebelumnya dulu!', { reply_to_message_id: msg.message_id });
        }
        
        // Logika Pengacakan
        const randomIndex = Math.floor(Math.random() * riddles.length);
        const selectedRiddle = riddles[randomIndex];
        
        const puzzleText = `
🧠 **QUIZ TEBAK KATA!** (5 Menit)

*Pertanyaan:*
${selectedRiddle.question}

*Petunjuk:*
1. Balas pesan ini dengan jawaban Anda.
2. Jika tidak tahu, balas pesan ini dengan kata \`nyerah\`.
        `;

        try {
            const sentMessage = await bot.sendMessage(chatId, puzzleText, { parse_mode: 'Markdown' });
            const messageId = sentMessage.message_id;

            const timeout = setTimeout(async () => {
                if (global.tebakKataGames[chatId]) {
                    await bot.sendMessage(chatId, `⌛ Waktu habis! Jawabannya: **${selectedRiddle.answer.toUpperCase()}**`, { parse_mode: 'Markdown', reply_to_message_id: messageId });
                    delete global.tebakKataGames[chatId];
                }
            }, GAME_DURATION);

            // Menyimpan state
            global.tebakKataGames[chatId] = {
                answer: normalizeAnswer(selectedRiddle.answer),
                riddleText: selectedRiddle.question,
                messageId: messageId,
                timeout: timeout,
            };

        } catch (e) {
            console.error(`🔴 [QUIZ ERROR] Gagal memulai game: ${e.message}`);
            bot.sendMessage(chatId, '❌ Gagal memulai quiz. Cek konsol bot.');
        }
    },

    // --- LOGIKA TEXT HANDLER UNTUK MENJAWAB ---
    textHandler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        if (!msg.reply_to_message || !msg.text) return;
        
        const repliedMessageId = msg.reply_to_message.message_id;

        if (global.tebakKataGames[chatId] && global.tebakKataGames[chatId].messageId === repliedMessageId) {
            
            const game = global.tebakKataGames[chatId];
            const rawUserGuess = msg.text.trim();
            const userGuess = normalizeAnswer(rawUserGuess);

            // A. LOGIKA NYERAH
            if (rawUserGuess.toLowerCase() === 'nyerah') {
                clearTimeout(game.timeout); 
                
                // Cari jawaban asli di array riddles
                const originalRiddle = riddles.find(r => normalizeAnswer(r.answer) === game.answer);
                const originalAnswer = originalRiddle ? originalRiddle.answer.toUpperCase() : "Jawaban tidak ditemukan.";

                await bot.sendMessage(chatId, 
                    `😓 Anda menyerah! Jawaban dari "${game.riddleText}" adalah: **${originalAnswer}**.\n\nKetik \`/kuis\` untuk bermain lagi.`, 
                    { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
                );
                
                delete global.tebakKataGames[chatId];
                return;
            }

            // B. LOGIKA JAWABAN BENAR
            if (userGuess === game.answer) {
                clearTimeout(game.timeout); 
                const winnerName = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
                
                await bot.sendMessage(chatId, `🎉 **SELAMAT!** ${winnerName} berhasil menjawab!`, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
                
                delete global.tebakKataGames[chatId];
            
            // C. LOGIKA JAWABAN SALAH
            } else {
                 await bot.sendMessage(chatId, `❌ Jawaban salah!! Silakan tebak lagi.`, { reply_to_message_id: msg.message_id });
            }
        }
    }
};