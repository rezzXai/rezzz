// cases/ping.js (FINAL FIX: DIKEMBALIKAN KE 3 ARGUMEN)

const os = require('os'); // Library bawaan Node.js untuk informasi sistem

// Fungsi untuk format ukuran byte ke GB/MB
function formatBytes(bytes) {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
}

module.exports = {
    keyword: '/ping', 
    // PERBAIKAN KRITIS: Mengembalikan ke 3 argumen (bot, msg, settings)
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        const startTime = Date.now(); // Catat waktu mulai perintah
    
        // --- 1. Kumpulkan Data Sistem ---
        
        // Informasi RAM
        const totalMem = os.totalmem();
        const freeMem = os.freemem();
        const usedMem = totalMem - freeMem;
        const uptime = os.uptime(); // Uptime sistem (detik)
    
        // Konversi uptime ke format Dd Hh Mm Ss
        const days = Math.floor(uptime / (3600 * 24));
        const hours = Math.floor((uptime % (3600 * 24)) / 3600);
        const minutes = Math.floor((uptime % 3600) / 60);
        const seconds = Math.floor(uptime % 60);
    
        // --- 2. Hitung Latensi (VPS Speed) ---
        const pingMsg = await bot.sendMessage(chatId, '```... Analysing Server Trace ...```', { parse_mode: 'Markdown' });
        const latency = Date.now() - startTime; 
        
        const telegramLatency = Date.now() - pingMsg.date * 1000;
        
        // --- 3. Buat Teks Respons (Gaya Hacker) ---
        const responseText = 
            `
 **𝗔𝗡𝗔𝗟𝗜𝗦𝗜𝗦 ♲︎**
    
\`\`\`bash
# SYSTEM INFORMATION 
    
  SERVER UPTIME : ${days}d ${hours}h ${minutes}m ${seconds}s
  CPU MODEL     : ${os.cpus()[0].model}
    
# MEMORY ALLOCATION (RAM)
    
  TOTAL RAM     : ${formatBytes(totalMem)}
  USED RAM      : ${formatBytes(usedMem)}
  FREE RAM      : ${formatBytes(freeMem)}
    
# NETWORK LATENCY
    
  PING TIME     : ${latency} ms
  TELEGRAM API  : ${telegramLatency} ms
\`\`\`
    
---
*sʏsᴛᴇᴍ ᴏᴘᴇʀᴀᴛɪᴏɴᴀʟ sᴜᴄᴄᴇs ♀*
            `;
    
        // 4. Edit pesan pingMsg dengan hasil akhir
        try {
            await bot.editMessageText(responseText, {
                chat_id: chatId,
                message_id: pingMsg.message_id,
                parse_mode: 'Markdown'
            });
        } catch (error) {
            console.error("Gagal mengedit pesan ping:", error.message);
            bot.sendMessage(chatId, responseText, { parse_mode: 'Markdown' });
        }
    }
};