const fs = require('fs');

const path = require('path');

const rewardPath = path.join(__dirname, '../../data/rewards.json');

const userAbsenPath = path.join(__dirname, '../../data/user_absen.json');

if (!fs.existsSync(path.join(__dirname, '../../data'))) {

    fs.mkdirSync(path.join(__dirname, '../../data'), { recursive: true });

}

if (!fs.existsSync(rewardPath)) {

    fs.writeFileSync(rewardPath, JSON.stringify({ "1": null, "2": null, "3": null }));

}

if (!fs.existsSync(userAbsenPath)) {

    fs.writeFileSync(userAbsenPath, JSON.stringify({}));

}

const getData = (p) => JSON.parse(fs.readFileSync(p));

const saveData = (p, d) => fs.writeFileSync(p, JSON.stringify(d, null, 2));

module.exports = {

    keyword: 'absen',

    keywordAliases: ['addreward', '/absen', '/addreward', 'cek_progress'],

    handler: async (bot, msg, settings) => {

        // PERBAIKAN: Pastikan ID diambil dengan benar baik dari pesan teks atau tombol

        const isCallback = !!msg.callbackQuery;

        const from = isCallback ? msg.callbackQuery.from : msg.from;

        const chatId = isCallback ? msg.callbackQuery.message.chat.id : msg.chat.id;

        const userId = String(from.id); // Konversi ke String agar konsisten di JSON

        

        const isOwner = global.isOwner(from.id);

        const callbackData = isCallback ? msg.callbackQuery.data : "";

        const text = msg.text || "";

        const args = text.split(' ');

        const command = isCallback ? callbackData : args[0].toLowerCase().replace('/', '');

        let rewards = getData(rewardPath);

        let userDb = getData(userAbsenPath);

        // --- 1. LOGIKA OWNER: TAMBAH REWARD ---

        if (command === 'addreward') {

            if (!isOwner) return;

            const slot = args[1]; 

            if (!['1', '2', '3'].includes(slot)) {

                return bot.sendMessage(chatId, "<pre>⚠️ Setup Hadiah:\n1: Absen x3\n2: Absen x5\n3: Absen x7</pre>", { parse_mode: 'HTML' });

            }

            if (!msg.reply_to_message) return bot.sendMessage(chatId, "<pre>⚠️ Balas file hadiahnya!</pre>", { parse_mode: 'HTML' });

            const reply = msg.reply_to_message;

            let type = 'text', content = reply.text, fileId = null;

            if (reply.document) { type = 'doc'; fileId = reply.document.file_id; }

            else if (reply.photo) { type = 'img'; fileId = reply.photo[reply.photo.length - 1].file_id; }

            else if (reply.video) { type = 'vid'; fileId = reply.video.file_id; }

            rewards[slot] = { type, content: fileId || content, name: args.slice(2).join(' ') || "Reward" };

            saveData(rewardPath, rewards);

            return bot.sendMessage(chatId, `<pre>✅ Hadiah Slot ${slot}\nBerhasil di-update!</pre>`, { parse_mode: 'HTML' });

        }

        // --- 2. LOGIKA CEK PROGRESS (TOMBOL) ---

        if (command === 'cek_progress') {

            // Mengambil data berdasarkan userId yang sudah di-string-kan

            const dataUser = userDb[userId] || { count: 0, lastDate: null };

            const streak = dataUser.count;

            let next = "MAX";

            if (streak < 3) next = "3";

            else if (streak < 5) next = "5";

            else if (streak < 7) next = "7";

            

            let progressText = `<pre>📊 YOUR PROGRESS\n━━━━━━━━━━━━━━━\nUser : ${from.first_name}\nStreak : ${streak} Hari\nNext   : ${next} Hari\n━━━━━━━━━━━━━━━\nStatus : ${streak > 0 ? 'Active' : 'No Data'}</pre>`;

            

            if (isCallback) {

                await bot.answerCallbackQuery(msg.callbackQuery.id).catch(() => {});

            }

            return bot.sendMessage(chatId, progressText, { parse_mode: 'HTML' });

        }

        // --- 3. LOGIKA USER: ABSEN ---

        if (command === 'absen') {

            const today = new Date().toISOString().split('T')[0];

            if (!userDb[userId]) userDb[userId] = { count: 0, lastDate: null };

            if (userDb[userId].lastDate === today) {

                const btnProgress = { inline_keyboard: [[{ text: "📊 Cek Progress", callback_data: "cek_progress" }]] };

                return bot.sendMessage(chatId, "<pre>❌ Access Denied!\nKamu sudah absen hari ini.</pre>", { parse_mode: 'HTML', reply_markup: btnProgress });

            }

            const yesterday = new Date();

            yesterday.setDate(yesterday.getDate() - 1);

            const yesterdayStr = yesterday.toISOString().split('T')[0];

            if (userDb[userId].lastDate === yesterdayStr) {

                userDb[userId].count += 1;

            } else {

                userDb[userId].count = 1;

            }

            if (userDb[userId].count > 7) userDb[userId].count = 1;

            userDb[userId].lastDate = today;

            saveData(userAbsenPath, userDb);

            const streak = userDb[userId].count;

            const btnProgress = { inline_keyboard: [[{ text: "📊 Cek My Progress", callback_data: "cek_progress" }]] };

            

            let targetSlot = null;

            if (streak === 3) targetSlot = "1";

            if (streak === 5) targetSlot = "2";

            if (streak === 7) targetSlot = "3";

            if (targetSlot) {

                const reward = rewards[targetSlot];

                let msgGift = `<pre>🎉 STREAK ACHIEVED!\n━━━━━━━━━━━━━━━\nDay  : ${streak} Days\nGift : ${reward ? reward.name : 'No Stok'}\nStatus: Success</pre>`;

                

                if (!reward) return bot.sendMessage(chatId, msgGift, { parse_mode: 'HTML', reply_markup: btnProgress });

                if (reward.type === 'doc') return bot.sendDocument(chatId, reward.content, { caption: msgGift, parse_mode: 'HTML', reply_markup: btnProgress });

                if (reward.type === 'img') return bot.sendPhoto(chatId, reward.content, { caption: msgGift, parse_mode: 'HTML', reply_markup: btnProgress });

                if (reward.type === 'vid') return bot.sendVideo(chatId, reward.content, { caption: msgGift, parse_mode: 'HTML', reply_markup: btnProgress });

                return bot.sendMessage(chatId, `${msgGift}\n\n<pre>DATA:\n${reward.content}</pre>`, { parse_mode: 'HTML', reply_markup: btnProgress });

            } else {

                let next = streak < 3 ? 3 : (streak < 5 ? 5 : 7);

                let textProgress = `<pre>📅 DAILY ABSEN\n━━━━━━━━━━━━━━━\nStreak : ${streak} Hari\nNext   : ${next} Hari\nStatus : Aktif\n━━━━━━━━━━━━━━━\nNote: Bolos = Reset</pre>`;

                return bot.sendMessage(chatId, textProgress, { parse_mode: 'HTML', reply_markup: btnProgress });

            }

        }

    }

};