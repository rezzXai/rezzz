const { unshorten } = require('../../bypass');

const { mediafireDl } = require('../../mediafire');

const axios = require('axios');

const settings = require('../../setting');

module.exports = {

    keyword: 'bypaslink',

    keywordAliases: ['unshorten', 'media'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.trim().split(/\s+/);

        if (!settings.OWNER_ID.includes(userId)) return;

        if (args.length < 2) return bot.sendMessage(chatId, "✘ Masukkan link yang ingin ditembus!");

        const inputUrl = args[1];

        const loadingMsg = await bot.sendMessage(chatId, "🔍 Menembus link verifikasi...");

        try {

            // 1. Tembus Link Shortener

            const realLink = await unshorten(inputUrl);

            if (!realLink || !realLink.includes('mediafire.com')) {

                return bot.editMessageText("✘ Gagal menemukan link Mediafire di dalam link tersebut.", {

                    chat_id: chatId,

                    message_id: loadingMsg.message_id

                });

            }

            // 2. Jika ketemu, langsung proses dengan scraper Mediafire yang sudah ada

            await bot.editMessageText("✅ Link ditemukan! Mengekstrak file...", {

                chat_id: chatId,

                message_id: loadingMsg.message_id

            });

            const result = await mediafireDl(realLink);

            

            // Logika ukuran (sama seperti sebelumnya)

            const sizeStr = result.size.toUpperCase();

            const sizeNum = parseFloat(sizeStr);

            const isLarge = sizeStr.includes('GB') || (sizeStr.includes('MB') && sizeNum > 15);

            if (isLarge) {

                return await bot.editMessageText(

                    `📂 File Ditemukan via Bypass\n\n📄 Nama: ${result.name}\n⚖️ Ukuran: ${result.size}\n\nFile terlalu besar, download manual:`,

                    {

                        chat_id: chatId,

                        message_id: loadingMsg.message_id,

                        reply_markup: {

                            inline_keyboard: [[{ text: "📥 Download", url: result.link }]]

                        }

                    }

                );

            }

            // 3. Kirim File (Buffer)

            const response = await axios.get(result.link, { responseType: 'arraybuffer' });

            const buffer = Buffer.from(response.data, 'binary');

            

            await bot.sendDocument(chatId, buffer, {

                caption: `🔓 𝘽𝙮𝙥𝙖𝙨𝙨 𝙎𝙪𝙘𝙘𝙚𝙨\n📄 ${result.name}\n⚖️ ${result.size}`

            }, { filename: result.name });

            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

        } catch (e) {

            bot.editMessageText("❌ Gagal menembus link tersebut. Verifikasi mungkin terlalu ketat.", {

                chat_id: chatId,

                message_id: loadingMsg.message_id

            });

        }

    }

};