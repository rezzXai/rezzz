// cases/math.js

module.exports = {
    keyword: '/math',
    keywordAliases: ['/kalkulator'], 
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        const text = msg.text.trim();
        
        // Memastikan ada argumen setelah /math
        const args = text.split(' ').slice(1);
        if (args.length < 3) {
            return bot.sendMessage(chatId, 
                `❌ Format salah! Gunakan format: <code>/math [angka] [operator] [angka]</code>\n\n` +
                `Contoh:\n` +
                `• <code>/math 5 ditambah 3</code>\n` +
                `• <code>/math 10 dikali 2</code>\n` +
                `• <code>/math 9 dibagi 3</code>\n` +
                `• <code>/math 15 dikurang 7</code>`,
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );
        }

        // Mengambil teks yang berisi operasi (misal: "2 dikali 1")
        const expression = args.join(' ');
        
        // Definisikan operator dalam bentuk kata dan simbol
        const operators = {
            'ditambah': '+',
            'dikurang': '-',
            'dikali': '*',
            'dibagi': '/'
        };

        let operatorKata = '';
        let operatorSimbol = '';

        // Mencari operator di dalam expression
        for (const kata in operators) {
            if (expression.includes(kata)) {
                operatorKata = kata;
                operatorSimbol = operators[kata];
                break;
            }
        }

        if (!operatorKata) {
            return bot.sendMessage(chatId, 
                `❌ Operator tidak ditemukan. Gunakan: ditambah, dikurang, dikali, atau dibagi.`,
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );
        }

        // Memecah expression berdasarkan operator kata
        const parts = expression.split(operatorKata).map(p => p.trim());
        
        // Pastikan ada dua angka yang ditemukan
        if (parts.length !== 2) {
             return bot.sendMessage(chatId, 
                `❌ Format angka salah. Pastikan hanya ada dua angka yang dipisahkan oleh satu operator.`,
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );
        }

        // Mengambil angka dan mengkonversinya ke float
        const num1 = parseFloat(parts[0]);
        const num2 = parseFloat(parts[1]);
        
        // Validasi apakah input adalah angka
        if (isNaN(num1) || isNaN(num2)) {
            return bot.sendMessage(chatId, 
                `❌ Input harus berupa angka yang valid.`,
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );
        }

        let result;
        let operationDescription;

        // Melakukan perhitungan berdasarkan operator simbol
        switch (operatorSimbol) {
            case '+':
                result = num1 + num2;
                operationDescription = `${num1} + ${num2}`;
                break;
            case '-':
                result = num1 - num2;
                operationDescription = `${num1} - ${num2}`;
                break;
            case '*':
                result = num1 * num2;
                operationDescription = `${num1} × ${num2}`;
                break;
            case '/':
                if (num2 === 0) {
                    return bot.sendMessage(chatId, 
                        `❌ Tidak bisa dibagi dengan angka nol!`,
                        { reply_to_message_id: msg.message_id }
                    );
                }
                result = num1 / num2;
                operationDescription = `${num1} ÷ ${num2}`;
                break;
            default:
                result = null; 
        }

        // Format hasil akhir
        const formattedResult = result.toFixed(result % 1 === 0 ? 0 : 4); // Maksimal 4 desimal jika bukan bilangan bulat
        
        // Kirim jawaban
        await bot.sendMessage(chatId, 
            `🧠 **Kalkulasi Selesai**\n` +
            `Operasi: ${operationDescription}\n\n` +
            `Hasil dari **${num1} ${operatorKata} ${num2}** adalah:\n` +
            `\`\`\`\n` +
            `${formattedResult}\n` +
            `\`\`\``,
            { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
        );
    }
};