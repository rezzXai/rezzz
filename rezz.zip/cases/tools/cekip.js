const dns = require('dns').promises;
const axios = require('axios');
const { OWNER_ID } = require('../../setting');

module.exports = {
    keyword: 'cekip',
    keywordAliases: ['/cekip', '/ipinfo', '/domain'],
    
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const text = msg.text || '';
        const args = text.split(/\s+/);
        let domainInput = args[1] ? args[1].trim() : null;

        // 1. Validasi Input
        if (!domainInput) {
            return bot.sendMessage(chatId, 
` <b>✘ 𝙎𝘼𝙇𝘼𝙃 𝙊𝙈 𝙆𝙐𝙐</b>
<pre>
━━━━━━━━━━━━━━━━━━━━
CONTOH : /cekip google.com
INFO   : Masukkan domain/URL
━━━━━━━━━━━━━━━━━━━━
</pre>`, { parse_mode: 'HTML' });
        }

        // 2. Pembersihan Nama Domain
        let domain = domainInput.replace(/(^\w+:|^)\/\//, '').split('/')[0].split(':')[0];
        
        const loading = await bot.sendMessage(chatId, `⏳ <code>SISTEM: Mencari info ${domain}...</code>`, { parse_mode: 'HTML' });

        try {
            // 3. DNS Lookup
            const lookup = await dns.lookup(domain);
            const ipAddress = lookup.address;

            // 4. GeoIP Lookup (Info ISP & Server)
            const response = await axios.get(`http://ip-api.com/json/${ipAddress}?fields=status,message,country,countryCode,regionName,city,zip,timezone,isp,org,as,mobile,proxy,hosting`);
            const data = response.data;

            if (data.status !== 'success') throw new Error(data.message);

            // 5. Format Output ala Panel Monitoring
            const reply = 
` <b>𝙃𝘼𝙎𝙄𝙇 𝘾𝙀𝙆 𝙎𝙐𝘾𝘾𝙀𝙎 ✔</b>
<pre>
━━━━━━━━━━━━━━━━━━━━
DOMAIN   : ${domain}
IP ADDR  : ${ipAddress}
━━━━━━━━━━━━━━━━━━━━
NETWORK DETAILS
ISP      : ${data.isp}
ASN      : ${data.as.split(' ')[0]}
HOSTING  : ${data.hosting ? 'YES (Cloud/VPS)' : 'NO (Home/ISP)'}
PROXY/VPN: ${data.proxy ? 'YES' : 'NO'}

LOCATION INFO
COUNTRY  : ${data.country} (${data.countryCode})
CITY     : ${data.city}
TIMEZONE : ${data.timezone}
━━━━━━━━━━━━━━━━━━━━
</pre>
<i>Data diambil berdasarkan database GeoIP terbaru.</i>`;

            await bot.editMessageText(reply, {
                chat_id: chatId,
                message_id: loading.message_id,
                parse_mode: 'HTML'
            });

        } catch (e) {
            bot.editMessageText(`❌ <b>GAGAL MELACAK</b>\n<pre>ERROR: Domain tidak valid atau server down.</pre>`, {
                chat_id: chatId,
                message_id: loading.message_id,
                parse_mode: 'HTML'
            });
        }
    }
};