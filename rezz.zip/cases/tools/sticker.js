// cases/sticker.js (REVISI FINAL: PROSES GAMBAR DENGAN SHARP & AXIOS)

const settings = require('../../setting');
const axios = require('axios'); // Untuk mengunduh gambar
const sharp = require('sharp'); // Untuk resize dan konversi gambar

module.exports = {
    keyword: '/sticker',
    keywordAliases: ['/stiker'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const repliedMsg = msg.reply_to_message;
        
        if (!repliedMsg) {
            return bot.sendMessage(chatId, '❌ **Kesalahan:** Silakan balas (reply) ke gambar, dokumen (PNG/JPG), atau sticker.', { parse_mode: 'Markdown' });
        }

        let fileId = null;
        
        // Cek media (Sticker, Foto, atau Dokumen Gambar)
        if (repliedMsg.sticker) {
            fileId = repliedMsg.sticker.file_id;
        } else if (repliedMsg.photo) {
            fileId = repliedMsg.photo[repliedMsg.photo.length - 1].file_id;
        } else if (repliedMsg.document && repliedMsg.document.mime_type.startsWith('image/')) {
            fileId = repliedMsg.document.file_id;
        }
        
        if (!fileId) {
             return bot.sendMessage(chatId, '❌ **Kesalahan:** Pesan yang Anda balas harus berupa gambar (PNG/JPG) atau sticker.', { parse_mode: 'Markdown' });
        }

        // ======================================================
        // === PROSES KONVERSI GAMBAR (DOWNLOAD, RESIZE, UPLOAD) ===
        // ======================================================
        try {
            // 1. Dapatkan File Path dari Telegram
            const fileInfo = await bot.getFile(fileId);
            const filePath = fileInfo.file_path;
            const downloadUrl = `https://api.telegram.org/file/bot${settings.BOT_TOKEN}/${filePath}`;

            // 2. Download Gambar
            const response = await axios({
                url: downloadUrl,
                responseType: 'arraybuffer'
            });
            const imageBuffer = Buffer.from(response.data);

            // 3. Proses Gambar (Resize & Konversi ke WEBP)
            const processedBuffer = await sharp(imageBuffer)
                .resize(512, 512, {
                    fit: 'contain', // Menjaga aspek rasio, sisa ruang jadi transparan
                    background: { r: 0, g: 0, b: 0, alpha: 0 } 
                })
                .webp({ quality: 90 }) // Konversi ke format WEBP (terbaik untuk sticker)
                .toBuffer();

            // 4. Kirim sebagai Sticker
            await bot.sendSticker(chatId, processedBuffer);
            
            // Hapus pesan command /sticker
            if (msg.chat.type !== 'private') {
                try {
                    await bot.deleteMessage(chatId, msg.message_id);
                } catch (e) { /* ignore */ }
            }

        } catch (error) {
            console.error(`🔴 Gagal memproses sticker (SHARP/AXIOS):`, error.message);
            
            let replyText = '❌ **Gagal Total Memproses Sticker!**\n\n';
            if (error.message.includes('Input buffer contains unsupported image format')) {
                 replyText += 'ℹ️ **Penyebab:** Format gambar ini tidak didukung (mungkin GIF animasi atau TGS).\n';
            } else {
                 replyText += 'ℹ️ **Penyebab:** Terjadi kesalahan saat mengunduh atau memproses gambar.\n';
            }
            
            return bot.sendMessage(chatId, replyText, { parse_mode: 'Markdown' });
        }
    }
};