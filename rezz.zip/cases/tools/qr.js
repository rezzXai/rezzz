// cases/qr.js (Pemindaian Kode QR)

const Jimp = require('jimp');
const qrCodeReader = require('qrcode-reader'); 
const fs = require('fs');
const path = require('path');

// Folder sementara untuk menyimpan gambar yang diunduh
const TEMP_DIR = path.join(__dirname, '..', 'temp');

// Pastikan folder temp ada
if (!fs.existsSync(TEMP_DIR)){
    fs.mkdirSync(TEMP_DIR);
}

module.exports = {
    keyword: 'qr',
    keywordAliases: ['/qr', '/scanqr'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        // 1. Cek apakah ada reply ke sebuah pesan
        const repliedMsg = msg.reply_to_message;
        
        if (!repliedMsg) {
            return bot.sendMessage(chatId, 
                "❌ Format Salah.Anda harus me reply gambar QR dengan perintah /qr.", 
                { reply_to_message_id: msg.message_id });
        }

        // 2. Cek apakah pesan yang di-reply berisi foto
        const photo = repliedMsg.photo; 
        
        if (!photo || photo.length === 0) {
            return bot.sendMessage(chatId, 
                "❌ Pesan yang di-reply harus berupa Foto yang mengandung Kode QR.", 
                { reply_to_message_id: msg.message_id });
        }

        // Ambil ID file foto dengan kualitas tertinggi
        const fileId = photo[photo.length - 1].file_id; 
        let tempFilePath = '';
        let waitMessage;
        
        try {
            waitMessage = await bot.sendMessage(chatId, "⏳ Mengunduh dan memindai Kode QR...", { reply_to_message_id: msg.message_id });

            // 3. Ambil URL file dari Telegram dan unduh
            const fileLink = await bot.getFileLink(fileId);
            const downloadStream = bot.getFileStream(fileId);
            
            // Simpan file sementara
            const fileName = `${Date.now()}_${fileId}.jpg`;
            tempFilePath = path.join(TEMP_DIR, fileName);
            
            const writer = fs.createWriteStream(tempFilePath);
            downloadStream.pipe(writer);

            // Tunggu hingga file selesai diunduh
            await new Promise((resolve, reject) => {
                writer.on('finish', resolve);
                writer.on('error', reject);
            });

            // 4. Proses dan Pindai dengan Jimp & qrcode-reader
            const image = await Jimp.read(tempFilePath);
            const qr = new qrCodeReader();

            // Membaca Kode QR (Callback-based, kita bungkus dengan Promise)
            const resultData = await new Promise((resolve, reject) => {
                qr.callback = (err, value) => {
                    if (err) {
                        return reject(new Error("Gagal membaca Kode QR. Pastikan gambar jelas."));
                    }
                    if (value && value.result) {
                        resolve(value.result);
                    } else {
                        reject(new Error("Tidak ada Kode QR yang terdeteksi pada gambar."));
                    }
                };
                qr.decode(image.bitmap);
            });
            
            // 5. Kirim Hasil
            await bot.deleteMessage(chatId, waitMessage.message_id).catch(() => {});
            
            const successMessage = 
                `✅ **Kode QR Berhasil Dipindai!**\n\n` +
                `*Data yang Ditemukan:*\n` +
                `\`\`\`\n${resultData}\n\`\`\``;

            return bot.sendMessage(chatId, successMessage, { 
                parse_mode: 'Markdown', 
                reply_to_message_id: msg.message_id 
            });

        } catch (error) {
            console.error(`🔴 Error saat memindai QR Code: ${error.message}`);
            
            // Hapus pesan tunggu jika ada dan belum dihapus
            if (waitMessage && waitMessage.message_id) {
                await bot.deleteMessage(chatId, waitMessage.message_id).catch(() => {});
            }

            // Kirim pesan error yang ramah pengguna
            bot.sendMessage(chatId, `❌ **Gagal Memindai.** ${error.message}`, { reply_to_message_id: msg.message_id });
        
        } finally {
            // 6. Hapus file sementara setelah selesai
            if (fs.existsSync(tempFilePath)) {
                fs.unlinkSync(tempFilePath);
            }
        }
    }
};