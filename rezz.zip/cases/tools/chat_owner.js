module.exports = {
    keyword: 'chatowner',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const args = msg.text.split(' ').slice(1).join(' ');

        if (!args) return bot.sendMessage(chatId, "❌ Gunakan format: `/chatowner [pesananda]`", { parse_mode: 'Markdown' });

        const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;
        const msgToOwner = `📩 **CHAT BARU**\n\n👤 **User:** ${msg.from.first_name}\n🆔 **ID:** \`${userId}\`\n💬 **Pesan:** ${args}`;

        try {
            await bot.sendMessage(ownerId, msgToOwner, { 
                parse_mode: 'Markdown',
                reply_markup: { inline_keyboard: [[{ text: '📩 BALAS PESAN', callback_data: `reply_user:${userId}` }]] }
            });
            global.resetChatTimer(bot, chatId, ownerId);
            return bot.sendMessage(chatId, "✅ Pesan terkirim ke Owner.");
        } catch (e) {
            return bot.sendMessage(chatId, "❌ Gagal menghubungi Owner.");
        }
    }
};