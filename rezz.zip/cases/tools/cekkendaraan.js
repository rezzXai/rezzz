// cases/cekkendaraan.js (FITUR BARU: Cek Kendaraan Acak)

module.exports = {
    keyword: 'cekkendaraan', 
    keywordAliases: ['/cekkendaraan'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const senderName = msg.from.first_name || 'Anda';
        const senderId = msg.from.id;

        // --- DAFTAR KENDARAAN (DATA) ---
        const vehicles = {
            darat: [
                "Sepeda Motor Bebek Modifikasi",
                "Mobil F1 Tim Ferrari (versi rusak)",
                "Truk Tronton Pengangkut Semangka",
                "Bajaj Berpendingin Udara",
                "Tank Leopard 2A6",
                "Motor Trail Cross Anti-Banjir",
                "Skuter Listrik Xiaomi (tanpa baterai)",
                "Delman yang ditarik oleh Kuda Poni",
                "Kereta Luncur Santa Claus"
            ],
            air: [
                "Kapal Selam Nuklir Rusia",
                "Perahu Karet Bocor (dengan dayung tunggal)",
                "Kapal Pesiar Mewah Titanic (setelah perbaikan)",
                "Jet Ski dengan tenaga Kincir Angin",
                "Sampan Kayu Anti-Tenggelam",
                "Raket Nyamuk yang mengapung"
            ],
            udara: [
                "Pesawat Tempur F-22 Raptor",
                "Balon Udara Panas berbentuk Nanas",
                "Helikopter Chinook (mode terbang mundur)",
                "Drone Pengantar Pizza Super Cepat",
                "Roket SpaceX (hanya bagian hidungnya)",
                "Karpet Terbang Aladin (butuh bensin)"
            ],
            fiksi: [
                "Mobil waktu DeLorean dari Back to the Future",
                "Kendaraan Batman (Batmobile versi 1966)",
                "TARDIS dari Doctor Who (lebih besar di dalam)",
                "Millennium Falcon (butuh perbaikan 100%)",
                "Ekor Ikan Duyung (mode cepat)",
                "Gundam RX-78-2 (hanya bisa berjalan pelan)"
            ]
        };
        
        // Pilih kategori dan kendaraan secara acak
        const categories = Object.keys(vehicles);
        const randomCategoryKey = categories[Math.floor(Math.random() * categories.length)];
        const categoryList = vehicles[randomCategoryKey];
        
        const randomIndex = Math.floor(Math.random() * categoryList.length);
        const vehicleName = categoryList[randomIndex];
        
        // Format kategori
        const categoryDisplay = randomCategoryKey.toUpperCase();
        
        // --- PESAN RESPON ---
        let responseMessage = 
            `🚗 **CEK KENDARAAN PEMBAWA HOKI!** ✈️\n\n` +
            `Hasil penerawangan untuk *${senderName}* (ID: \`${senderId}\`):\n\n` +
            `Berdasarkan takdir acak, kendaraan yang akan membawa Anda berkeliling dunia adalah:\n\n` +
            `🔧 **${vehicleName.toUpperCase()}**\n` +
            `*Tipe:* ${categoryDisplay}\n\n` +
            `Semoga kendaraan Anda membawa berkah!`;

        try {
            await bot.sendMessage(chatId, responseMessage, { 
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id 
            });
        } catch (error) {
            console.error(`Gagal mengirim pesan cekkendaraan: ${error.message}`);
        }
    }
};