// /cases/font.js (Murni Javascript - Versi Lengkap 20 Font, Daftar Rapi)

// === Peta Karakter Unicode (Dibuat Manual) ===
const FONT_MAPS = {
    // A. Gaya Matematika & Dasar (5 Gaya)
    bold: {
        A: '𝗔', B: '𝗕', C: '𝗖', D: '𝗗', E: '𝗘', F: '𝗙', G: '𝗚', H: '𝗛', I: '𝗜', J: '𝗝', K: '𝗞', L: '𝗟', M: '𝗠', N: '𝗡', O: '𝗢', P: '𝗣', Q: '𝗤', R: '𝗥', S: '𝗦', T: '𝗧', U: '𝗨', V: '𝗩', W: '𝗪', X: '𝗫', Y: '𝗬', Z: '𝗭',
        a: '𝗮', b: '𝗯', c: '𝗰', d: '𝗱', e: '𝗲', f: '𝗳', g: '𝗴', h: '𝗵', i: '𝗶', j: '𝗷', k: '𝗸', l: '𝗹', m: '𝗺', n: '𝗻', o: '𝗼', p: '𝗽', q: '𝗾', r: '𝗿', s: '𝘀', t: '𝘁', u: '𝘂', v: '𝘃', w: '𝘄', x: '𝘅', y: '𝘆', z: '𝘇',
        0: '𝟬', 1: '𝟭', 2: '𝟮', 3: '𝟯', 4: '𝟰', 5: '𝟱', 6: '𝟲', 7: '𝟳', 8: '𝟴', 9: '𝟵',
    },
    italic: {
        A: '𝘈', B: '𝘉', C: '𝘊', D: '𝘋', E: '𝘌', F: '𝘍', G: '𝘎', H: '𝘏', I: '𝘐', J: '𝘑', K: '𝘒', L: '𝘓', M: '𝘔', N: '𝘕', O: '𝘖', P: '𝘗', Q: '𝘘', R: '𝘙', S: '𝘚', T: '𝘛', U: '𝘜', V: '𝘝', W: '𝘞', X: '𝘟', Y: '𝘠', Z: '𝘡',
        a: '𝘢', b: '𝘣', c: '𝘤', d: '𝘥', e: '𝘦', f: '𝘧', g: '𝘨', h: '𝘩', i: '𝘪', j: '𝘫', k: '𝘬', l: '𝘭', m: '𝘮', n: '𝘯', o: '𝘰', p: '𝘱', q: '𝘲', r: '𝘳', s: '𝘴', t: '𝘵', u: '𝘶', v: '𝘷', w: '𝘸', x: '𝘹', y: '𝘺', z: '𝘻',
    },
    bolditalic: {
        A: '𝑨', B: '𝑩', C: '𝑪', D: '𝑫', E: '𝑬', F: '𝑭', G: '𝑮', H: '𝑯', I: '𝑰', J: '𝑱', K: '𝑲', L: '𝑳', M: '𝑴', N: '𝑵', O: '𝑶', P: '𝑷', Q: '𝑸', R: '𝑹', S: '𝑺', T: '𝑻', U: '𝑼', V: '𝑽', W: '𝑾', X: '𝑿', Y: '𝒀', Z: '𝒁',
        a: '𝒂', b: '𝒃', c: '𝒄', d: '𝒅', e: '𝒆', f: '𝒇', g: '𝒈', h: '𝒉', i: '𝒊', j: '𝒋', k: '𝒌', l: '𝒍', m: '𝒎', n: '𝒏', o: '𝒐', p: '𝒑', q: '𝒒', r: '𝒓', s: '𝒔', t: '𝒕', u: '𝒖', v: '𝒗', w: '𝒘', x: '𝒙', y: '𝒚', z: '𝒛',
    },
    mono: {
        A: '𝙰', B: '𝙱', C: '𝙲', D: '𝙳', E: '𝙴', F: '𝙵', G: '𝙶', H: '𝙷', I: '𝙸', J: '𝙹', K: '𝙺', L: '𝙻', M: '𝙼', N: '𝙽', O: '𝙾', P: '𝙿', Q: '𝚀', R: '𝚁', S: '𝚂', T: '𝚃', U: '𝚄', V: '𝚅', W: '𝚆', X: '𝚇', Y: '𝚈', Z: '𝚉',
        a: '𝚊', b: '𝚋', c: '𝚌', d: '𝚍', e: '𝚎', f: '𝚏', g: '𝚐', h: '𝚑', i: '𝚒', j: '𝚓', k: '𝚔', l: '𝚕', m: '𝚖', n: '𝚗', o: '𝚘', p: '𝚙', q: '𝚚', r: '𝚛', s: '𝚜', t: '𝚝', u: '𝚞', v: '𝚟', w: '𝚠', x: '𝚡', y: '𝚢', z: '𝚣',
        0: '🟰', 1: '🟰', 2: '🟰', 3: '🟰', 4: '🟰', 5: '🟰', 6: '🟰', 7: '🟰', 8: '🟰', 9: '🟰',
    },
    double: {
        A: '𝔸', B: '𝔹', C: 'ℂ', D: '𝔻', E: '𝔼', F: '𝔽', G: '𝔾', H: 'ℍ', I: '𝕀', J: '𝕁', K: '𝕂', L: '𝕃', M: '𝕄', N: 'ℕ', O: '𝕆', P: 'ℙ', Q: 'ℚ', R: 'ℝ', S: '𝕊', T: '𝕋', U: '𝕌', V: '𝕍', W: '𝕎', X: '𝕏', Y: '𝕐', Z: 'ℤ',
    },

    // B. Gaya Dekoratif & Fun (5 Gaya)
    bubble: {
        A: 'Ⓐ', B: 'Ⓑ', C: 'Ⓒ', D: 'Ⓓ', E: 'Ⓔ', F: 'Ⓕ', G: 'Ⓖ', H: 'Ⓗ', I: 'Ⓘ', J: 'Ⓙ', K: 'Ⓚ', L: 'Ⓛ', M: 'Ⓜ', N: 'Ⓝ', O: 'Ⓞ', P: 'Ⓟ', Q: 'Ⓠ', R: 'Ⓡ', S: 'Ⓢ', T: 'Ⓣ', U: 'Ⓤ', V: 'Ⓥ', W: 'Ⓦ', X: 'Ⓧ', Y: 'Ⓨ', Z: 'Ⓩ',
        a: 'ⓐ', b: 'ⓑ', c: 'ⓒ', d: 'ⓓ', e: 'ⓔ', f: 'ⓕ', g: 'ⓖ', h: 'ⓗ', i: 'ⓘ', j: 'ⓙ', k: 'ⓚ', l: 'ⓛ', m: 'ⓜ', n: 'ⓝ', o: 'ⓞ', p: 'ⓟ', q: 'ⓠ', r: 'ⓡ', s: 'ⓢ', t: 'ⓣ', u: 'ⓤ', v: 'ⓥ', w: 'ⓦ', x: 'ⓧ', y: 'ⓨ', z: 'ⓩ',
        0: '⓪', 1: '①', 2: '②', 3: '③', 4: '④', 5: '⑤', 6: '⑥', 7: '⑦', 8: '⑧', 9: '⑨',
    },
    script: {
        A: '𝒜', B: '𝐵', C: '𝒞', D: '𝒟', E: '𝐸', F: '𝐹', G: '𝒢', H: '𝐻', I: '𝐼', J: '𝒥', K: '𝒦', L: '𝐿', M: '𝑀', N: '𝒩', O: '𝒪', P: '𝒫', Q: '𝒬', R: '𝑅', S: '𝒮', T: '𝒯', U: '𝒰', V: '𝒱', W: '𝒲', X: '𝒳', Y: '𝒴', Z: '𝒵',
        a: '𝒶', b: '𝒷', c: '𝒸', d: '𝒹', e: '𝑒', f: '𝒻', g: '𝑔', h: '𝒽', i: '𝒾', j: '𝒿', k: '𝓀', l: '𝓁', m: '𝓂', n: '𝓃', o: '𝑜', p: '𝓅', q: '𝓆', r: '𝓇', s: '𝓈', t: '𝓉', u: '𝓊', v: '𝓋', w: '𝓌', x: '𝓍', y: '𝓎', z: '𝓏',
    },
    gothic: { 
        A: '𝔄', B: '𝔅', C: 'ℭ', D: '𝔇', E: '𝔈', F: '𝔉', G: '𝔊', H: 'ℌ', I: 'ℑ', J: '𝔍', K: '𝔎', L: '𝔏', M: '𝔐', N: '𝔑', O: '𝔒', P: '𝔓', Q: '𝔔', R: 'ℜ', S: '𝔖', T: '𝔗', U: '𝔘', V: '𝔙', W: '𝔚', X: '𝔛', Y: '𝔜', Z: 'ℨ',
        a: '𝔞', b: '𝔟', c: '𝔠', d: '𝔡', e: '𝔢', f: '𝔣', g: '𝔤', h: '𝔥', i: '𝔦', j: '𝔧', k: '𝔨', l: '𝔩', m: '𝔪', n: '𝔫', o: '𝔬', p: '𝔭', q: '𝔮', r: '𝔯', s: '𝔰', t: '𝔱', u: '𝔲', v: '𝔳', w: '𝔴', x: '𝔵', y: '𝔶', z: '𝔷',
    },
    box: { 
        A: '🄰', B: '🄱', C: '🄲', D: '🄳', E: '🄴', F: '🄵', G: '🄶', H: '🄷', I: '🄸', J: '🄹', K: '🄺', L: '🄻', M: '🄼', N: '🄽', O: '🄾', P: '🄿', Q: '🅀', R: '🅁', S: '🅂', T: '🅃', U: '🅄', V: '🅅', W: '🅆', X: '🅇', Y: '🅈', Z: '🅉',
    },
    wave: { 
        A: '≋', B: 'Ḅ', C: 'Ḉ', D: 'Ḋ', E: 'Ḕ', F: 'Ḟ', G: '₲', H: 'Ħ', I: 'Ї', J: 'J', K: '₭', L: 'Ł', M: 'ℳ', N: '₦', O: 'Ø', P: '₱', Q: 'Q', R: 'ℛ', S: 'Ṡ', T: '₮', U: 'Ṳ', V: 'V', W: '₩', X: 'X', Y: 'Ẏ', Z: 'ℤ',
        a: 'ḁ', b: 'b', c: 'c', d: 'đ', e: 'é', f: 'f', g: 'g', h: 'h', i: 'ɨ', j: 'j', k: 'k', l: 'ł', m: 'm', n: 'n', o: 'ø', p: 'p', q: 'q', r: 'r', s: 's', t: 't', u: 'u', v: 'v', w: 'w', x: 'x', y: 'y', z: 'z',
    },
    
    // C. Gaya Status & Khusus (6 Gaya)
    tiny: { 
        A: 'ᴬ', B: 'ᴮ', C: 'ᶜ', D: 'ᴰ', E: 'ᴱ', F: 'ᶠ', G: 'ᴳ', H: 'ᴴ', I: 'ᴵ', J: 'ᴶ', K: 'ᴷ', L: 'ᴸ', M: 'ᴹ', N: 'ᴺ', O: 'ᴼ', P: 'ᴾ', Q: 'Q', R: 'ᴿ', S: 'ˢ', T: 'ᵀ', U: 'ᵁ', V: 'ᵛ', W: 'ᵂ', X: 'ˣ', Y: 'ʸ', Z: 'ᶻ',
        a: 'ᵃ', b: 'ᵇ', c: 'ᶜ', d: 'ᵈ', e: 'ᵉ', f: 'ᶠ', g: 'ᵍ', h: 'ʰ', i: 'ⁱ', j: 'ʲ', k: 'ᵏ', l: 'ˡ', m: 'ᵐ', n: 'ⁿ', o: 'ᵒ', p: 'ᵖ', q: '𐞥', r: 'ʳ', s: 'ˢ', t: 'ᵗ', u: 'ᵘ', v: 'ᵛ', w: 'ʷ', x: 'ˣ', y: 'ʸ', z: 'ᶻ',
        0: '⁰', 1: '¹', 2: '²', 3: '³', 4: '⁴', 5: '⁵', 6: '⁶', 7: '⁷', 8: '⁸', 9: '⁹',
    },
    lining: { 
        a: 'a̲', b: 'b̲', c: 'c̲', d: 'd̲', e: 'e̲', f: 'f̲', g: 'g̲', h: 'h̲', i: 'i̲', j: 'j̲', k: 'k̲', l: 'l̲', m: 'm̲', n: 'n̲', o: 'o̲', p: 'p̲', q: 'q̲', r: 'r̲', s: 's̲', t: 't̲', u: 'u̲', v: 'v̲', w: 'w̲', x: 'x̲', y: 'y̲', z: 'z̲',
        A: 'A̲', B: 'B̲', C: 'C̲', D: 'D̲', E: 'E̲', F: 'F̲', G: 'G̲', H: 'H̲', I: 'I̲', J: 'J̲', K: 'K̲', L: 'L̲', M: 'M̲', N: 'N̲', O: 'O̲', P: 'P̲', Q: 'Q̲', R: 'R̲', S: 'S̲', T: 'T̲', U: 'U̲', V: 'V̲', W: 'W̲', X: 'X̲', Y: 'Y̲', Z: 'Z̲',
    },
    smallcaps: { 
        a: 'ᴀ', b: 'ʙ', c: 'ᴄ', d: 'ᴅ', e: 'ᴇ', f: 'ꜰ', g: 'ɢ', h: 'ʜ', i: 'ɪ', j: 'ᴊ', k: 'ᴋ', l: 'ʟ', m: 'ᴍ', n: 'ɴ', o: 'ᴏ', p: 'ᴘ', q: 'Q', r: 'ʀ', s: 'ꜱ', t: 'ᴛ', u: 'ᴜ', v: 'ᴠ', w: 'ᴡ', x: 'x', y: 'ʏ', z: 'ᴢ',
    },
    crossthru: { 
        a: 'a̶', b: 'b̶', c: 'c̶', d: 'd̶', e: 'e̶', f: 'f̶', g: 'g̶', h: 'h̶', i: 'i̶', j: 'j̶', k: 'k̶', l: 'l̶', m: 'm̶', n: 'n̶', o: 'o̶', p: 'p̶', q: 'q̶', r: 'r̶', s: 's̶', t: 't̶', u: 'u̶', v: 'v̶', w: 'w̶', x: 'x̶', y: 'y̶', z: 'z̶',
        A: 'A̶', B: 'B̶', C: 'C̶', D: 'D̶', E: 'E̶', F: 'F̶', G: 'G̶', H: 'H̶', I: 'I̶', J: 'J̶', K: 'K̶', L: 'L̶', M: 'M̶', N: 'N̶', O: 'O̶', P: 'P̶', Q: 'Q̶', R: 'R̶', S: 'S̶', T: 'T̶', U: 'U̶', V: 'V̶', W: 'W̶', X: 'X̶', Y: 'Y̶', Z: 'Z̶',
    },
    reverse: { 
        a: 'ɐ', b: 'q', c: 'ɔ', d: 'p', e: 'ǝ', f: 'ɟ', g: 'ƃ', h: 'ɥ', i: 'ᴉ', j: 'ɾ', k: 'ʞ', l: 'l', m: 'ɯ', n: 'u', o: 'o', p: 'd', q: 'b', r: 'ɹ', s: 's', t: 'ʇ', u: 'n', v: 'ʌ', w: 'ʍ', x: 'x', y: 'ʎ', z: 'z',
        '!': '¡', '?': '¿', ',': "'", '.': '˙',
    },
    strikethrough: {}, 

    // D. Gaya Unik Tambahan (9 Gaya)
    squarefill: { 
        A: '🅰', B: '🅱', C: '🅲', D: '🅳', E: '🅴', F: '🅵', G: '🅶', H: '🅷', I: '🅸', J: '🅹', K: '🅺', L: '🅻', M: '🅼', N: '🅽', O: '🅾', P: '🅿', Q: '🆀', R: '🆁', S: '🆂', T: '🆃', U: '🆄', V: '🆅', W: '🆆', X: '🆇', Y: '🆈', Z: '🆉',
    },
    bracket: { 
        A: '⟦A⟧', B: '⟦B⟧', C: '⟦C⟧', D: '⟦D⟧', E: '⟦E⟧', F: '⟦F⟧', G: '⟦G⟧', H: '⟦H⟧', I: '⟦I⟧', J: '⟦J⟧', K: '⟦K⟧', L: '⟦L⟧', M: '⟦M⟧', N: '⟦N⟧', O: '⟦O⟧', P: '⟦P⟧', Q: '⟦Q⟧', R: '⟦R⟧', S: '⟦S⟧', T: '⟦T⟧', U: '⟦U⟧', V: '⟦V⟧', W: '⟦W⟧', X: '⟦X⟧', Y: '⟦Y⟧', Z: '⟦Z⟧',
        a: '[a]', b: '[b]', c: '[c]', d: '[d]', e: '[e]', f: '[f]', g: '[g]', h: '[h]', i: '[i]', j: '[j]', k: '[k]', l: '[l]', m: '[m]', n: '[n]', o: '[o]', p: '[p]', q: '[q]', r: '[r]', s: '[s]', t: '[t]', u: '[u]', v: '[v]', w: '[w]', x: '[x]', y: '[y]', z: '[z]',
    },
    mirror: { 
        A: 'A', B: 'B', C: 'Ɔ', D: 'ᗡ', E: 'Ǝ', F: 'F', G: 'Ꭾ', H: 'H', I: 'I', J: 'ſ', K: 'ꓘ', L: '⅃', M: 'M', N: 'И', O: 'O', P: 'ꟼ', Q: 'Q', R: 'Я', S: 'Ƨ', T: 'T', U: 'U', V: 'V', W: 'W', X: 'X', Y: 'Y', Z: '⅁',
        a: 'ɒ', b: 'd', c: 'ɔ', d: 'b', e: 'ɘ', f: 'ʇ', g: 'ǫ', h: 'ʜ', i: 'i', j: 'ſ', k: 'ʞ', l: 'l', m: 'm', n: 'n', o: 'o', p: 'q', q: 'p', r: 'ɿ', s: 'ƨ', t: 't', u: 'u', v: 'v', w: 'w', x: 'x', y: 'y', z: 'z',
    },
    tilde: { 
        a: 'ã', b: 'b̃', c: 'c̃', d: 'd̃', e: 'ẽ', f: 'f̃', g: 'g̃', h: 'h̃', i: 'ĩ', j: 'j̃', k: 'k̃', l: 'l̃', m: 'm̃', n: 'ñ', o: 'õ', p: 'p̃', q: 'q̃', r: 'r̃', s: 's̃', t: 't̃', u: 'ũ', v: 'ṽ', w: 'w̃', x: 'x̃', y: 'ỹ', z: 'z̃',
        A: 'Ã', B: 'B̃', C: 'C̃', D: 'D̃', E: 'Ẽ', F: 'F̃', G: 'G̃', H: 'H̃', I: 'Ĩ', J: 'J̃', K: 'K̃', L: 'L̃', M: 'M̃', N: 'Ñ', O: 'Õ', P: 'P̃', Q: 'Q̃', R: 'R̃', S: 'S̃', T: 'T̃', U: 'Ũ', V: 'Ṽ', W: 'W̃', X: 'X̃', Y: 'Ỹ', Z: 'Z̃',
    },
    // Tambahan 4 Gaya Baru
    diamond: {
        A: '🅐', B: '🅑', C: '🅒', D: '🅓', E: '🅔', F: '🅕', G: '🅖', H: '🅗', I: '🅘', J: '🅙', K: '🅚', L: '🅛', M: '🅜', N: '🅝', O: '🅞', P: '🅟', Q: '🅠', R: '🅡', S: '🅢', T: '🅣', U: '🅤', V: '🅥', W: '🅦', X: '🅧', Y: '🅨', Z: '🅩',
    },
    fullwidth: { // Teks Lebar Penuh (sering dipakai di Jepang)
        A: 'Ａ', B: 'Ｂ', C: 'Ｃ', D: 'Ｄ', E: 'Ｅ', F: 'Ｆ', G: 'Ｇ', H: 'Ｈ', I: 'Ｉ', J: 'Ｊ', K: 'Ｋ', L: 'Ｌ', M: 'Ｍ', N: 'Ｎ', O: 'Ｏ', P: 'Ｐ', Q: 'Ｑ', R: 'Ｒ', S: 'Ｓ', T: 'Ｔ', U: 'Ｕ', V: 'Ｖ', W: 'Ｗ', X: 'Ｘ', Y: 'Ｙ', Z: 'Ｚ',
        a: 'ａ', b: 'ｂ', c: 'ｃ', d: 'ｄ', e: 'ｅ', f: 'ｆ', g: 'ｇ', h: 'ｈ', i: 'ｉ', j: 'ｊ', k: 'ｋ', l: 'ｌ', m: 'ｍ', n: 'ｎ', o: 'ｏ', p: 'ｐ', q: 'ｑ', r: 'ｒ', s: 'ｓ', t: 'ｔ', u: 'ｕ', v: 'ｖ', w: 'ｗ', x: 'ｘ', y: 'ｙ', z: 'ｚ',
        0: '０', 1: '１', 2: '２', 3: '３', 4: '４', 5: '５', 6: '６', 7: '７', 8: '８', 9: '９',
    },
    doubleline: { // Teks Garis Ganda di Bawah (Double Underline)
        a: 'a̳', b: 'b̳', c: 'c̳', d: 'd̳', e: 'e̳', f: 'f̳', g: 'g̳', h: 'h̳', i: 'i̳', j: 'j̳', k: 'k̳', l: 'l̳', m: 'm̳', n: 'n̳', o: 'o̳', p: 'p̳', q: 'q̳', r: 'r̳', s: 's̳', t: 't̳', u: 'u̳', v: 'v̳', w: 'w̳', x: 'x̳', y: 'y̳', z: 'z̳',
        A: 'A̳', B: 'B̳', C: 'C̳', D: 'D̳', E: 'E̳', F: 'F̳', G: 'G̳', H: 'H̳', I: 'I̳', J: 'J̳', K: 'K̳', L: 'L̳', M: 'M̳', N: 'N̳', O: 'O̳', P: 'P̳', Q: 'Q̳', R: 'R̳', S: 'S̳', T: 'T̳', U: 'U̳', V: 'V̳', W: 'W̳', X: 'X̳', Y: 'Y̳', Z: 'Z̳',
    },
    fraktur: { // Bold Gothic / Bold Fraktur
        A: '𝕬', B: '𝕭', C: '𝕮', D: '𝕯', E: '𝕰', F: '𝕱', G: '𝕲', H: '𝕳', I: '𝕴', J: '𝕵', K: '𝕶', L: '𝕷', M: '𝕸', N: '𝕹', O: '𝕺', P: '𝕻', Q: '𝕼', R: '𝕽', S: '𝕾', T: '𝕿', U: '𝖀', V: '𝖁', W: '𝖂', X: '𝖃', Y: '𝖄', Z: '𝖅',
        a: '𝖆', b: '𝖇', c: '𝖈', d: '𝖉', e: '𝖊', f: '𝖋', g: '𝖌', h: '𝖍', i: '𝖎', j: '𝖏', k: '𝖐', l: '𝖑', m: '𝖒', n: '𝖓', o: '𝖔', p: '𝖕', q: '𝖖', r: '𝖗', s: '𝖘', t: '𝖙', u: '𝖚', v: '𝖛', w: '𝖜', x: '𝖝', y: '𝖞', z: '𝖟',
    }
};

// Fungsi Konversi Manual Utama
const convertText = (text, style) => {
    // 1. Logika Strikethrough (Coret Tengah)
    if (style === 'strikethrough') {
        return text.split('').map(char => char + '\u0336').join('');
    }
    
    // 2. Logika Berbasis Map
    const map = FONT_MAPS[style];
    if (!map) return text;

    let converted = '';
    for (let char of text) {
        const upperChar = char.toUpperCase();
        let replacement = map[char];
        
        if (!replacement && char.match(/[a-zA-Z]/)) {
             replacement = map[upperChar];
        }

        converted += replacement || char; 
    }
    return converted;
};


// === Handler Utama ===
module.exports = {
    keyword: 'font', // Gunakan 'font' karena rezz.js akan menambahkan '/'
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const commandParts = msg.text.split(/(\s+)/).filter(s => s.trim().length > 0);
        
        const fontName = commandParts[1] ? commandParts[1].toLowerCase() : null;
        const textToConvert = commandParts.slice(2).join(' '); 

        const availableFontNames = Object.keys(FONT_MAPS);

        if (!fontName || textToConvert.length === 0) {
            // Logika Pesan Bantuan/Error format
            const fontList = availableFontNames.map(name => `  /font ${name}`).join('\n');
            
            return bot.sendMessage(chatId, 
                `⚠️ <b>Penggunaan Salah.</b>\n` +
                `ᴄᴏɴᴛᴏʜ: <code>/font [nama font] [teks yang ingin diubah]</code>\n\n` +
                `<b>ᴛᴏᴛᴀʟ ${availableFontNames.length} ғᴏɴᴛ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ:</b>\n` +
                `<pre>${fontList}</pre>`, 
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );
        }

        if (!availableFontNames.includes(fontName)) {
            // Logika Pesan Font Tidak Ditemukan
            const fontList = availableFontNames.map(name => `  /font ${name}`).join('\n');
            
            return bot.sendMessage(chatId, 
                `✘ ғᴏɴᴛ b>${fontName}</b> ᴛɪᴅᴀᴋ ᴛᴇʀsᴇᴅɪᴀᴀ.\n\n` +
                `<b>ғᴏɴᴛ ʏᴀɴɢ ᴛᴇʀsᴇᴅɪᴀ:</b>\n` +
                `<pre>${fontList}</pre>`, 
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );
        }
        
        try {
            const convertedText = convertText(textToConvert, fontName);

            if (convertedText && convertedText.trim() !== '') {
                await bot.sendMessage(chatId, 
                    `📝 <b>𝗙𝗢𝗡𝗧 𖣘 ${fontName.toUpperCase()}</b>\n\n${convertedText}`, 
                    { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
                ); 

            } else {
                 await bot.sendMessage(chatId, 
                    '✘ Gagal mengkonversi teks. Mungkin teks terlalu panjang atau berisi karakter yang tidak didukung.', 
                    { reply_to_message_id: msg.message_id }
                );
            }

        } catch (error) {
            console.error(`[FONT ERROR] Gagal mengubah font: ${error.message}`);
            bot.sendMessage(chatId, '✘ Terjadi kesalahan internal saat mencoba mengubah font.', { reply_to_message_id: msg.message_id });
        }
    }
};