const Pengguna = require('../../lib/pengguna');

module.exports = {
    keyword: 'history',
    keywordAliases: ['/history', 'riwayat', 'historylist'], 
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // 1. Langsung ambil data user tanpa cek registrasi
        // Jika user belum pernah belanja, Pengguna.ambil otomatis mengembalikan history kosong []
        const dataUser = Pengguna.ambil(userId);
        const history = dataUser.history || [];

        // 2. Jika History Kosong (Belum pernah beli produk)
        if (history.length === 0) {
            return bot.sendMessage(chatId, "✘ **History Belanja Kosong**\nSepertinya kamu belum berbelanja hari ini. Silakan beli produk terlebih dahulu.", { 
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id 
            });
        }

        // 3. Susun List Belanjaan
        let pesan = `📜 **RIWAYAT BELANJA KAMU**\n`;
        pesan += `────────────────────\n`;

        history.forEach((item, index) => {
            pesan += `${index + 1}. 📦 *${item.produk}*\n`;
            pesan += `   💰 Harga: Rp ${Number(item.harga).toLocaleString('id-ID')}\n`;
            pesan += `   📅 Waktu: ${item.tanggal}\n`;
            pesan += `   💳 Via: ${item.metode}\n\n`;
        });

        pesan += `────────────────────\n`;
        pesan += `_Menampilkan ${history.length} transaksi terakhir._`;

        return bot.sendMessage(chatId, pesan, { 
            parse_mode: 'Markdown',
            reply_to_message_id: msg.message_id 
        });
    }
};