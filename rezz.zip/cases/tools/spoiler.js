// cases/spoiler.js (FINAL FIX SANITASI MARKDOWNV2)

module.exports = {
    keyword: '/spoiler', 
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const fullCommand = msg.text;
        
        // Ambil teks yang akan dispoiler (potong hanya /spoiler dan spasi pertama)
        const spoilerText = fullCommand.substring(fullCommand.indexOf(' ') + 1);

        if (!spoilerText || spoilerText.toLowerCase().trim() === '/spoiler') {
            const usage = `
Penggunaan salah!
Masukkan teks yang ingin di spoiler.

Contoh:
\`/spoiler [teks].\`
            `;
            // Menggunakan parse_mode: 'Markdown' untuk pesan bantuan agar lebih mudah
            return bot.sendMessage(chatId, usage, { parse_mode: 'Markdown' });
        }
        
        // --- 1. Sanitasi Teks untuk MarkdownV2 ---
        // Karakter yang HARUS di-escape di MarkdownV2: 
        // _ * [ ] ( ) ~ ` > # + - = | { } . !
        // Catatan: \ juga harus di-escape (menjadi \\)
        const escapeChars = /([_*[\]()~`>#+\-={}.!|])/g;
        
        // 1. Escape karakter yang sensitif di MarkdownV2
        const escapedText = spoilerText.replace(escapeChars, '\\$1');
        
        // --- 2. Bentuk Pesan Spoiler ---
        // Membungkus teks yang sudah di-escape dengan || || untuk spoiler
        const formattedSpoiler = `||${escapedText}||`;
        
        const response = `
PESAN YANG DI \\(SPOILER\\)

Klik teks di yang sudah di spoiler di bawah:

${formattedSpoiler}
        `.trim();
        
        // --- 3. Kirim Pesan ---
        try {
            await bot.sendMessage(chatId, response, { 
                parse_mode: 'MarkdownV2',
                // Pastikan juga meng-escape karakter di header (misal: tanda kurung)
                // Saya sudah meng-escape tanda kurung pada "(SPOILER)" di baris 'response'.
                reply_to_message_id: msg.message_id 
            });
        } catch (error) {
            console.error("Gagal mengirim pesan spoiler:", error.message);
            
            // Memberikan pesan error yang lebih jelas kepada user (menggunakan Markdown biasa)
            bot.sendMessage(chatId, `❌ Terjadi kesalahan saat membuat spoiler. Error: \`${error.message}\`. Pastikan teks Anda tidak terlalu kompleks.`, {
                parse_mode: 'Markdown'
            });
        }
    }
};