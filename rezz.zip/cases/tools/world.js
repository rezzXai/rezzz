// cases/world.js (TAMPILAN KALENDER RAPI DENGAN <pre>)

module.exports = {
    keyword: '/world', 
    handler: (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        // Mendapatkan waktu di Jakarta (WIB)
        const now = new Date();
        
        // Format untuk Hari/Tanggal Lengkap
        const formattedFullDate = new Intl.DateTimeFormat('id-ID', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric',
            timeZone: 'Asia/Jakarta' 
        }).format(now);
        
        // Format untuk Jam (Waktu)
        const formattedTime = new Intl.DateTimeFormat('id-ID', {
            hour: '2-digit',
            minute: '2-digit',
            second: '2-digit',
            timeZone: 'Asia/Jakarta' 
        }).format(now);

        // Ambil komponen terpisah untuk tampilan rapi
        const year = now.getFullYear();
        const month = new Intl.DateTimeFormat('id-ID', { month: 'long', timeZone: 'Asia/Jakarta' }).format(now);
        const date = now.getDate();
        
        // --- Konten Pesan dengan blok <pre> ---
        const response = 
            `𝙏𝙄𝙈𝙀 𝙄𝙎 𝙂𝙊𝙇𝘿 𒇫\n\n` +
            `<pre>` +
            ` ∘ Zona Waktu: Asia/Jakarta (WIB)\n` +
            ` ∘ Hari Lengkap: ${formattedFullDate}\n` +
            ` -------------------------------------\n` +
            ` ∘ Tanggal: ${date}\n` +
            ` ∘ Bulan:   ${month}\n` +
            ` ∘ Tahun:   ${year}\n` +
            ` -------------------------------------\n` +
            ` ∘ Pukul:   ${formattedTime} WIB\n` +
            `</pre>\n\n` +
            `sᴇʟᴀᴍᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ʙᴏᴛ𖤛.`;

        bot.sendMessage(chatId, response, { parse_mode: 'HTML' }); 
    }
};