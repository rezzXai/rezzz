module.exports = {

    keyword: 'tod',

    keywordAliases: ['truth', 'dare'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const command = msg.text.toLowerCase().split(/\s+/)[0];

        // Database tantangan lebih banyak & seru

        const listTruth = [

            "Siapa orang yang terakhir kamu kepoin di media sosial?",

            "Apa ketakutan terbesar kamu yang belum pernah kamu ceritakan ke siapa pun?",

            "Pernahkah kamu menyukai seseorang di grup ini secara diam-diam?",

            "Apa kebohongan terbesar yang pernah kamu katakan kepada orang tuamu?",

            "Sebutkan satu hal yang paling membuatmu merasa tidak percaya diri.",

            "Siapa mantan terindah yang diam-diam masih kamu ingat?",

            "Apa hal paling memalukan yang pernah kamu alami di depan umum?",

            "Kalau kamu bisa bertukar nasib dengan seseorang di grup ini, siapa itu?",

            "Apa hal paling ilegal yang pernah kamu lakukan?",

            "Pernahkah kamu pura-pura sakit supaya bisa bolos sekolah/kerja?",

            "Siapa orang di grup ini yang menurutmu paling menyebalkan?",

            "Apa rahasia yang kamu simpan rapat-rapat sampai sekarang?",

            "Pernahkah kamu kentut di tempat ramai lalu pura-pura tidak tahu?",

            "Apa aplikasi paling aneh yang ada di HP kamu?",

            "Sebutkan kriteria pacar idaman kamu sesungguhnya.",

            "Apa hal paling konyol yang pernah kamu lakukan saat jatuh cinta?",

            "Siapa orang terakhir yang kamu chat sebelum buka Telegram sekarang?",

            "Pernahkah kamu menangis karena film kartun?",

            "Apa hal yang paling kamu sesali dalam hidupmu?",

            "Sebutkan satu hal yang orang lain tidak tahu tentang dirimu."

        ];

        const listDare = [

            "Kirim pesan ke mantan kamu dan bilang 'Aku kangen', screenshot kirim ke sini!",

            "Rekam suara kamu nyanyi lagu 'Balonku' pakai bahasa alien lalu kirim ke grup ini.",

            "Ganti foto profil Telegram kamu jadi foto meme lucu/jelek selama 15 menit.",

            "Chat orang pertama di daftar chat kamu (selain bot), bilang 'Aku cinta kamu' tanpa alasan.",

            "Kirim stiker paling aneh/random yang kamu punya ke grup ini.",

            "Tulis di bio Telegram: 'Aku adalah asisten setia [Nama Member Grup]'.",

            "Puji semua orang di grup ini satu per satu dengan kalimat tulus.",

            "VC (Video Call) salah satu teman kamu, teriak 'Ada kecoa!' lalu langsung matikan.",

            "Kirim screenshot galeri foto terakhir di HP kamu.",

            "Bikin pesan suara (Voice Note) niruin suara ayam berkokok selama 10 detik.",

            "Ketik 'AKU BAU' di 3 grup berbeda yang kamu punya.",

            "Kirim VN bilang 'I Love You' ke salah satu admin di grup ini.",

            "Jangan chat di grup ini selama 10 menit (diam adalah emas).",

            "Sebutkan 3 kekurangan admin grup ini secara blak-blakan.",

            "Cari foto random di Google tentang 'Ular' lalu kirim ke sini.",

            "Kirim link video YouTube terakhir yang kamu tonton ke grup ini.",

            "Spam stiker sebanyak 5 kali berturut-turut sekarang juga!",

            "Ketik nama kamu menggunakan hidung di chat ini.",

            "Ajak salah satu member di grup ini untuk jadian (hanya becanda).",

            "Ganti nama Telegram kamu jadi 'Hamba Allah' selama 1 jam."

        ];

        let hasil = "";

        let judul = "";

        // Logika penentuan Truth atau Dare

        if (command.includes('truth')) {

            judul = "🧐 **TRUTH (KEJUJURAN)**";

            hasil = listTruth[Math.floor(Math.random() * listTruth.length)];

        } else if (command.includes('dare')) {

            judul = "🔥 **DARE (TANTANGAN)**";

            hasil = listDare[Math.floor(Math.random() * listDare.length)];

        } else {

            // Menu utama jika hanya ketik /tod

            let menu = `🎮 **TRUTH OR DARE GAME**\n\n`;

            menu += `Tantangan tersedia.\n\n`;

            menu += `🔹 Ketik \`/truth\` untuk tantangan kejujuran.\n`;

            menu += `🔹 Ketik \`/dare\` untuk tantangan aksi.\n\n`;

            menu += `_Pilih salah satu dan jangan jadi penakut!_`;

            return bot.sendMessage(chatId, menu, { parse_mode: 'Markdown' });

        }

        let pesan = `${judul}\n`;

        pesan += `──────────────────\n`;

        pesan += `👉 *${hasil}*\n`;

        pesan += `──────────────────\n`;

        pesan += `_Cepat lakukan atau kamu cupu!_`;

        await bot.sendMessage(chatId, pesan, { 

            parse_mode: 'Markdown',

            reply_to_message_id: msg.message_id 

        });

    }

};