// cases/urlcheck.js (Pengecek Status URL/Website - FIXED)

const axios = require('axios');

module.exports = {
    keyword: 'checkurl',
    keywordAliases: ['/checkurl', '/urlcheck', '/status'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const args = msg.text.split(' ').slice(1);
        
        if (args.length === 0) {
            return bot.sendMessage(chatId, 
                "✘ sᴀʟᴀʜ ᴏᴍ\n" +
                "ᴄᴏɴᴛᴏʜ: `/checkurl https://google.com`",
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        let url = args[0];
        
        // Validasi dan Koreksi Format URL
        if (!url.startsWith('http://') && !url.startsWith('https://')) {
            url = 'https://' + url;
        }

        // <<< PERBAIKAN UTAMA: Deklarasi startTime di luar blok try/catch >>>
        let startTime = Date.now(); 

        const waitMessage = await bot.sendMessage(chatId, `⏳ Sedang memeriksa status **${url}**...`, { 
            parse_mode: 'Markdown', 
            reply_to_message_id: msg.message_id 
        });

        try {
            // Set/Update nilai startTime tepat sebelum mengirim request
            startTime = Date.now();
            
            // Kirim Permintaan HEAD
            const response = await axios.head(url, {
                maxRedirects: 0, 
                timeout: 10000 
            });
            
            // Hitung Latency
            const latency = Date.now() - startTime;
            
            const statusCode = response.status;
            let statusText = '';
            let statusEmoji = '';

            // Tentukan status berdasarkan Kode HTTP
            if (statusCode >= 200 && statusCode < 300) {
                statusEmoji = '✔';
                statusText = '𝗔𝗖𝗧𝗜𝗩𝗘';
            } else if (statusCode >= 300 && statusCode < 400) {
                statusEmoji = '🔄';
                statusText = `Dialihkan (Redirect)`;
            } else if (statusCode >= 400 && statusCode < 500) {
                statusEmoji = '⚠️';
                statusText = '𝗘𝗥𝗢𝗥';
            } else if (statusCode >= 500) {
                statusEmoji = '✘';
                statusText = '𝗦𝗘𝗥𝗩𝗘𝗥 𝗘𝗥𝗢𝗥';
            } else {
                 statusEmoji = '❓';
                 statusText = '𝗡𝗢𝗧 𝗙𝗢𝗨𝗡𝗗';
            }

            // Kirim Hasil
            const resultMessage = 
                `${statusEmoji} **𝗛𝗔𝗦𝗜𝗟 𝗖𝗛𝗘𝗖𝗞**\n\n` +
                `*URL:* \`${url}\`\n` +
                `*Status:* **${statusText}**\n` +
                `*Kode HTTP:* \`${statusCode}\`\n` +
                `*Waktu Respons (Latency):* **${latency}ms**`;

            await bot.editMessageText(resultMessage, {
                chat_id: chatId,
                message_id: waitMessage.message_id,
                parse_mode: 'Markdown'
            });

        } catch (error) {
            // Latency dapat dihitung di sini tanpa ReferenceError
            const latency = Date.now() - startTime; 
            
            // Tangani error seperti Timeout, DNS failure, atau status code 4xx/5xx yang dianggap error
            let errorMessage = 'Tidak Diketahui';
            
            if (error.code === 'ECONNABORTED' || error.code === 'ETIMEDOUT') {
                errorMessage = `Waktu Habis (timeout ${latency}ms)`;
            } else if (error.response) {
                // Jika error disebabkan oleh status code 4xx/5xx
                errorMessage = `Kode Error HTTP: ${error.response.status} ${error.response.statusText}`;
            } else if (error.code === 'ENOTFOUND') {
                errorMessage = 'Domain tidak ditemukan (DNS Error)';
            } else {
                errorMessage = `Error Jaringan: ${error.message}`;
            }

            const failureMessage = 
                `✘ **𝗪𝗘𝗕 𝗗𝗢𝗪𝗡**\n\n` +
                `*URL:* \`${url}\`\n` +
                `*Penyebab:* ${errorMessage}\n` +
                `*Waktu Respons:* **${latency}ms**`;
            
            await bot.editMessageText(failureMessage, {
                chat_id: chatId,
                message_id: waitMessage.message_id,
                parse_mode: 'Markdown'
            });
        }
    }
};