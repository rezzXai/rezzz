// =================================================================
// CASES/ASCII.JS - GENERATOR TEKS SENI (Pembatasan 1 Kata)
// =================================================================

// --- Peta Karakter ASCII (Menggunakan # sebagai Blok) ---
const ASCII_MAP = {
    // Keterangan: # = Blok, Spasi = Kosong
    'A': [' ### ', '#   #', '#####', '#   #', '#   #'],
    'B': ['#### ', '#   #', '#### ', '#   #', '#### '],
    'C': [' ### ', '#   #', '#    ', '#   #', ' ### '],
    'D': ['#### ', '#   #', '#   #', '#   #', '#### '],
    'E': ['#####', '#    ', '###  ', '#    ', '#####'],
    'F': ['#####', '#    ', '###  ', '#    ', '#    '],
    'G': [' ### ', '#    ', '# #  ', '#   #', ' ### '],
    'H': ['#   #', '#   #', '#####', '#   #', '#   #'],
    'I': ['#####', '  #  ', '  #  ', '  #  ', '#####'],
    'J': ['#####', '  #  ', '  #  ', '# #  ', ' ##  '],
    'K': ['#  #', '# # ', '##  ', '# # ', '#  #'],
    'L': ['#    ', '#    ', '#    ', '#    ', '#####'],
    'M': ['# # #', '# # #', '# # #', '#   #', '#   #'],
    'N': ['#   #', '##  #', '# # #', '#  ##', '#   #'],
    'O': [' ### ', '#   #', '#   #', '#   #', ' ### '],
    'P': ['#### ', '#   #', '#### ', '#    ', '#    '],
    'Q': [' ### ', '#   #', '# # #', '#  ##', ' ###Q'],
    'R': ['#### ', '#   #', '#### ', '# #  ', '#  ##'],
    'S': [' ####', '#    ', ' ### ', '    #', '#### '],
    'T': ['#####', '  #  ', '  #  ', '  #  ', '  #  '],
    'U': ['#   #', '#   #', '#   #', '#   #', ' ### '],
    'V': ['#   #', '#   #', '#   #', ' # # ', '  #  '],
    'W': ['#   #', '#   #', '# # #', '# # #', ' # # #'],
    'X': ['#   #', ' # # ', '  #  ', ' # # ', '#   #'],
    'Y': ['#   #', ' # # ', '  #  ', '  #  ', '  #  '],
    'Z': ['#####', '   # ', '  #  ', ' #   ', '#####'],

    '0': [' ### ', '# # #', '# # #', '# # #', ' ### '],
    '1': ['  #  ', ' ##  ', '  #  ', '  #  ', '#####'],
    '2': ['#### ', '    #', ' ### ', '#    ', '#####'],
    '3': ['#### ', '    #', ' ### ', '    #', '#### '],
    '4': ['#  # ', '#  # ', '#####', '   # ', '   # '],
    '5': ['#####', '#    ', '#### ', '    #', '#### '],
    '6': [' ### ', '#    ', '#### ', '#   #', ' ### '],
    '7': ['#####', '    #', '   # ', '  #  ', ' #   '],
    '8': [' ### ', '#   #', ' ### ', '#   #', ' ### '],
    '9': [' ### ', '#   #', ' ####', '    #', ' ### '],
    
    ' ': ['     ', '     ', '     ', '     ', '     '], 
    '!': ['  #  ', '  #  ', '  #  ', '     ', '  #  '],
    '?': [' ### ', '#   #', '  ## ', '     ', '  #  '],
    '.': ['     ', '     ', '     ', '     ', '  #  '],
    '-': ['     ', '#####', '     ', '     ', '     '],
};

const HEIGHT = 5;

const convertToAscii = (text) => {
    const lines = Array(HEIGHT).fill(''); 
    const upperText = text.toUpperCase();

    for (let i = 0; i < upperText.length; i++) {
        const char = upperText[i];
        
        // Gunakan mapping karakter, jika tidak ada, gunakan spasi.
        const charMap = ASCII_MAP[char] || ASCII_MAP[' ']; 

        for (let j = 0; j < HEIGHT; j++) {
            // Gabungkan baris saat ini, dan tambahkan spasi pemisah tunggal (ini adalah padding yang Anda pertahankan)
            lines[j] += charMap[j] + '  '; 
        }
    }
    
    // Gabungkan semua baris
    return lines.join('\n');
};

// === Handler Utama ===
module.exports = {
    keyword: 'ascii', 
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        // Pisahkan teks menjadi array kata
        const args = msg.text.trim().split(/\s+/).slice(1);
        
        if (args.length === 0) {
            return bot.sendMessage(chatId, 
                '✘ ᴋᴇsᴀʟᴀʜᴀɴ\n\n' +
                'ᴄᴏɴᴛᴏʜ:  /ᴀsᴄɪɪ ʀᴇᴢɪ ',
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
            );
        }

        // --- Perubahan Kunci: Validasi 1 Kata ---
        if (args.length > 1) {
             return bot.sendMessage(chatId, 
                '✘ ʜᴀɴʏᴀ ᴍᴇɴᴅᴜᴋᴜɴɢ 1 ᴛᴇᴋs sᴀᴊᴀ.\n\n' +
                'ᴋᴇsᴀʟᴀʜᴀɴ ᴍᴇɴɢᴇᴛɪᴋ: `' + args.join(' ') + '`', 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
            );
        }

        // Jika hanya ada 1 kata, ambil kata tersebut
        const textToConvert = args[0]; 

        if (textToConvert.length > 20) {
             return bot.sendMessage(chatId, 
                '✘ ᴛᴇᴋs ʟɪᴍɪᴛ [ᴍɪɴɪᴍᴀʟ 20 ᴋᴀᴛᴀ].', 
                { reply_to_message_id: msg.message_id }
            );
        }
        
        try {
            const asciiText = convertToAscii(textToConvert);

            // Kirim hasil, dibungkus dalam tag <pre> dan ParseMode: HTML
            await bot.sendMessage(chatId,
                `𝗔𝗦𝗖𝗜𝗜 𝗖𝗢𝗡𝗩𝗘𝗥𝗧 ✔\n\n<pre>${asciiText}</pre>`,
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id }
            );

        } catch (error) {
            console.error(`[ASCII COMMAND ERROR] Gagal membuat ASCII Art: ${error.message}`);
            bot.sendMessage(chatId, '✘ ᴇʀᴏʀ sᴀᴀᴛ ᴍᴇᴍᴘʀᴏsᴇs ᴀsᴄɪɪ.', { reply_to_message_id: msg.message_id });
        }
    }
};