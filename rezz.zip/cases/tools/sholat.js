const axios = require('axios');

module.exports = {

    keyword: 'sholat',

    keywordAliases: ['jadwalsholat', 'jadwal'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const args = msg.text.trim().split(/\s+/).slice(1).join(" ");

        if (!args) {

            return bot.sendMessage(chatId, "✘ Masukkan nama kota!\nContoh: `/sholat Jakarta` atau `/sholat Surabaya`", { parse_mode: 'Markdown' });

        }

        try {

            // 1. Mencari ID Kota berdasarkan nama kota yang diinput user

            const searchCity = await axios.get(`https://api.myquran.com/v2/sholat/kota/cari/${encodeURIComponent(args)}`);

            

            if (!searchCity.data.status || searchCity.data.data.length === 0) {

                return bot.sendMessage(chatId, `✘ Kota **"${args}"** tidak ditemukan.`, { parse_mode: 'Markdown' });

            }

            const cityId = searchCity.data.data[0].id;

            const cityName = searchCity.data.data[0].lokasi;

            // 2. Mengambil Jadwal Sholat berdasarkan ID Kota dan Tanggal hari ini

            const date = new Date();

            const y = date.getFullYear();

            const m = String(date.getMonth() + 1).padStart(2, '0');

            const d = String(date.getDate()).padStart(2, '0');

            const response = await axios.get(`https://api.myquran.com/v2/sholat/jadwal/${cityId}/${y}/${m}/${d}`);

            const jadwal = response.data.data.jadwal;

            let pesan = `🕌 **JADWAL SHOLAT HARI INI**\n`;

            pesan += `📍 **Lokasi**: ${cityName}\n`;

            pesan += `📅 **Tanggal**: ${jadwal.tanggal}\n\n`;

            pesan += `✨ **Imsak**: ${jadwal.imsak}\n`;

            pesan += `✨ **Subuh**: ${jadwal.subuh}\n`;

            pesan += `✨ **Terbit**: ${jadwal.terbit}\n`;

            pesan += `✨ **Dhuha**: ${jadwal.dhuha}\n`;

            pesan += `✨ **Dzuhur**: ${jadwal.dzuhur}\n`;

            pesan += `✨ **Ashar**: ${jadwal.ashar}\n`;

            pesan += `✨ **Maghrib**: ${jadwal.maghrib}\n`;

            pesan += `✨ **Isya**: ${jadwal.isya}\n\n`;

            pesan += `_Waktu berdasarkan zona wilayah setempat._`;

            await bot.sendMessage(chatId, pesan, { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        } catch (e) {

            console.error(`🔴 Error Sholat: ${e.message}`);

            bot.sendMessage(chatId, "❌ Terjadi gangguan saat mengambil data jadwal sholat.");

        }

    }

};