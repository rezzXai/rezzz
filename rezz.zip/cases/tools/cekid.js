const path = require('path');
const fs = require('fs');
const Pengguna = require('../../lib/pengguna'); 

const ID_IMAGE_PATH = path.join(__dirname, '..', '28.jpg'); 
const dbLimitPath = path.join(__dirname, '../../database/adddbtoken.json');

module.exports = {
    keyword: 'cekid',
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        const receivedUserId = msg.from.id;
        
        let actualUserId = receivedUserId;
        let status, icon;
        
        const isAnonymous = msg.from.username === 'GroupAnonymousBot' || !!msg.sender_chat;
        const ownerIds = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID.map(id => Number(id)) : [Number(settings.OWNER_ID)];
        const isOwnerBot = ownerIds.includes(Number(receivedUserId));

        // Penentuan Status & Icon
        if (isOwnerBot && !isAnonymous) {
            status = 'OWNER PUSAT';
            icon = '⚡';
        } else if (isAnonymous) {
            actualUserId = ownerIds[0];
            status = 'ADMINISTRATOR';
            icon = '🛡️';
        } else {
            status = 'CUSTOMER';
            icon = '👤';
        }

        // Ambil Data Saldo
        const dataUser = Pengguna.ambil(actualUserId);
        const saldoDisplay = `Rp ${dataUser.saldo.toLocaleString('id-ID')}`;

        // Ambil Data Limit AddToken
        let limitDisplay = "0";
        if (isOwnerBot) {
            limitDisplay = "UNLIMITED";
        } else if (fs.existsSync(dbLimitPath)) {
            const dbLimit = JSON.parse(fs.readFileSync(dbLimitPath));
            if (dbLimit[actualUserId]) {
                limitDisplay = `${dbLimit[actualUserId].limit}x`;
            }
        }

        // --- TAMPILAN BARU (LEBIH ELEGAN) ---
        const response = 
            ` <b>𓁹 𝗣𝗥𝗢𝗙𝗜𝗟𝗘</b> \n` +
            `<i>Informasi data</i>\n\n` +
            `<blockquote>` +
            `🆔 <b>ID AKUN:</b> <code>${actualUserId}</code>\n` +
            `🏷️ <b>STATUS:</b> ${icon} ${status}\n` +
            `💰 <b>SALDO:</b> ${saldoDisplay}\n` +
            `🎫 <b>LIMIT TOKEN:</b> ${limitDisplay}` +
            `</blockquote>\n` +
            `📅 <b>:</b> <code>${new Date().toLocaleString('id-ID', {timeZone: 'Asia/Jakarta'})} WIB</code>\n\n` +
            `<i>Hargai Dev @ziistr</i>`;
            
        let photoFileId = null;

        try {
            const profilePhotos = await bot.getUserProfilePhotos(actualUserId, { limit: 1 });
            if (profilePhotos.total_count > 0) {
                photoFileId = profilePhotos.photos[0][profilePhotos.photos[0].length - 1].file_id;
            }
        } catch (e) {}

        const options = {
            caption: response,
            parse_mode: 'HTML', // Ganti ke HTML agar blockquote jalan
            reply_to_message_id: msg.message_id
        };

        // Kirim Pesan
        if (photoFileId) {
            await bot.sendPhoto(chatId, photoFileId, options).catch(() => 
                bot.sendMessage(chatId, response, options)
            );
        } else if (fs.existsSync(ID_IMAGE_PATH)) {
            await bot.sendPhoto(chatId, ID_IMAGE_PATH, options).catch(() => 
                bot.sendMessage(chatId, response, options)
            );
        } else {
            await bot.sendMessage(chatId, response, options);
        }
    }
};