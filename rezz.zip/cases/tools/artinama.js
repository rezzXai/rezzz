// cases/artinama.js (FITUR BARU: Arti Nama Random)

module.exports = {
    keyword: 'artinama', 
    keywordAliases: ['/artinama'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const args = msg.text.slice(msg.entities[0].length).trim(); 
        
        if (!args) {
            return bot.sendMessage(chatId, 
                "❌ **Format Salah.**\n\n" +
                "Gunakan: `/artinama [nama Anda]`\n" +
                "Contoh: `/artinama Budi Santoso`", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const inputName = args;

        // --- KOMPONEN ARTI NAMA (DATA RANDOM) ---
        // Komponen 1: Sifat / Karakteristik
        const sifat = [
            "Penuh gairah dan karisma",
            "Sering rebahan tapi sukses",
            "Mempunyai takdir yang unik",
            "Sosok yang misterius dan pendiam",
            "Selalu menjadi pusat perhatian",
            "Anti-gagal dalam mencari cuan",
            "Pemaaf, tetapi tukang dendam",
            "Sangat ambisius dan keras kepala"
        ];
        
        // Komponen 2: Profesi / Takdir Masa Depan
        const takdir = [
            "akan menjadi bos besar di bidang perabot rumah tangga",
            "adalah seorang penemu rumus matematika yang gagal terkenal",
            "ditakdirkan menjadi atlet e-sport profesional di usia senja",
            "adalah ahli nujum modern yang merangkap tukang parkir",
            "diprediksi akan sukses besar setelah berhenti jadi *developer*",
            "memiliki bakat terpendam sebagai penyanyi dangdut koplo",
            "akan memenangkan lotre setelah menolong seekor kucing oren"
        ];
        
        // Komponen 3: Peringatan / Nasihat
        const peringatan = [
            "namun harus waspada terhadap godaan diskon tengah malam.",
            "jangan lupakan jasa orang yang pernah minjami uang.",
            "dan dia akan selalu ditemani oleh khodam cicak bunglon.",
            "namun nasibnya tergantung pada harga kopi hari itu.",
            "dan perlu rajin minum air putih agar tidak cepat kaya.",
            "tetapi harus segera menghapus *history browser*."
        ];
        
        // --- LOGIKA RANDOM ---
        const randomSifat = sifat[Math.floor(Math.random() * sifat.length)];
        const randomTakdir = takdir[Math.floor(Math.random() * takdir.length)];
        const randomPeringatan = peringatan[Math.floor(Math.random() * peringatan.length)];
        
        // Gabungkan 3 komponen menjadi satu arti
        const artiLengkap = 
            `Arti nama Anda adalah: \n\n` +
            `*${randomSifat}*,\n` +
            `dan *${randomTakdir}*,\n` +
            `*${randomPeringatan}*`;

        // --- PESAN RESPON AKHIR ---
        let responseMessage = 
            `📜 **ARTI NAMA UNTUK "${inputName.toUpperCase()}"** 📜\n\n` +
            `Berdasarkan data kuno yang diacak oleh RezzXai, ini adalah arti nama Anda:\n\n` +
            `${artiLengkap}\n\n` +
            `*Disclaimer: Hasil ini 100% acak, jangan dianggap serius!*`;

        try {
            await bot.sendMessage(chatId, responseMessage, { 
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id 
            });
        } catch (error) {
            console.error(`Gagal mengirim pesan artinama: ${error.message}`);
            await bot.sendMessage(chatId, `❌ Gagal memproses arti nama. Terjadi kesalahan pada bot.`);
        }
    }
};