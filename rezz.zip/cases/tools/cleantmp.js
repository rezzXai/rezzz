const fs = require('fs');

const path = require('path');

const { OWNER_ID } = require('../../setting');

module.exports = {

    keyword: 'cleantmp',

    keywordAliases: ['/cleantmp', 'cleartemp', 'hapussampah'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // PROTEKSI OWNER

        if (Number(userId) !== Number(OWNER_ID)) {

            return bot.sendMessage(chatId, 

`✘ <b>𝙂𝘼 𝘽𝙄𝙎𝘼 𝘽𝙀𝙂𝙊</b>

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS : REJECTED

INFO   : Hanya Owner yang

         bisa bersih-bersih.

━━━━━━━━━━━━━━━━━━━━

</pre>`, { parse_mode: 'HTML' });

        }

        const tempDir = path.join(__dirname, '../temp');

        try {

            // Cek apakah folder temp ada

            if (!fs.existsSync(tempDir)) {

                return bot.sendMessage(chatId, "📁 <pre>Folder /temp tidak ditemukan.</pre>", { parse_mode: 'HTML' });

            }

            const files = fs.readdirSync(tempDir);

            let count = 0;

            // Proses penghapusan file

            files.forEach(file => {

                const fullPath = path.join(tempDir, file);

                // Pastikan yang dihapus adalah file (bukan folder)

                if (fs.lstatSync(fullPath).isFile()) {

                    fs.unlinkSync(fullPath);

                    count++;

                }

            });

            if (count === 0) {

                return bot.sendMessage(chatId, " <pre>✔ Folder temp sudah bersih!</pre>", { parse_mode: 'HTML' });

            }

            const reply = 

`🧹 <b>𝙏𝙀𝙈𝙋 𝘾𝙇𝙀𝘼𝙉𝙀𝙍</b>

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS  : SUCCESS

CLEANED : ${count} Files

TARGET  : /temp/ *

━━━━━━━━━━━━━━━━━━━━

</pre>

<i>File sampah berhasil dihapus!</i>`;

            await bot.sendMessage(chatId, reply, { parse_mode: 'HTML' });

        } catch (e) {

            bot.sendMessage(chatId, `❌ <b>ERROR</b>\n<pre>${e.message}</pre>`, { parse_mode: 'HTML' });

        }

    }

};