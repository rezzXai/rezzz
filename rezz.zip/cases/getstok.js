// cases/getstok.js (Mengambil Stok Universal)

const { findProduct } = require('../lib/stokdb');

module.exports.getstok = {
    keyword: '/getstok',
    keywordAliases: ['getstok'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const args = msg.text.split(' ').slice(1).join(' ').trim();
        
        // Cek jika pengguna adalah OWNER (opsional, untuk testing)
        if (String(msg.from.id) !== String(settings.OWNER_ID)) {
             return bot.sendMessage(chatId, "❌ **Akses Ditolak:** Perintah ini hanya untuk Owner.", { reply_to_message_id: msg.message_id });
        }
        
        if (!args) {
            return bot.sendMessage(chatId, '❌ **Kesalahan:** Mohon sertakan NAMA PRODUK yang dicari.\nContoh: `/getstok SC AUTO ORDER`', { parse_mode: 'Markdown' });
        }
        
        const productName = args.toUpperCase();
        const product = findProduct(productName);

        if (!product) {
            return bot.sendMessage(chatId, `⚠️ **Stok Tidak Ditemukan:** Produk **${productName}** tidak ada di database.`, { parse_mode: 'Markdown' });
        }
        
        // --- 1. Buat Caption Universal ---
        const caption = 
            `✅ **DETAIL STOK DITEMUKAN (Universal)**\n\n` +
            `📦 **Nama:** ${product.nameDisplay}\n` +
            `💵 **Harga:** Rp ${product.price.toLocaleString('id-ID')}\n` +
            `📝 **Deskripsi:** ${product.description || 'Tidak ada'}\n` +
            `💾 **Tipe Data Tersimpan:** ${product.fileType.toUpperCase()}\n\n` +
            `${product.extraItems ? '--- Data Tambahan ---\n' + product.extraItems : ''}`; // Tambahkan data item tambahan
            
        try {
            // --- 2. Kirim Berdasarkan Tipe Data yang Tersimpan (Universal) ---
            if (product.fileType === 'document') {
                await bot.sendDocument(chatId, product.fileId, { caption: caption, parse_mode: 'Markdown' });
            } else if (product.fileType === 'photo') {
                await bot.sendPhoto(chatId, product.fileId, { caption: caption, parse_mode: 'Markdown' });
            } else {
                // Tipe Teks/Link (termasuk extraItems)
                await bot.sendMessage(chatId, caption, { parse_mode: 'Markdown' });
            }
        } catch (error) {
            console.error(`🔴 Gagal mengirim file ID ${product.fileId} (${product.fileType}):`, error.message);
            await bot.sendMessage(chatId, 
                `⚠️ **Peringatan:** Detail stok ditemukan, tetapi **gagal mengirim file/foto/link** yang tersimpan.\n` +
                `Pesan error: \`${error.message}\`\n\n` +
                `Detail Teks: ${caption}`, 
                { parse_mode: 'Markdown' }
            );
        }
    }
};