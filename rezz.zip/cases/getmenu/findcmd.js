const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'findcmd',

    handler: async (bot, msg) => {

        if (!global.isOwner(msg.from.id)) return;

        const args = msg.text.split(/\s+/)[1];

        if (!args) return bot.sendMessage(msg.chat.id, "⚠️ Contoh: /findcmd API_KEY");

        const rootPath = path.join(__dirname, '../../'); 

        let results = [];

        const ignoredFolders = ['node_modules', '.git', '.npm', 'tmp', '.cache', 'dist'];

        // Fungsi Escape HTML manual agar simbol tidak merusak format

        const clean = (text) => {

            return text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

        };

        const searchEverywhere = (dir) => {

            const files = fs.readdirSync(dir);

            files.forEach(file => {

                const fullPath = path.join(dir, file);

                const stat = fs.statSync(fullPath);

                if (stat.isDirectory()) {

                    if (!ignoredFolders.includes(file)) {

                        searchEverywhere(fullPath);

                    }

                } else if (file.endsWith('.js') || file.endsWith('.json')) {

                    try {

                        const content = fs.readFileSync(fullPath, 'utf8');

                        if (content.toLowerCase().includes(args.toLowerCase())) {

                            const relativePath = path.relative(rootPath, fullPath);

                            results.push(relativePath);

                        }

                    } catch (e) {}

                }

            });

        };

        try {

            // Pesan awal tanpa HTML agar tidak error byte offset

            await bot.sendMessage(msg.chat.id, `🔍 Sedang mencari teks "${args}" di seluruh file bot...`);

            

            searchEverywhere(rootPath);

            if (results.length === 0) {

                return bot.sendMessage(msg.chat.id, `❌ Teks "${args}" tidak ditemukan di file manapun.`);

            }

            // Batasi hasil pencarian agar pesan tidak kepanjangan

            const displayedResults = results.slice(0, 30);

            let response = `<b>✅ Ditemukan di ${results.length} lokasi:</b>\n\n`;

            

            displayedResults.forEach((res, i) => {

                // Gunakan <code> agar path file bisa diklik/copy dan aman dari error parse

                response += `${i + 1}. <code>${clean(res)}</code>\n`;

            });

            if (results.length > 30) {

                response += `\n<i>...dan ${results.length - 30} file lainnya.</i>`;

            }

            response += `\n\n💡 Gunakan <code>/getfile [path]</code> untuk mengambil file.`;

            await bot.sendMessage(msg.chat.id, response, { parse_mode: 'HTML' });

        } catch (err) {

            bot.sendMessage(msg.chat.id, "❌ Terjadi kesalahan: " + err.message);

        }

    }

};