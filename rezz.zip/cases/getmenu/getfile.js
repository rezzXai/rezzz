const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'getfile',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // Cek akses Owner

        if (!global.isOwner(userId)) return;

        const args = msg.text.split(/\s+/);

        const fileName = args[1];

        if (!fileName) {

            return bot.sendMessage(chatId, "⚠️ **Format Salah!**\nContoh: `/getfile database/premium.json`", { parse_mode: 'Markdown' });

        }

        // Path ke root folder bot (naik 2 tingkat dari cases/owner/)

        const filePath = path.join(__dirname, '../../', fileName);

        if (fs.existsSync(filePath)) {

            bot.sendMessage(chatId, `⏳ Sedang mengambil file: \`${fileName}\`...`, { parse_mode: 'Markdown' });

            try {

                await bot.sendDocument(chatId, filePath, { caption: `📄 **File Berhasil Diambil**\nPath: \`${fileName}\``, parse_mode: 'Markdown' });

            } catch (e) {

                bot.sendMessage(chatId, `❌ **Gagal mengirim file:**\n${e.message}`);

            }

        } else {

            bot.sendMessage(chatId, `❌ **File tidak ditemukan!**\nPastikan path benar. Contoh: \`database/users.json\``, { parse_mode: 'Markdown' });

        }

    }

};