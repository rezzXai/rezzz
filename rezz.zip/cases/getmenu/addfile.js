const fs = require('fs');

const path = require('path');

const axios = require('axios');

module.exports = {

    keyword: 'addfile',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // 1. KEAMANAN: Wajib Owner

        if (!global.isOwner(userId)) return;

        // 2. CEK APAKAH USER MELAKUKAN REPLY KE DOCUMENT

        if (!msg.reply_to_message || !msg.reply_to_message.document) {

            return bot.sendMessage(chatId, "⚠️ **Cara Pakai:**\nReply file `.js` atau file apa pun, lalu ketik:\n`/addfile [path/folder/]`\n\nContoh: `/addfile cases/owner/`", { parse_mode: 'Markdown' });

        }

        // 3. AMBIL PATH TUJUAN DARI PESAN

        const targetFolder = msg.text.split(/\s+/)[1] || './'; // Default ke root folder jika kosong

        const doc = msg.reply_to_message.document;

        const fileName = doc.file_name;

        // Tentukan path lengkap file yang akan disimpan

        const targetPath = path.join(__dirname, '../../', targetFolder, fileName);

        const absoluteFolder = path.join(__dirname, '../../', targetFolder);

        bot.sendMessage(chatId, `⏳ Sedang mengunggah \`${fileName}\` ke \`${targetFolder}\`...`, { parse_mode: 'Markdown' });

        try {

            // 4. BUAT FOLDER JIKA BELUM ADA

            if (!fs.existsSync(absoluteFolder)) {

                fs.mkdirSync(absoluteFolder, { recursive: true });

            }

            // 5. AMBIL LINK DOWNLOAD FILE DARI TELEGRAM

            const fileInfo = await bot.getFile(doc.file_id);

            const fileUrl = `https://api.telegram.org/file/bot${bot.token}/${fileInfo.file_path}`;

            // 6. DOWNLOAD DAN SIMPAN KE VPS

            const response = await axios({

                url: fileUrl,

                method: 'GET',

                responseType: 'stream'

            });

            const writer = fs.createWriteStream(targetPath);

            response.data.pipe(writer);

            writer.on('finish', () => {

                bot.sendMessage(chatId, `✅ **Berhasil!**\nFile \`${fileName}\` telah disimpan di folder \`${targetFolder}\`.`, { parse_mode: 'Markdown' });

            });

            writer.on('error', (err) => {

                bot.sendMessage(chatId, `❌ **Gagal menulis file:** ${err.message}`);

            });

        } catch (e) {

            bot.sendMessage(chatId, `❌ **Error:** ${e.message}`);

        }

    }

};