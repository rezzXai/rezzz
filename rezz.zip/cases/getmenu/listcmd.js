const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'listcmd',

    handler: async (bot, msg) => {

        if (!global.isOwner(msg.from.id)) return;

        const casesPath = path.join(__dirname, '../../cases');

        let allLines = [];

        let totalCmd = 0;

        // Fungsi Escape HTML agar simbol tidak merusak format

        const escapeHTML = (text) => {

            return text

                .replace(/&/g, "&amp;")

                .replace(/</g, "&lt;")

                .replace(/>/g, "&gt;");

        };

        const readCommands = (dir) => {

            const files = fs.readdirSync(dir);

            files.forEach(file => {

                const fullPath = path.join(dir, file);

                const stat = fs.statSync(fullPath);

                if (stat.isDirectory()) {

                    readCommands(fullPath);

                } else if (file.endsWith('.js')) {

                    try {

                        const cmd = require(fullPath);

                        if (cmd.keyword) {

                            totalCmd++;

                            const category = path.basename(path.dirname(fullPath));

                            // Format: [Nomor] /keyword (folder/file.js)

                            allLines.push(`${String(totalCmd).padStart(3, '0')}. /${cmd.keyword.padEnd(15)} (${category}/${file})`);

                        }

                        delete require.cache[require.resolve(fullPath)];

                    } catch (e) {

                        allLines.push(`ERR. [${file}] - Gagal Muat`);

                    }

                }

            });

        };

        try {

            await bot.sendMessage(msg.chat.id, "🔍 *Menyusun daftar perintah...*", { parse_mode: 'Markdown' });

            readCommands(casesPath);

            // Ukuran per blok (sekitar 30-40 baris agar pas di layar HP)

            const chunkSize = 40; 

            for (let i = 0; i < allLines.length; i += chunkSize) {

                const chunk = allLines.slice(i, i + chunkSize).join('\n');

                

                let message = "";

                if (i === 0) message += "<b>📋 REZISTORE COMMAND LIST</b>\n";

                

                // Membungkus baris dengan <pre> agar rapi dan monospaced

                message += `<pre>${escapeHTML(chunk)}</pre>`;

                

                if (i + chunkSize >= allLines.length) {

                    message += `\n<b>📊 Total: ${totalCmd} Handlers</b>`;

                }

                await bot.sendMessage(msg.chat.id, message, { parse_mode: 'HTML' });

            }

        } catch (err) {

            bot.sendMessage(msg.chat.id, "❌ Gagal: " + err.message);

        }

    }

};