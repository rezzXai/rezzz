const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'delfile',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // Cek akses Owner

        if (!global.isOwner(userId)) return;

        const args = msg.text.split(/\s+/);

        const fileName = args[1];

        if (!fileName) {

            return bot.sendMessage(chatId, "⚠️ **Format Salah!**\nContoh: `/delfile junk.txt` atau `/delfile nama_folder`", { parse_mode: 'Markdown' });

        }

        const filePath = path.join(__dirname, '../../', fileName);

        if (fs.existsSync(filePath)) {

            try {

                const stat = fs.statSync(filePath);

                

                if (stat.isDirectory()) {

                    // Hapus Folder beserta isinya

                    fs.rmSync(filePath, { recursive: true, force: true });

                    bot.sendMessage(chatId, `🗑️ **Folder Dihapus:** \`${fileName}\` berhasil dihapus secara permanen.`, { parse_mode: 'Markdown' });

                } else {

                    // Hapus File tunggal

                    fs.unlinkSync(filePath);

                    bot.sendMessage(chatId, `🗑️ **File Dihapus:** \`${fileName}\` berhasil dihapus secara permanen.`, { parse_mode: 'Markdown' });

                }

            } catch (e) {

                bot.sendMessage(chatId, `❌ **Gagal menghapus:**\n${e.message}`);

            }

        } else {

            bot.sendMessage(chatId, `❌ **File/Folder tidak ditemukan!**`, { parse_mode: 'Markdown' });

        }

    }

};