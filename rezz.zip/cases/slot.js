const Pengguna = require('../lib/pengguna'); // Import Lib
const userSession = {};

module.exports = {
    keyword: 'slot',
    keywordAliases: ['bet', 'judi', 'daftar'],

    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id; // PAKAI USER ID
        const text = msg.text ? msg.text.trim() : "";
        const sekarangWIB = new Date(new Date().toLocaleString("en-US", {timeZone: "Asia/Jakarta"}));

        // 1. FITUR DAFTAR
        if (text.startsWith('/daftar')) {
            const input = text.replace('/daftar', '').trim();
            if (!input.includes(',')) return bot.sendMessage(chatId, `✘ Format: \`/daftar nama,${chatId}\``);
            
            const [username] = input.split(',').map(item => item.trim());
            if (Pengguna.isTerdaftar(userId)) return bot.sendMessage(chatId, "✅ Kamu sudah terdaftar.");

            // REGISTER VIA LIB
            Pengguna.simpan(userId, {
                username,
                saldo: 3000,
                registered: true,
                joinTime: sekarangWIB.getTime(),
                date: sekarangWIB.toLocaleString('id-ID')
            });

            return bot.sendMessage(chatId, `✅ DAFTAR BERHASIL!\n👤 User: ${username}\n🎁 Bonus: Rp 3.000`);
        }

        // 2. CEK REGISTRASI
        if (!Pengguna.isTerdaftar(userId)) {
            return bot.sendMessage(chatId, `⚠️ Belum terdaftar! Ketik: \`/daftar nama,${chatId}\``);
        }

        // 3. MENU UTAMA
        if (text === '/slot' || text.toLowerCase() === 'slot') {
            return bot.sendPhoto(chatId, "https://files.catbox.moe/wd20le.jpg", {
                caption: "Pilih paket spin kamu:",
                reply_markup: {
                    inline_keyboard: [[
                        { text: '1x Spin', callback_data: 'slot_1' },
                        { text: '3x Spin', callback_data: 'slot_3' },
                        { text: '5x Spin', callback_data: 'slot_5' }
                    ]]
                }
            });
        }

        // 4. LOGIKA TERIMA NOMINAL
        if (userSession[userId] && !isNaN(text)) {
            const nominal = parseInt(text);
            const count = userSession[userId].count;
            if (nominal < 1000) return bot.sendMessage(chatId, "✘ Minimal bet Rp 1.000.");

            let user = Pengguna.ambil(userId);
            const totalBayar = nominal * count;

            if (user.saldo < totalBayar) return bot.sendMessage(chatId, `✘ Saldo kurang! Sisa: Rp ${user.saldo.toLocaleString()}`);

            delete userSession[userId];
            Pengguna.tambahSaldo(userId, -totalBayar); // POTONG SALDO

            await bot.sendMessage(chatId, `💸 Memulai ${count}x Spin...`);
            const poolEmoji = ['🍎', '💎', '🍋', '🍒', '🔔', '⭐', '🍀', '👑', '🔮', '🗿'];
            let totalWin = 0;

            for (let s = 1; s <= count; s++) {
                const res = Array.from({length: 10}, () => poolEmoji[Math.floor(Math.random() * poolEmoji.length)]);
                const maxSame = Math.max(...Object.values(res.reduce((a, b) => (a[b] = (a[b]||0) + 1, a), {})));
                
                let win = maxSame >= 5 ? nominal * (maxSame === 10 ? 5 : maxSame >= 7 ? 3 : 2) : 0;
                totalWin += win;
                await bot.sendMessage(chatId, `🎰 HASIL SPIN ${s}: [ ${res.join(' ')} ]\n🎁 Win: Rp ${win.toLocaleString()}`);
                await new Promise(r => setTimeout(r, 1000));
            }

            Pengguna.tambahSaldo(userId, totalWin); // TAMBAH SALDO KEMENANGAN
            return bot.sendMessage(chatId, `🏁 SELESAI! Total Menang: Rp ${totalWin.toLocaleString()}\nSaldo Akhir: Rp ${Pengguna.ambil(userId).saldo.toLocaleString()}`);
        }
    },

    callbackHandler: async (bot, callbackQuery) => {
        if (callbackQuery.data.startsWith('slot_')) {
            const userId = callbackQuery.from.id;
            userSession[userId] = { count: parseInt(callbackQuery.data.split('_')[1]) };
            await bot.answerCallbackQuery(callbackQuery.id);
            return bot.sendMessage(callbackQuery.message.chat.id, `🎰 Ketik nominal taruhan (min 1000):`);
        }
    }
};