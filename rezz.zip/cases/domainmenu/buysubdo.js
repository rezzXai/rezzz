const fs = require('fs');
const path = require('path');
const configPanel = require('../../lib/panel');
const { createSubdomain } = require('../../lib/cloudflare');

const sessionPath = path.join(__dirname, '../../database/session_subdo.json');
if (!fs.existsSync(sessionPath)) fs.writeFileSync(sessionPath, JSON.stringify({}));

const PATH_QRIS = path.join(__dirname, '../../qris.jpg');
const DOMAIN_UTAMA = "ziistore.my.id";
const HARGA_SUBDO = 2500;
const TIMEOUT_MS = 5 * 60 * 1000; // 5 Menit dalam milidetik

module.exports = {
    keyword: 'buysubdo',

    handler: async (bot, msg) => {
        const userId = msg.from.id;
        const chatId = msg.chat.id;

        // --- ANTI BENTROK: Hapus sesi di fitur lain jika ada ---
        const otherSessions = [
            path.join(__dirname, '../../database/session_order.json'),
            path.join(__dirname, '../../database/session_ress.json')
        ];
        otherSessions.forEach(p => {
            if (fs.existsSync(p)) {
                let s = JSON.parse(fs.readFileSync(p));
                if (s[userId]) { delete s[userId]; fs.writeFileSync(p, JSON.stringify(s)); }
            }
        });

        let sessions = JSON.parse(fs.readFileSync(sessionPath));
        
        // Buat sesi baru dengan Timestamp
        sessions[userId] = { 
            step: 'WAITING_NAME', 
            firstName: msg.from.first_name,
            createdAt: Date.now() 
        }; 

        fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
        return bot.sendMessage(chatId, "🌐 <b>ORDER SUBDOMAIN</b>\n\nSilakan ketik nama subdomain yang diinginkan:\nContoh: <code>vpsrezi</code>\n\n⚠️ <i>Sesi ini otomatis hangus dalam 5 menit.</i>", { parse_mode: 'HTML' });
    },

    onMessage: async (bot, msg, settings) => {
        const userId = msg.from.id;
        const chatId = msg.chat.id;
        let sessions = JSON.parse(fs.readFileSync(sessionPath));
        const userSession = sessions[userId];

        if (!userSession) return false;

        // --- LOGIKA TIMEOUT ---
        if (Date.now() - userSession.createdAt > TIMEOUT_MS) {
            delete sessions[userId];
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
            await bot.sendMessage(chatId, "⏰ <b>Waktu Sesi Habis!</b>\nSilakan ketik kembali /buysubdo untuk memulai ulang.", { parse_mode: 'HTML' });
            return true;
        }

        // Step 1: Input Nama Subdomain
        if (userSession.step === 'WAITING_NAME' && msg.text) {
            userSession.nama = msg.text.trim().toLowerCase().replace(/\s+/g, '');
            userSession.step = 'WAITING_IP';
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            await bot.sendMessage(chatId, `✅ Calon Domain: <b>${userSession.nama}.${DOMAIN_UTAMA}</b>\n\nSekarang silakan kirim <b>IP VPS</b> Anda:`, { parse_mode: 'HTML' });
            return true;
        }

        // Step 2: Input IP VPS
        if (userSession.step === 'WAITING_IP' && msg.text) {
            userSession.ip = msg.text.trim();
            userSession.step = 'WAITING_PAYMENT';
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            if (fs.existsSync(PATH_QRIS)) {
                await bot.sendPhoto(chatId, fs.createReadStream(PATH_QRIS), {
                    caption: `💳 <b>PEMBAYARAN SUBDOMAIN</b>\n\n` +
                             `🌐 <b>Preview:</b> <code>${userSession.nama}.${DOMAIN_UTAMA}</code>\n` +
                             `📍 <b>IP VPS:</b> <code>${userSession.ip}</code>\n` +
                             `💰 <b>Harga:</b> Rp${HARGA_SUBDO.toLocaleString()}\n\n` +
                             `⚠️ <i>Status: Menunggu Pembayaran</i>\n` +
                             `Silakan transfer ke QRIS di atas dan kirim <b>FOTO BUKTI</b> sekarang.`,
                    parse_mode: 'HTML'
                });
            } else {
                await bot.sendMessage(chatId, `⚠️ QRIS tidak ditemukan. Silakan transfer <b>Rp${HARGA_SUBDO}</b> ke admin.`);
            }
            return true;
        }

        // Step 3: Input Foto Bukti
        if (userSession.step === 'WAITING_PAYMENT' && msg.photo) {
            const photoId = msg.photo[msg.photo.length - 1].file_id;
            userSession.step = 'PENDING_OWNER';
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            await bot.sendMessage(chatId, "⏳ <b>Bukti diterima!</b>\nMenunggu konfirmasi Owner untuk pendaftaran domain.");

            const ownerId = configPanel.OWNER_ID || 8064092635;
            await bot.sendPhoto(ownerId, photoId, {
                caption: `🔔 <b>KONFIRMASI SUBDOMAIN</b>\n\n👤 User: ${userSession.firstName}\n🌐 Subdo: ${userSession.nama}.${DOMAIN_UTAMA}\n📍 IP: ${userSession.ip}`,
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [[
                        { text: "✅ ACC & CREATE", callback_data: `acc_subdo_${userId}` },
                        { text: "❌ TOLAK", callback_data: `rej_subdo_${userId}` }
                    ]]
                }
            });
            return true;
        }
        return false;
    },

    callbackHandler: async (bot, callbackQuery, settings) => {
        const { data, message } = callbackQuery;
        const chatId = message.chat.id;
        let sessions = JSON.parse(fs.readFileSync(sessionPath));

        if (data.startsWith('acc_subdo_')) {
            const targetId = data.split('_')[2];
            const order = sessions[targetId];
            if (!order) return bot.answerCallbackQuery(callbackQuery.id, { text: "Sesi tidak ditemukan atau sudah expired.", show_alert: true });

            await bot.editMessageCaption("⏳ <b>Sedang memproses ke Cloudflare...</b>", { chat_id: chatId, message_id: message.message_id });

            try {
                await createSubdomain(order.nama, order.ip);

                const suksesTeks = `✅ <b>SUBDOMAIN BERHASIL AKTIF</b>\n\n` +
                    `🌐 <b>Domain:</b> <code>${order.nama}.${DOMAIN_UTAMA}</code>\n` +
                    `📍 <b>IP VPS:</b> <code>${order.ip}</code>\n\n` +
                    `Terima kasih telah order di <b>ReziStore</b>!`;

                await bot.sendMessage(targetId, suksesTeks, { parse_mode: 'HTML' });
                await bot.sendMessage(chatId, "✅ Berhasil mendaftarkan subdomain.");

                const sekarang = new Date();
                const tgl = sekarang.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });
                
                const logChannel = `📢 <b>NOTIFIKASI PENJUALAN</b>\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `👤 <b>Pembeli:</b> ${order.firstName}\n` +
                    `🛒 <b>Produk:</b> Subdomain (Subdo)\n` +
                    `💰 <b>Harga:</b> Rp ${HARGA_SUBDO.toLocaleString()}\n` +
                    `📅 <b>Tanggal:</b> ${tgl}\n` +
                    `━━━━━━━━━━━━━━━━━━━━\n` +
                    `✅ <b>Status:</b> Sukses Terdaftar\n\n` +
                    `©️ <b>ReziStore</b>`;

                bot.sendPhoto(configPanel.CHANNEL_ID, configPanel.IMAGE_URL, {
                    caption: logChannel,
                    parse_mode: 'HTML'
                }).catch(() => {});

                delete sessions[targetId];
                fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));

            } catch (err) {
                const errorMsg = err.response?.data?.errors?.[0]?.message || err.message;
                bot.sendMessage(chatId, "❌ Gagal: " + errorMsg);
            }
            return true;
        }

        if (data.startsWith('rej_subdo_')) {
            const targetId = data.split('_')[2];
            await bot.sendMessage(targetId, "❌ Maaf, bukti pembayaran subdomain kamu ditolak.");
            delete sessions[targetId];
            fs.writeFileSync(sessionPath, JSON.stringify(sessions, null, 2));
            await bot.deleteMessage(chatId, message.message_id);
            return true;
        }
        return false;
    }
};