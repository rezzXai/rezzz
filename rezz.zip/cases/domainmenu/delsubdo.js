const { deleteSubdomain } = require('../../lib/cloudflare');
const setting = require('../../setting'); 

module.exports = {
    keyword: 'delsubdo',
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // Cek apakah userId ada di dalam array OWNER_ID pada settings.js
        const listOwner = setting.OWNER_ID; 

        if (!listOwner.includes(userId)) {
            // Jika bukan owner, bot tidak memberikan respon apa-apa
            return; 
        }

        // Mengambil argumen nama subdomain
        const args = (msg.text || "").split(/\s+/);
        const namaSubdo = args[1];

        if (!namaSubdo) {
            return bot.sendMessage(chatId, "❌ **Format Salah!**\nContoh: `/delsubdo tes.ziistore.my.id`", { parse_mode: 'Markdown' });
        }

        bot.sendMessage(chatId, `⏳ **Menghapus** \`${namaSubdo}\`...`, { parse_mode: 'Markdown' });

        try {
            // Eksekusi hapus di Cloudflare
            await deleteSubdomain(namaSubdo.trim());

            // Respon sukses hanya ke Owner
            bot.sendMessage(chatId, `✅ **BERHASIL!**\nSubdomain \`${namaSubdo}\` telah dihapus secara permanen.`, { parse_mode: 'Markdown' });

        } catch (error) {
            // Jika subdomain tidak ditemukan atau API error
            bot.sendMessage(chatId, "❌ **GAGAL MENGHAPUS**\nSubdomain tidak ditemukan atau terjadi gangguan pada API Cloudflare.");
        }
    }
};