const { listSubdomains } = require('../../lib/cloudflare');
const settings = require('../../setting');

module.exports = {
    keyword: 'listsubdo',
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // --- CEK OWNER (OWNER ONLY) ---
        if (!settings.OWNER_ID.includes(userId)) {
            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.", { 
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id 
            });
        }

        bot.sendMessage(chatId, "⏳ Mengambil daftar subdomain dari Cloudflare...");

        try {
            const list = await listSubdomains();

            if (list.length === 0) {
                return bot.sendMessage(chatId, "ℹ️ Tidak ada subdomain (DNS Record) yang ditemukan.");
            }

            let teks = `📂 DAFTAR SUBDOMAIN AKTIF\n`;
            teks += `Domain: \`ziistore.my.id\`\n`;
            teks += `━━━━━━━━━━━━━━━━━━━━\n\n`;

            list.forEach((item, index) => {
                teks += `${index + 1}. 🌐 \`${item.name}\`\n`;
                teks += `   📍 IP: \`${item.content}\`\n\n`;
            });

            teks += `━━━━━━━━━━━━━━━━━━━━\n`;
            teks += `Total: **${list.length}** Subdomain`;

            bot.sendMessage(chatId, teks, { parse_mode: 'Markdown' });

        } catch (error) {
            bot.sendMessage(chatId, "❌ GAGAL MENGAMBIL DATA\nTerjadi kesalahan saat menghubungi API Cloudflare.");
        }
    }
};