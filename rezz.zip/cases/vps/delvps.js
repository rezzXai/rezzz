const axios = require('axios');
const configDO = require('../../lib/do'); // - Memanggil file konfigurasi dari folder lib

module.exports = {
    keyword: 'delvps',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text ? msg.text.trim() : "";
        const args = text.split(/\s+/);

        // --- KONFIGURASI (DIAMBIL DARI LIB/DO.JS) ---
        const DO_TOKEN = configDO.DO_TOKEN; 

        const isOwner = global.isOwner(userId);
        if (!isOwner) return bot.sendMessage(chatId, "❌ Fitur ini hanya untuk Owner.");

        // 1. Tampilkan Daftar VPS
        if (args.length === 1) {
            bot.sendMessage(chatId, "⏳ Mengambil daftar VPS aktif...");
            try {
                const res = await axios.get('https://api.digitalocean.com/v2/droplets', {
                    headers: { 'Authorization': `Bearer ${DO_TOKEN}` }
                });

                const droplets = res.data.droplets;
                if (droplets.length === 0) return bot.sendMessage(chatId, "📭 Tidak ada VPS yang ditemukan.");

                let list = "🗑 **DAFTAR VPS AKTIF (DIGITALOCEAN)**\n\n";
                
                droplets.forEach((d, i) => {
                    // MENCARI IPV4 PUBLIK YANG BENAR
                    const publicNetwork = d.networks.v4.find(net => net.type === 'public');
                    const ip = publicNetwork ? publicNetwork.ip_address : "Proses IP...";
                    
                    list += `${i + 1}. 🖥 **Nama:** \`${d.name}\`\n`;
                    list += `   🆔 **ID:** \`${d.id}\`\n`;
                    list += `   🌐 **IP:** \`${ip}\`\n`;
                    list += `   📍 **Region:** ${d.region.slug}\n`;
                    list += `   ━━━━━━━━━━━━━━━━\n`;
                });
                
                list += "\n**Cara Hapus:** `/delvps ID_VPS`\nContoh: `/delvps 46512345`";
                
                return bot.sendMessage(chatId, list, { parse_mode: 'Markdown' });
            } catch (e) {
                return bot.sendMessage(chatId, "❌ Gagal mengambil data dari DigitalOcean.");
            }
        }

        // 2. Eksekusi Penghapusan Berdasarkan ID
        const dropletId = args[1];
        bot.sendMessage(chatId, `⏳ Sedang menghapus Droplet ID: ${dropletId}...`);

        try {
            await axios.delete(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                headers: { 'Authorization': `Bearer ${DO_TOKEN}` }
            });

            bot.sendMessage(chatId, `✅ **SUKSES!**\nVPS dengan ID \`${dropletId}\` telah dihapus permanen dari DigitalOcean.`, { parse_mode: 'Markdown' });
            
        } catch (error) {
            const msgErr = error.response?.data?.message || error.message;
            bot.sendMessage(chatId, `❌ **GAGAL MENGHAPUS**\nAlasan: \`${msgErr}\``, { parse_mode: 'Markdown' });
        }
    }
};