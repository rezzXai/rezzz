const axios = require('axios');
const fs = require('fs');
const path = require('path');
const configDO = require('../../lib/do'); // - Memanggil file konfigurasi baru

function generateStrongPassword(length = 16) {
    const charset = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789!@#$%^&*()_+";
    let password = "";
    for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * charset.length);
        password += charset[randomIndex];
    }
    return password;
}

module.exports = {
    keyword: 'buyvps',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text ? msg.text.trim() : "";
        const argsRaw = text.split(/\s+/)[1];

        // --- KONFIGURASI (DIAMBIL DARI LIB/DO.JS) ---
        const DO_TOKEN = configDO.DO_TOKEN; //
        const ID_SALURAN = configDO.ID_SALURAN; //
        const IMAGE_URL = configDO.IMAGE_URL; //
        
        const userDbPath = path.join(__dirname, '../../database/users_data.json');

        const regionMap = { 'sgp': 'sgp1', 'nyc': 'nyc3', 'fra': 'fra1', 'lon': 'lon1' };
        const osMap = { '22': 'ubuntu-22-04-x64', '24': 'ubuntu-24-04-x86-64', '25': 'ubuntu-25-04-x86-64' };
        const sizeMap = { 
            '2-2': { size: 's-2vcpu-2gb', harga: 15000, desc: 'RAM 2GB / CPU 2' },
            '4-2': { size: 's-2vcpu-4gb', harga: 25000, desc: 'RAM 4GB / CPU 2' },
            '8-2': { size: 's-2vcpu-8gb', harga: 30000, desc: 'RAM 8GB / CPU 2' },
            '8-4': { size: 's-4vcpu-8gb', harga: 35000, desc: 'RAM 8GB / CPU 4' }
        };

        if (!argsRaw || argsRaw.split(',').length < 3) {
            let help = "⚠️ FORMAT PEMBELIAN VPS\n\n`/buyvps negara,os,spek`\nContoh: `/buyvps sgp,24,2-2`\n\n";
            help += "🌐 Negara: `sgp, nyc, fra, lon`\n💿 OS: `22, 24, 25` (Ubuntu)\n📟 Spek: `2-2, 4-2, 8-2, 8-4`";
            return bot.sendMessage(chatId, help, { parse_mode: 'Markdown' });
        }

        const [neg, os, spek] = argsRaw.split(',').map(item => item.toLowerCase().trim());
        const targetRegion = regionMap[neg];
        const targetOS = osMap[os];
        const targetSize = sizeMap[spek];

        if (!targetRegion || !targetOS || !targetSize) return bot.sendMessage(chatId, "✘ Data tidak valid!");

        // 1. CEK SALDO DI AWAL
        let userDb = JSON.parse(fs.readFileSync(userDbPath));
        const isOwner = global.isOwner(userId);
        const userSaldo = userDb[userId]?.saldo || 0;

        if (!isOwner && userSaldo < targetSize.harga) {
            return bot.sendMessage(chatId, `✘ SALDO TIDAK CUKUP\n\nHarga: Rp ${targetSize.harga.toLocaleString()}\nSaldo Anda: Rp ${userSaldo.toLocaleString()}`);
        }

        bot.sendMessage(chatId, `⏳ SALDO TERCUKUPI\nSedang memproses ${targetSize.desc}...\nMohon tunggu sekitar 1 menit.`);

        const passwordAcak = generateStrongPassword();
        const userData = `#!/bin/bash\necho "root:${passwordAcak}" | chpasswd\nsed -i 's/#PermitRootLogin prohibit-password/PermitRootLogin yes/' /etc/ssh/sshd_config\nsed -i 's/PasswordAuthentication no/PasswordAuthentication yes/' /etc/ssh/sshd_config\nsystemctl restart ssh`;

        try {
            const res = await axios.post('https://api.digitalocean.com/v2/droplets', {
                name: `zii-${neg}-${spek}-${userId}`,
                region: targetRegion,
                size: targetSize.size,
                image: targetOS,
                user_data: userData,
                ipv6: true
            }, { headers: { 'Authorization': `Bearer ${DO_TOKEN}` } });

            const dropletId = res.data.droplet.id;

            let attempts = 0;
            const checkIP = setInterval(async () => {
                attempts++;
                try {
                    const info = await axios.get(`https://api.digitalocean.com/v2/droplets/${dropletId}`, {
                        headers: { 'Authorization': `Bearer ${DO_TOKEN}` }
                    });
                    const networks = info.data.droplet.networks.v4;

                    if (networks && networks.length > 0) {
                        clearInterval(checkIP);
                        const ip = networks[0].ip_address;

                        // 2. POTONG SALDO SAAT BERHASIL
                        if (!isOwner) {
                            userDb[userId].saldo -= targetSize.harga;
                            fs.writeFileSync(userDbPath, JSON.stringify(userDb, null, 2));
                        }

                        // Kirim detail ke User
                        const sukses = `✅ VPS BERHASIL AKTIF!\n\n🌐 IP: \`${ip}\`\n👤 User: \`root\`\n🔑 Pass: \`${passwordAcak}\`\n📟 Spek: ${targetSize.desc}\n\n⚠️ Tunggu 2 menit sebelum login!`;
                        bot.sendMessage(chatId, sukses, { parse_mode: 'Markdown' });

                        // 3. BROADCAST KE SALURAN
                        const username = msg.from.username ? `@${msg.from.username}` : msg.from.first_name;
                        let caption = `📢 NOTIFIKASI PEMBELIAN VPS\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `👤 User: ${username}\n`;
                        caption += `📟 Spek: ${targetSize.desc}\n`;
                        caption += `📍 Lokasi: ${neg.toUpperCase()}\n`;
                        caption += `💿 OS: Ubuntu ${os}\n`;
                        caption += `💰 Harga: Rp ${targetSize.harga.toLocaleString()}\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `✅ *TATUS: SUKSES`;

                        bot.sendPhoto(ID_SALURAN, IMAGE_URL, { caption: caption, parse_mode: 'Markdown' }).catch(() => {});
                    }
                } catch (e) {}
                if (attempts > 12) clearInterval(checkIP);
            }, 10000);

        } catch (error) {
            const msgErr = error.response?.data?.message || error.message;
            bot.sendMessage(chatId, `,✘GAGAL: ${msgErr}`);
        }
    }
};