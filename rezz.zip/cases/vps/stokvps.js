const axios = require('axios');
const configDO = require('../../lib/do'); // - Memanggil file konfigurasi dari folder lib

module.exports = {
    keyword: 'stokvps',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;

        // --- KONFIGURASI (DIAMBIL DARI LIB/DO.JS) ---
        const DO_TOKEN = configDO.DO_TOKEN;

        try {
            // 1. Ambil Data Akun (untuk total limit)
            const account = await axios.get('https://api.digitalocean.com/v2/account', {
                headers: { 'Authorization': `Bearer ${DO_TOKEN}` }
            });

            // 2. Ambil Daftar Droplet (untuk jumlah terpakai)
            const droplets = await axios.get('https://api.digitalocean.com/v2/droplets?per_page=1', {
                headers: { 'Authorization': `Bearer ${DO_TOKEN}` }
            });

            const limitTotal = account.data.account.droplet_limit;
            const terpakai = droplets.data.meta.total;
            const sisa = limitTotal - terpakai;

            let teks = `📊 **STATUS STOK VPS DIGITALOCEAN**\n\n`;
            teks += `🔹 Total Limit Droplet: **${limitTotal}**\n`;
            teks += `🔸 Droplet Terpakai: **${terpakai}**\n`;
            teks += `━━━━━━━━━━━━━━━━━━━━\n`;
            teks += `✅ **SISA SLOT: ${sisa} VPS**\n\n`;
            
            if (sisa <= 0) {
                teks += `⚠️ *Stok sedang habis! Harap hapus vps lama atau hubungi admin.*`;
            } else {
                teks += `🚀 Silakan gunakan /buyvps untuk memesan.`;
            }

            bot.sendMessage(chatId, teks, { parse_mode: 'Markdown' });

        } catch (error) {
            console.error(error);
            bot.sendMessage(chatId, "❌ Gagal mengambil data stok dari DigitalOcean.");
        }
    }
};