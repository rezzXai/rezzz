const { tiktokdownload } = require('../scraper'); 

const settings = require('../setting'); // Mengarah ke setting.js sesuai contohmu

module.exports = {

    keyword: 'ttmp3',

    keywordAliases: ['/ttmp3', 'ttmp3'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.trim().split(/\s+/);

        // --- VALIDASI OWNER (Sesuai contoh ttslide) ---

        if (!settings.OWNER_ID.includes(userId)) {

            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.", { 

                reply_to_message_id: msg.message_id 

            });

        }

        if (args.length < 2) {

            return bot.sendMessage(chatId, "❌ Masukkan link TikTok!", { 

                reply_to_message_id: msg.message_id 

            });

        }

        const url = args[1];

        const loadingMsg = await bot.sendMessage(chatId, "⏳ Sedang mengambil audio...");

        try {

            // Menggunakan fungsi scraper andalanmu

            const result = await tiktokdownload(url);

            if (result.status && result.audio) {

                // Kirim sebagai Audio (MP3)

                await bot.sendAudio(chatId, result.audio, {

                    title: result.title || "TikTok Audio",

                    performer: "TikTok Downloader",

                    caption: `✅ **Audio Berhasil Diambil!**\n📝 ${result.title || '-'}`,

                    reply_to_message_id: msg.message_id,

                    parse_mode: 'Markdown'

                });

            } else {

                throw new Error("Gagal mendapatkan link audio.");

            }

        } catch (e) {

            console.error(`🔴 TTMP3 Error: ${e.message}`);

            bot.sendMessage(chatId, `❌ **Gagal:** ${e.message}`);

        } finally {

            // Hapus pesan loading agar chat bersih

            bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

        }

    }

};