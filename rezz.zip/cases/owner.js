// cases/owner.js (REVISI FINAL: Edit Pesan saat Callback, Markdown)

const settings = require('../setting');
const path = require('path');
const fs = require('fs');

// Tentukan path lengkap ke file gambar owner/kredit
const OWNER_IMAGE_PATH = path.join(__dirname, '..', '1128.jpg');

// Versi bot dan detail pembuatan
const BOT_VERSION = "ᴠ3.5.0";
const SCRIPT_DETAIL = "ɴᴏᴅᴇ ᴊs ᴀɴᴅ ᴘʏᴛʜᴏɴ ";
const CREATION_DATE = "ᴊᴀɴᴜᴀʀʏ";


// --- Fungsi untuk menghasilkan konten pesan (agar bisa dipakai berulang) ---
function getOwnerContent(settings) {
    const ownerUsername = settings.OWNER_USERNAME || 'Developer';

    // --- 1. Konfigurasi Tombol Inline ---
    // NOTE: Callback '/start' diubah menjadi '/start_callback'
    const inlineKeyboard = {
        inline_keyboard: [
            // Baris 1: Tombol Navigasi Kontak
            [
                { text: '𝗢𝗪𝗡𝗘𝗥', url: `https://t.me/${ownerUsername}` }
            ],
            // Baris 2: Media Sosial
            [
                { text: '𝗬𝗢𝗨𝗧𝗨𝗕𝗘', url: settings.OWNER_YOUTUBE || 'https://www.youtube.com' },
                { text: '𝗧𝗜𝗞𝗧𝗢𝗞', url: settings.OWNER_TIKTOK || 'https://www.tiktok.com' },
            ],
            // Baris 3: Media Sosial Lanjutan
            [
                { text: '𝗜𝗡𝗦𝗧𝗔𝗚𝗥𝗔𝗠', url: settings.OWNER_INSTAGRAM || 'https://www.instagram.com' },
             ],
             [
                { text: '☜ʙᴀᴄᴋ', callback_data: '/start_callback' }
            ]
        ]
    };

    // --- 2. Teks Deskripsi (Menggunakan Formatting Markdown) ---
    const descriptionCaption = 
        `𝗜𝗡𝗙𝗢 𝗢𝗪𝗡𝗘𝗥 𝗕𝗢𝗧 𒆙\n` +
        `_==============================_\n` + 
        
        `Ｉ'Ｍ Ａ ＢＯＴ ＦＲＯＭ @${ownerUsername}\n` +
        
        `𝗕𝗢𝗧 𝗗𝗘𝗧𝗔𝗜𝗟 ♕\n` +
        `• 𝙑𝙀𝙍𝙎𝙄𝙊𝙉: \`${BOT_VERSION}\`\n` +
        `• 𝘾𝙍𝙀𝘼𝙏𝙀 𝘽𝙔: \`${SCRIPT_DETAIL}\`\n` +
        `• 𝙍𝙄𝙇𝙄𝙎 𝙄𝙉 𝙋𝙐𝘽𝙇𝙄𝘾: _${CREATION_DATE}_\n\n` +
        
        `𝗠𝗬 𝗖𝗢𝗡𝗧𝗔𝗖𝗧𝗦\n` +
        `• Username: \`@${ownerUsername}\`\n` +
        `𝗗𝗜 𝗕𝗨𝗔𝗧 𝗢𝗟𝗘𝗛 𝗥𝗘𝗭𝗜 𝗦𝗧𝗢𝗥𝗘 𖣘\n` +
        
        `\n_==============================_\n` +
        `𝗣𝗟𝗘𝗔𝗦𝗘 𝗙𝗢𝗟𝗟𝗢𝗪 𝗠𝗬 𝗦𝗢𝗦𝗠𝗘𝗗 ☟`;
        
    return { descriptionCaption, inlineKeyboard };
}


module.exports = {
    keyword: '/owner',
    keywordAliases: ['/owner_callback'], // Tambahkan alias untuk callback jika diperlukan
    
    handler: async (bot, msg, settings) => { 
        const chatId = msg.chat.id;
        
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id;

        const imageExists = fs.existsSync(OWNER_IMAGE_PATH);
        const { descriptionCaption, inlineKeyboard } = getOwnerContent(settings);

        const options = {
            caption: descriptionCaption, 
            parse_mode: 'Markdown', // Menggunakan Markdown
            reply_markup: inlineKeyboard,
            reply_to_message_id: isCallback ? undefined : msg.message_id
        };

        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
            // Aksi: EDIT CAPTION pesan yang ada
            try {
                // Gunakan editMessageCaption (asumsi pesan sebelumnya foto)
                await bot.editMessageCaption(descriptionCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'Markdown',
                    reply_markup: inlineKeyboard
                });
            } catch (e) {
                if (e.message && e.message.includes('message is not modified')) {
                    return; 
                }
                
                console.warn(`Gagal mengedit pesan /owner: ${e.message}. Mencoba mengirim baru.`);
                
                // Fallback: Kirim pesan baru
                 if (imageExists) {
                    await bot.sendPhoto(chatId, OWNER_IMAGE_PATH, options);
                } else {
                    await bot.sendMessage(chatId, descriptionCaption, { parse_mode: 'Markdown', reply_markup: inlineKeyboard });
                }
            }
            
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /owner diketik)
            if (imageExists) {
                await bot.sendPhoto(chatId, OWNER_IMAGE_PATH, options)
                .catch(error => {
                    console.error("Gagal mengirim foto owner:", error.message);
                    // Fallback: Kirim pesan teks saja jika pengiriman foto gagal
                    bot.sendMessage(chatId, 
                        `❌ **Kesalahan:** Gagal menampilkan gambar Owner.\n\n` +
                        descriptionCaption, 
                        { 
                            parse_mode: 'Markdown',
                            reply_markup: inlineKeyboard
                        }
                    );
                });
            } else {
                console.warn(`[WARN] File foto owner tidak ditemukan. Mengirim teks saja.`);
                bot.sendMessage(chatId, descriptionCaption, { parse_mode: 'Markdown', reply_markup: inlineKeyboard });
            }
        }
    }
};