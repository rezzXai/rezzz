const settings = require('../setting'); // Mengambil config dari file setting.js di folder utama

module.exports = {

    keyword: 'text',

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // 1. Pengecekan Owner dari file setting

        // Mendukung format OWNER_ID berupa Array maupun Angka tunggal

        const ownerIds = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID : [settings.OWNER_ID];

        const isOwner = ownerIds.includes(userId) || ownerIds.includes(String(userId));

        

        if (!isOwner) {

            return bot.sendMessage(chatId, `<blockquote>❌ <b>ᴀᴋsᴇs ᴅɪᴛᴏʟᴀᴋ!</b>\n\nᴍᴀᴀғ, ᴘᴇʀɪɴᴛᴀʜ ɪɴɪ ʜᴀɴʏᴀ ᴅᴀᴘᴀᴛ ᴅɪɢᴜɴᴀᴋᴀɴ ᴏʟᴇʜ ᴏᴡɴᴇʀ ʙᴏᴛ.</blockquote>`, { parse_mode: 'HTML' });

        }

        const text = msg.text ? msg.text : '';

        // 2. Regex untuk menangkap teks setelah command (mendukung paragraf/line break)

        const match = text.match(/^\/\w+\s+([\s\S]+)/);

        if (!match) {

            const errorMsg = `<blockquote>❌ <b>ғᴏʀᴍᴀᴛ sᴀʟᴀʜ!</b>\n\nɢᴜɴᴀᴋᴀɴ: <code>/text [ɪsɪ ᴘᴇsᴀɴ]</code>\n\nᴄᴏɴᴛᴏʜ:\n/text ʜᴀʟᴏ sᴇᴍᴜᴀ 🚀</blockquote>`;

            return bot.sendMessage(chatId, errorMsg, { parse_mode: 'HTML' });

        }

        const isiPesan = match[1];

        // 3. Membungkus pesan dengan Blockquote

        const formatPesan = `<blockquote>${isiPesan}</blockquote>`;

        try {

            await bot.sendMessage(chatId, formatPesan, { 

                parse_mode: 'HTML',

                disable_web_page_preview: true 

            });

            

            // Hapus pesan perintah asli agar tampilan chat bersih

            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});

            

        } catch (e) {

            const failMsg = `<blockquote>❌ <b>ɢᴀɢᴀʟ ᴍᴇɴɢɪʀɪᴍ ᴛᴇᴋs!</b>\nᴘᴀsᴛɪᴋᴀɴ ᴛɪᴅᴀᴋ ᴀᴅᴀ ᴛᴀɢ ʜᴛᴍʟ ʏᴀɴɢ sᴀʟᴀʜ.</blockquote>`;

            bot.sendMessage(chatId, failMsg, { parse_mode: 'HTML' });

        }

    }

};