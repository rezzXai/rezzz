const Pengguna = require('../lib/pengguna'); // Import Library

module.exports = {
    keyword: 'flip',
    keywordAliases: ['koin', 'cf'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id; // Konsisten pakai userId
        const text = msg.text ? msg.text.trim() : "";
        const args = text.split(/\s+/);

        // 1. Cek Registrasi via Lib
        if (!Pengguna.isTerdaftar(userId)) {
            return bot.sendMessage(chatId, "⚠️ Kamu belum terdaftar! Ketik /daftar dulu.");
        }

        // 2. Validasi Format: /flip [nominal] [A/G]
        if (args.length < 3) {
            return bot.sendMessage(chatId, 
                `🪙 **COIN FLIP GAMES** 🪙\n\n` +
                `Cara main: \`/koin [nominal] [pilihan]\`\n` +
                `Pilihan: **A** (Angka) atau **G** (Gambar)\n\n` +
                `Contoh: \`/koin 1000 A\``, { parse_mode: 'Markdown' });
        }

        const nominal = parseInt(args[1]);
        const pilihan = args[2].toUpperCase();

        // 3. Validasi Input & Saldo
        if (isNaN(nominal) || nominal < 1000) {
            return bot.sendMessage(chatId, "✘ Minimal taruhan adalah Rp 1.000.");
        }

        if (pilihan !== 'A' && pilihan !== 'G') {
            return bot.sendMessage(chatId, "✘ Pilih antara A (Angka) atau G (Gambar).");
        }

        const dataUser = Pengguna.ambil(userId);
        if (dataUser.saldo < nominal) {
            return bot.sendMessage(chatId, `✘ Saldo tidak cukup!\nSaldo kamu: Rp ${dataUser.saldo.toLocaleString('id-ID')}`);
        }

        // --- PROSES PERMAINAN ---
        // Kurangi saldo di awal (anti-cheat) via Lib
        Pengguna.tambahSaldo(userId, -nominal);

        const waitMsg = await bot.sendMessage(chatId, `🪙 Koin dilempar ke udara...`);
        
        // Animasi singkat
        await new Promise(r => setTimeout(r, 1500));

        const sisiKoin = ['A', 'G'];
        const hasil = sisiKoin[Math.floor(Math.random() * sisiKoin.length)];
        const hasilTeks = hasil === 'A' ? '🔢 ANGKA' : '🖼️ GAMBAR';
        
        let menang = pilihan === hasil;
        let pesanHasil = "";

        if (menang) {
            const reward = nominal * 2;
            Pengguna.tambahSaldo(userId, reward); // Tambah saldo kemenangan via Lib
            pesanHasil = `🎉 **MENANG!**\n\nHasil koin: **${hasilTeks}**\nKamu mendapatkan: **Rp ${reward.toLocaleString('id-ID')}**`;
        } else {
            pesanHasil = `💀 **KALAH!**\n\nHasil koin: **${hasilTeks}**\nTaruhan kamu **Rp ${nominal.toLocaleString('id-ID')}** hangus.`;
        }

        // Ambil saldo terbaru setelah permainan
        const saldoAkhir = Pengguna.ambil(userId).saldo;

        const finalMsg = 
            `🪙 **HASIL COIN FLIP** 🪙\n` +
            `────────────────────\n` +
            `${pesanHasil}\n` +
            `────────────────────\n` +
            `💳 **Saldo Akhir:** Rp ${saldoAkhir.toLocaleString('id-ID')}`;

        return bot.editMessageText(finalMsg, { 
            chat_id: chatId, 
            message_id: waitMsg.message_id, 
            parse_mode: 'Markdown' 
        });
    }
};