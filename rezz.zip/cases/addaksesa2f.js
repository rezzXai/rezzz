// /cases/addaksesa2f.js - REVISI MENGGUNAKAN global.isOwner()

const { getAccessList, saveAccessList } = require('../lib/a2f_db');

module.exports = {
    keyword: 'addaksesa2f', 
    keywordAliases: ['/addaksesa2f'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id; // Ambil ID sebagai Number, biarkan global.isOwner yang konversi
        
        // --- 1. Cek Keamanan (Gunakan helper global.isOwner yang terdefinisi di rezz.js) ---
        // Asumsi: rezz.js sudah mendefinisikan global.isOwner
        if (typeof global.isOwner !== 'function' || !global.isOwner(senderId)) {
             return bot.sendMessage(chatId, 
                "❌ **Akses Ditolak.** Perintah ini hanya untuk Owner bot.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 2. Ambil Argumen (ID Pengguna) ---
        const args = msg.text.slice(msg.entities[0].length).trim();
        const targetId = args.split(/\s+/)[0]; // Ambil ID pertama
        
        if (!targetId || isNaN(targetId) || targetId.length < 5) {
            return bot.sendMessage(chatId, 
                "❌ **Format Salah.**\n\nGunakan: `/addaksesa2f [ID Telegram]`\nContoh: `/addaksesa2f 123456789`", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const newId = String(targetId); // Simpan ID sebagai string
        let allowedIds = getAccessList();

        // --- 3. Cek Duplikasi ---
        if (allowedIds.includes(newId)) {
            return bot.sendMessage(chatId, 
                `⚠️ **Gagal:** ID \`${newId}\` sudah memiliki akses ke /a2f.`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 4. Tambahkan ID dan Simpan ---
        allowedIds.push(newId);
        const success = saveAccessList(allowedIds);

        if (success) {
            await bot.sendMessage(chatId, 
                `✅ **Sukses!**\n\nID \`${newId}\` telah diberikan akses untuk menggunakan /a2f.`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else {
             await bot.sendMessage(chatId, 
                "❌ **Error Penyimpanan.** Gagal menyimpan data ke file.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};