const { findProduct, updateStock } = require('../lib/stokdb'); 
const { getVoucher, saveVoucher } = require('../lib/voucherdb');
const Pengguna = require('../lib/pengguna');

const isUserOwner = (userId, ownerSettings) => {
    const numericUserId = Number(userId);
    let ownerIds = Array.isArray(ownerSettings) ? ownerSettings.map(id => Number(id)) : [Number(ownerSettings)];
    return ownerIds.includes(numericUserId);
};

module.exports = {
    keyword: 'konfirmasi',
    
    callbackHandler: async (bot, callbackQuery, settings) => {
        const data = callbackQuery.data;
        const adminId = callbackQuery.from.id;
        const ownerSettings = settings.OWNER_ID;
        const CHANNEL_ID = '-1002927416845';

        if (data.startsWith('acc_pay_') || data.startsWith('rej_pay_')) {
            if (!isUserOwner(adminId, ownerSettings)) {
                await bot.answerCallbackQuery(callbackQuery.id, { text: "✘ Anda bukan Owner!", show_alert: true });
                return true; 
            }

            const userId = data.split('_')[2];
            const trx = global.unconfirmedTransactions[userId];

            if (!trx) {
                await bot.answerCallbackQuery(callbackQuery.id, { text: "⚠️ Transaksi kedaluwarsa atau sudah diproses." });
                return true;
            }

            if (data.startsWith('acc_pay_')) {
                const product = findProduct(trx.stockKey);
                if (!product || product.count <= 0) {
                    await bot.sendMessage(adminId, "⚠️ Stok habis!");
                    return true;
                }

                updateStock(product.name, product.count - 1);
                Pengguna.tambahHistory(trx.userId, {
                    produk: product.nameDisplay,
                    harga: trx.price,
                    metode: 'QRIS'
                });

                if (trx.voucherUsed) {
                    let vDb = getVoucher();
                    if (vDb.list && vDb.list[trx.voucherUsed]) {
                        vDb.list[trx.voucherUsed].used += 1;
                        saveVoucher(vDb);
                    }
                }

                const buyerName = trx.username ? `@${trx.username}` : `User_${trx.userId}`;
                const itemSent = product.fileId || product.extraItems;
                let deliveryCaption = `<blockquote>✅ <b>PEMBAYARAN QRIS BERHASIL</b>\n\n📦 Produk: ${product.nameDisplay}\n💰 Total: Rp ${trx.price.toLocaleString()}</blockquote>`;

                if (product.fileType === 'document') {
                    await bot.sendDocument(trx.chatId, itemSent, { caption: deliveryCaption, parse_mode: 'HTML' });
                } else {
                    await bot.sendMessage(trx.chatId, `${deliveryCaption}\n\n<code>${itemSent}</code>`, { parse_mode: 'HTML' });
                }

                const channelNotification = `<blockquote>💰 <b>PRODUK TERJUAL (QRIS)</b>\n\n🛒 <b>Produk:</b> ${product.nameDisplay}\n💸 <b>Total:</b> Rp ${trx.price.toLocaleString()}\n👤 <b>Buyer:</b> ${buyerName}\n✔ <b>STATUS: SUCCESS</b></blockquote>`;
                await bot.sendPhoto(CHANNEL_ID, "https://files.catbox.moe/40p7bv.jpg", { caption: channelNotification, parse_mode: 'HTML' });

                await bot.editMessageCaption(`<blockquote>✅ <b>BERHASIL DIKONFIRMASI</b>\nProduk telah dikirim ke ${buyerName}</blockquote>`, {
                    chat_id: callbackQuery.message.chat.id,
                    message_id: callbackQuery.message.message_id,
                    parse_mode: 'HTML'
                });

            } else {
                await bot.sendMessage(trx.chatId, "<blockquote>✘ <b>PEMBAYARAN DITOLAK</b>\nBukti transfer tidak valid atau tidak sesuai.</blockquote>", { parse_mode: 'HTML' });
                await bot.editMessageCaption(`<blockquote>✘ <b>TRANSAKSI DITOLAK</b></blockquote>`, {
                    chat_id: callbackQuery.message.chat.id,
                    message_id: callbackQuery.message.message_id,
                    parse_mode: 'HTML'
                });
            }

            delete global.unconfirmedTransactions[userId];
            return true;
        }
        return false;
    },

    onPhoto: async (bot, msg, settings) => {
        const userId = msg.from.id;
        const trx = global.unconfirmedTransactions[userId];

        if (trx && trx.status === 'AWAITING_PROOF') {
            const photoId = msg.photo[msg.photo.length - 1].file_id;
            const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;

            trx.status = 'WAITING_CONFIRMATION';
            await bot.sendMessage(msg.chat.id, "<blockquote>✅ <b>Bukti Terkirim!</b>\nMohon tunggu konfirmasi Owner.</blockquote>", { parse_mode: 'HTML' });

            const captionOwner = `<blockquote>🔔 <b>KONFIRMASI PEMBAYARAN</b>\n\n👤 Buyer: @${trx.username || 'User'}\n📦 Produk: ${trx.stockName}\n💰 Nominal: Rp ${trx.price.toLocaleString()}</blockquote>`;
            const keyboard = {
                inline_keyboard: [[
                    { text: "✅ KONFIRMASI", callback_data: `acc_pay_${userId}` },
                    { text: "❌ TOLAK", callback_data: `rej_pay_${userId}` }
                ]]
            };

            return bot.sendPhoto(ownerId, photoId, { caption: captionOwner, reply_markup: keyboard, parse_mode: 'HTML' });
        }
    }
};