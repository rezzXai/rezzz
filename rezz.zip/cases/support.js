module.exports = {

    keyword: 'support',

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        // 1. Desain Teks (Gaya Quote & Small Caps)

        const teks = 

            "<b>S U P P O R T  S Y S T E M</b>\n" +

            "<blockquote>(🕊️) ᴛʜᴀɴᴋꜱ ꜰᴏʀ ᴇᴠᴇʀʏᴛʜɪɴɢ. ᴛʜɪꜱ ᴘʀᴏᴊᴇᴄᴛ ꜱᴛᴀɴᴅ ᴛʜɪꜱ ꜰᴀʀ ʙᴇᴄᴀᴜꜱᴇ ᴏꜰ ʏᴏᴜʀ ᴘʀᴀʏᴇʀꜱ ᴀɴᴅ ꜱᴜᴘᴘᴏʀᴛ.</blockquote>\n" +

            "╭─( ᴛʜᴀɴᴋꜱ ᴛᴏ ) ❞\n" +

            "⪼ ᴀʟʟᴀʜ [ ᴍʏ ɢᴏᴅ ]\n" +

            "⪼ ᴍʏ ᴍᴏᴍ [ ᴇᴍᴀᴋ ɢᴜᴀ ]\n" +

            "⪼ ᴢɪɪꜱᴛʀ [ ᴅᴇᴠᴇʟᴏᴘᴇʀ ]\n" +

            "╰────────────┈⊷\n" +

            "<blockquote>(ツ) ᴋᴇᴍʙᴀʟɪ</blockquote>";

        try {

            // 2. Kirim Pesan Teks Terlebih Dahulu

            await bot.sendMessage(chatId, teks, { 

                parse_mode: 'HTML',

                reply_markup: {

                    inline_keyboard: [

                        [{ text: '─── [ OurDev ] ───', url: 'https://t.me/ziistr' }]

                    ]

                }

            });

            // 3. Kirim Musik (Audio)

            // Ganti URL/Path di bawah dengan file musik Anda (.mp3)

            const audioUrl = "https://files.catbox.moe/lp9nzt.mp3"; 

            

            await bot.sendAudio(chatId, audioUrl, {

                caption: "🎧 <i>reflexing</i>",

                parse_mode: 'HTML'

            });

        } catch (e) {

            console.error("Error UI Support:", e.message);

            bot.sendMessage(chatId, "❌ Terjadi kesalahan saat mengirim dukungan.");

        }

    }

};