const axios = require('axios');

const cheerio = require('cheerio');

module.exports = {

    keyword: 'pinsearch',

    keywordAliases: ['pincari', 'caripin'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const text = msg.text.split(' ').slice(1).join(' ');

        if (!text) return bot.sendMessage(chatId, "✘ Masukkan kata kunci pencarian!\nContoh: `/pinsearch ayam`", { parse_mode: 'Markdown' });

        const loading = await bot.sendMessage(chatId, `🔍 ᴘʀᴏsᴇs sᴇᴀʀᴄʜ ${text} ...`);

        try {

            const searchUrl = `https://www.google.com/search?q=${encodeURIComponent(text + ' pinterest')}&tbm=isch`;

            

            const { data } = await axios.get(searchUrl, {

                headers: {

                    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36"

                }

            });

            const $ = cheerio.load(data);

            let images = [];

            // 1. Ambil semua URL gambar dari scraping

            $('img').each((index, element) => {

                const src = $(element).attr('src');

                // Lewati gambar pertama (biasanya logo Google)

                if (src && src.startsWith('http') && index > 0) {

                    images.push(src);

                }

            });

            if (images.length < 10) throw new Error("Gambar tidak cukup ditemukan.");

            // 2. ACAK GAMBAR (Shuffle) agar hasil selalu berbeda

            images.sort(() => Math.random() - 0.5);

            // 3. AMBIL 10 GAMBAR (Sesuai permintaan)

            const selectedImages = images.slice(0, 10);

            // 4. KIRIM SATU PER SATU DENGAN JEDA

            for (let i = 0; i < selectedImages.length; i++) {

                await bot.sendPhoto(chatId, selectedImages[i], {

                    caption: i === 0 ? `✅ ᴘʀᴇᴠɪᴇᴡ: ${text}` : "",

                    reply_to_message_id: i === 0 ? msg.message_id : null 

                });

                // JEDA 1,2 DETIK (1200ms) agar lebih aman kirim 10 gambar sekaligus

                await new Promise(resolve => setTimeout(resolve, 1200));

            }

            // Hapus pesan loading setelah semua terkirim

            bot.deleteMessage(chatId, loading.message_id).catch(() => {});

        } catch (e) {

            console.error(e);

            bot.editMessageText("❌ **Gagal mengambil 10 gambar.** Coba kata kunci lain atau tunggu sebentar.", {

                chat_id: chatId,

                message_id: loading.message_id

            });

        }

    }

};