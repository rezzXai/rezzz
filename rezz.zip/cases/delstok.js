// cases/delstok.js (V3: Menghapus Seluruh Stok Menggunakan Lowdb yang Dikuatkan)

const { deleteProduct } = require('../lib/stokdb'); 

module.exports = {
    keyword: 'delstok',
    keywordAliases: ['/delstok', '/hapusstok'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        // Menggunakan split untuk parsing argumen setelah command
        const args = msg.text.split(' ').slice(1).join(' ').trim(); 
        
        if (String(msg.from.id) !== String(settings.OWNER_ID)) {
            return bot.sendMessage(chatId, "❌ Hanya OWNER bot yang dapat menggunakan perintah ini.", { reply_to_message_id: msg.message_id });
        }

        const stockNameRaw = args;
        
        if (!stockNameRaw) {
            return bot.sendMessage(chatId, "❌ Format salah. Gunakan: `/delstok Nama Barang`", { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // deleteProduct akan secara otomatis mengkonversi input ke UPPERCASE dan TRIM (dijamin di lib/stokdb.js)
        const isDeleted = deleteProduct(stockNameRaw);
        
        if (isDeleted) {
            return bot.sendMessage(chatId, 
                `✅ **Seluruh Stok Produk ${stockNameRaw.toUpperCase()} Berhasil Dihapus!**\n(Termasuk File/Script ID dan kuantitas).`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else {
             return bot.sendMessage(chatId, 
                `❌ Stok dengan nama **${stockNameRaw.toUpperCase()}** tidak ditemukan di database.`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};