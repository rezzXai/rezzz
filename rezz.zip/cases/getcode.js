const axios = require('axios');

module.exports = {

    keyword: '/getcode',

    keywordAliases: ['getcode', 'ceksc'],

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        if (userId !== Number(settings.OWNER_ID)) {

            return bot.sendMessage(chatId, "✘ ᴀᴄᴄᴇss ᴅᴇɴɪᴇᴅ.");

        }

        const replyMsg = msg.reply_to_message;

        if (!replyMsg || !replyMsg.document) {

            return bot.sendMessage(chatId, "<blockquote>Reply file .js lalu ketik /getcode</blockquote>", { parse_mode: 'HTML' });

        }

        const doc = replyMsg.document;

        const statusMsg = await bot.sendMessage(chatId, "⏳ <i>Reading & Cleaning code...</i>", { parse_mode: 'HTML' });

        try {

            const fileLink = await bot.getFileLink(doc.file_id);

            const response = await axios.get(fileLink);

            let codeContent = response.data.toString();

            // 🔥 SOLUSI ERROR 400: Encode karakter < dan > agar tidak dianggap HTML error

            const cleanCode = (text) => text.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

            const header = `<b>📄 sᴏᴜʀᴄᴇ ᴄᴏᴅᴇ ᴠɪᴇᴡᴇʀ</b>\n<blockquote>ғɪʟᴇ: ${doc.file_name}</blockquote>\n\n`;

            const maxLength = 3500; // Dikurangi agar lebih aman bagi limit Telegram

            if (codeContent.length <= maxLength) {

                await bot.editMessageText(header + `<pre>${cleanCode(codeContent)}</pre>`, {

                    chat_id: chatId,

                    message_id: statusMsg.message_id,

                    parse_mode: 'HTML'

                });

            } else {

                const chunks = [];

                for (let i = 0; i < codeContent.length; i += maxLength) {

                    chunks.push(codeContent.substring(i, i + maxLength));

                }

                // Kirim bagian pertama (Edit pesan status)

                await bot.editMessageText(header + `<b>📦 Part 1 / ${chunks.length}</b>\n<pre>${cleanCode(chunks[0])}</pre>`, {

                    chat_id: chatId,

                    message_id: statusMsg.message_id,

                    parse_mode: 'HTML'

                });

                // Kirim bagian selanjutnya

                for (let j = 1; j < chunks.length; j++) {

                    await new Promise(res => setTimeout(res, 1000)); // Jeda 1 detik agar tidak Flood limit

                    await bot.sendMessage(chatId, `<b>📦 Part ${j + 1} / ${chunks.length}</b>\n<pre>${cleanCode(chunks[j])}</pre>`, { parse_mode: 'HTML' });

                }

            }

        } catch (e) {

            console.error(e);

            await bot.editMessageText(`❌ ᴇʀʀᴏʀ: ${e.message}`, {

                chat_id: chatId,

                message_id: statusMsg.message_id

            });

        }

    }

};