const { drawNulis } = require('../lib/canvas');

module.exports = {

    keyword: 'nulis',

    keywordAliases: ['/nulis', 'magernulis', 'tulis'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        

        // Mengambil teks setelah perintah /nulis

        // Contoh: /nulis Hari ini saya belajar koding

        const text = msg.text || "";

        const args = text.split(' ').slice(1).join(' ');

        // Validasi input jika kosong

        if (!args) {

            return bot.sendMessage(chatId, "❌ Teksnya mana?\n\nContoh: `/nulis Nama: Rezi\nKelas: 12\nTugas: Menulis Estetik`", { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        }

        // Mengirim status "sedang mengetik" atau loading agar user tahu bot bekerja

        const loadingMsg = await bot.sendMessage(chatId, "✍️ *Tunggu sebentar, Rezi sedang menulis di kertas vintage...*", { parse_mode: 'Markdown' });

        try {

            // Memanggil fungsi drawNulis yang sudah kita buat di lib/canvas.js

            const imageBuffer = await drawNulis(args);

            // Kirim hasilnya dalam bentuk foto

            await bot.sendPhoto(chatId, imageBuffer, {

                caption: `✅ Berhasil Menulis!`,

                reply_to_message_id: msg.message_id

            });

        } catch (e) {

            console.error("Error Fitur Nulis:", e);

            bot.sendMessage(chatId, "❌ Waduh, ada masalah!\nPastikan library `canvas` sudah terinstal di VPS kamu.");

        } finally {

            // Hapus pesan loading setelah gambar terkirim

            bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

        }

    }

};