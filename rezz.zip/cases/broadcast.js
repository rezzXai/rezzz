const fs = require('fs');
const path = require('path');

module.exports = {
    keyword: 'bc',
    keywordAliases: ['/bc', '/broadcast'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // 1. Verifikasi Owner
        const ownerId = Number(settings.OWNER_ID);
        if (userId !== ownerId) {
            return bot.sendMessage(chatId, "✘ ᴏᴡɴᴇʀ ᴏɴʟʏ.");
        }

        // 2. Ambil Data dari Pesan yang di-Reply
        const replyMsg = msg.reply_to_message;
        
        if (!replyMsg) {
            return bot.sendMessage(chatId, 
                `<b>✘ 𝙎𝘼𝙇𝘼𝙃 𝙋𝙍𝙊𝙎𝙀𝘿𝙐𝙍</b>\n` +
                `<blockquote>Silakan reply pesan (gambar, video, file, atau teks) yang ingin disebarkan, lalu ketik /bc</blockquote>`, { parse_mode: 'HTML' });
        }

        // Identifikasi konten dari pesan yang di-reply
        const broadcastText = replyMsg.caption || replyMsg.text || "";
        const photo = replyMsg.photo ? replyMsg.photo[replyMsg.photo.length - 1].file_id : null;
        const video = replyMsg.video ? replyMsg.video.file_id : null;
        const document = replyMsg.document ? replyMsg.document.file_id : null;
        const audio = replyMsg.audio ? replyMsg.audio.file_id : null;
        const sticker = replyMsg.sticker ? replyMsg.sticker.file_id : null;

        // 3. Path ke database/users.json
        const filePath = path.join(__dirname, '..', 'database', 'users.json'); 
        if (!fs.existsSync(filePath)) {
            return bot.sendMessage(chatId, "✘ ᴜsᴇʀs.ᴊsᴏɴ ɴᴏᴛ ғᴏᴜɴᴅ.", { parse_mode: 'HTML' });
        }

        try {
            const data = JSON.parse(fs.readFileSync(filePath, 'utf-8'));
            const users = data.users || [];
            const total = users.length;

            if (total === 0) return bot.sendMessage(chatId, "✘ ᴀʟʟ ᴜsᴇʀ ɴᴏᴛ ғᴏᴜɴᴅ.");

            const statusMsg = await bot.sendMessage(chatId, 
                `🚀 <b>𝗠𝗘𝗠𝗨𝗟𝗔𝗜 𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧...</b>\n` +
                `<blockquote><code>[░░░░░░░░░░]</code> 0%</blockquote>`, { parse_mode: 'HTML' });

            let success = 0;
            let failed = 0;

            for (let i = 0; i < total; i++) {
                try {
                    await new Promise(resolve => setTimeout(resolve, 300)); // Jeda 300ms

                    const targetId = users[i].id;

                    if (photo) {
                        await bot.sendPhoto(targetId, photo, { caption: broadcastText, parse_mode: 'HTML' });
                    } else if (video) {
                        await bot.sendVideo(targetId, video, { caption: broadcastText, parse_mode: 'HTML' });
                    } else if (document) {
                        await bot.sendDocument(targetId, document, { caption: broadcastText, parse_mode: 'HTML' });
                    } else if (audio) {
                        await bot.sendAudio(targetId, audio, { caption: broadcastText, parse_mode: 'HTML' });
                    } else if (sticker) {
                        await bot.sendSticker(targetId, sticker);
                    } else {
                        await bot.sendMessage(targetId, broadcastText, { parse_mode: 'HTML' });
                    }
                    success++;
                } catch (e) {
                    failed++;
                }

                // Update Progress Bar setiap 5 user
                if ((i + 1) % 5 === 0 || (i + 1) === total) {
                    const percent = Math.round(((i + 1) / total) * 100);
                    const progress = Math.round(percent / 10);
                    const progressBar = "█".repeat(progress) + "░".repeat(10 - progress);
                    
                    try {
                        await bot.editMessageText(
                            `📡 <b>𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧𝗜𝗡𝗚 𝗜𝗡 𝗣𝗥𝗢𝗚𝗥𝗘𝗦𝗦</b>\n\n` +
                            `<blockquote><code>[${progressBar}]</code> ${percent}%</blockquote>\n` +
                            `<b>◈ sᴛᴀᴛɪsᴛɪᴋ</b>\n` +
                            `<blockquote>` +
                            `• ✅ ʙᴇʀʜᴀsɪʟ: ${success}\n` +
                            `• ❌ ɢᴀɢᴀʟ: ${failed}\n` +
                            `• 👥 ᴛᴏᴛᴀʟ: ${total}</blockquote>`,
                            { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }
                        );
                    } catch (err) {}
                }
            }

            return bot.editMessageText(
                `📢 <b>𝗕𝗥𝗢𝗔𝗗𝗖𝗔𝗦𝗧 𝗦𝗘𝗟𝗘𝗦𝗔𝗜</b>\n` +
                `➖➖➖➖➖➖➖➖➖➖➖➖\n\n` +
                `<b>◈ ʟᴀᴘᴏʀᴀɴ ᴀᴋʜɪʀ</b>\n` +
                `<blockquote>` +
                `• 🟢 ʙᴇʀʜᴀsɪʟ : ${success}\n` +
                `• 🔴 ɢᴀɢᴀʟ    : ${failed}\n` +
                `• ✨ ᴛᴏᴛᴀʟ    : ${total}</blockquote>\n\n` +
                `➖➖➖➖➖➖➖➖➖➖➖➖\n` +
                `<i>Laporan telah diperbarui otomatis.</i>`,
                { chat_id: chatId, message_id: statusMsg.message_id, parse_mode: 'HTML' }
            );

        } catch (error) {
            console.error(error);
            return bot.sendMessage(chatId, "❌ Terjadi kesalahan pada sistem broadcast.");
        }
    }
};