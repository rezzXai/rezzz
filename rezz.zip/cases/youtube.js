// File: cases/youtube.js (Perbaikan dan Peningkatan Error Handling)

// PENTING: Mengimpor dari file 'yt.js' di root folder
const { ytDonlodMp4 } = require('../yt'); 
const { URL } = require('url');

// Batas ukuran file Telegram untuk bot (50 MB)
const MAX_TELEGRAM_SIZE = 50 * 1024 * 1024; 

module.exports = {
    keyword: 'youtube',
    keywordAliases: ['yt'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const text = msg.text.trim();
        const parts = text.split(/\s+/);
        
        if (parts.length < 2) {
            return bot.sendMessage(chatId, 
                `❌ Format salah.\n\nGunakan: \`/youtube <URL Video YouTube>\``, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const url = parts[1]; 
        
        try {
            // Memastikan URL valid
            new URL(url); 
        } catch (e) {
            return bot.sendMessage(chatId, "❌ Masukkan URL YouTube yang valid.", { reply_to_message_id: msg.message_id });
        }

        const loadingMsg = await bot.sendMessage(chatId, "⏳ Memproses dan mengunduh video, mohon tunggu...");

        try {
            // Asumsi ytDonlodMp4(url) mengembalikan objek { url, title, channel, views, size }
            const result = await ytDonlodMp4(url); 
            
            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
            
            if (!result || !result.url) {
                return bot.sendMessage(chatId, "❌ Gagal mendapatkan link download video MP4 yang kompatibel. Coba URL lain.", { reply_to_message_id: msg.message_id });
            }

            // --- Pengecekan Ukuran File (PENTING untuk Telegram) ---
            if (result.size && result.size > MAX_TELEGRAM_SIZE) {
                const sizeMB = (result.size / (1024 * 1024)).toFixed(2);
                return bot.sendMessage(chatId, 
                    `⚠️ **VIDEO TERLALU BESAR!**\n\n` + 
                    `Ukuran video ini (${sizeMB} MB) melebihi batas Telegram (50 MB).\n` +
                    `Anda dapat mengunduhnya secara manual: ${result.url}`, 
                    { reply_to_message_id: msg.message_id });
            }
            // --------------------------------------------------------
            
            const caption = `
🎬 **DOWNLOAD BERHASIL!**
            
**Judul:** ${result.title}
**Channel:** ${result.channel}
**Views:** ${result.views.toLocaleString()}
            `;

            await bot.sendVideo(chatId, result.url, { 
                caption: caption,
                parse_mode: 'Markdown',
                supports_streaming: true,
                reply_to_message_id: msg.message_id 
            });

        } catch (e) {
            console.error(`🔴 Error di /youtube: ${e.message}`, e); // Logging lebih detail
            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
            
            // Memberikan pesan error yang lebih informatif
            let errorMessage = "Terjadi kesalahan saat mengunduh video.";
            if (e.message.includes('400')) {
                errorMessage += " Kemungkinan URL video tidak valid atau video tidak ditemukan.";
            } else if (e.message.includes('timeout')) {
                errorMessage += " Proses unduhan terlalu lama dan waktu habis (timeout). Coba lagi atau gunakan video yang lebih pendek.";
            } else if (e.message.includes('403')) {
                errorMessage += " Akses ke video ditolak (video berbayar atau dibatasi).";
            }
            
            bot.sendMessage(chatId, errorMessage);
        }
    }
};