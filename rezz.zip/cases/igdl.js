// /cases/igdl.js (Instagram Downloader)

const { instagramDownload } = require('@mrnima/instagram-downloader');
const axios = require('axios');

module.exports = {
    keyword: 'igdl',
    keywordAliases: ['/igdl', '/instadl', '/reels'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const args = msg.text.split(' ').slice(1);
        
        // --- 1. Validasi Argumen ---
        if (args.length === 0) {
            return bot.sendMessage(chatId, 
                "❌ **Format Salah.** Harap sertakan tautan (link) Instagram Post/Reels.\n" +
                "Contoh: `/igdl https://www.instagram.com/reel/...`",
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const url = args[0].trim();
        
        const waitMessage = await bot.sendMessage(chatId, `⏳ Sedang memproses tautan Instagram... Mohon tunggu.`, 
            { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });

        try {
            // --- 2. Memanggil Downloader API ---
            // Fungsi ini akan mengembalikan array of objects (untuk slide post atau video tunggal)
            const result = await instagramDownload(url);

            if (!result || !result.data || result.data.length === 0) {
                throw new Error("Tautan tidak valid atau tidak dapat mengambil data media.");
            }

            // --- 3. Mengirim Media ke Telegram ---
            
            const mediaItems = result.data;
            const mediaType = mediaItems[0].type; // 'video' atau 'image'
            const mediaUrl = mediaItems[0].url; // Ambil URL media yang bisa diunduh
            const captionText = `✅ **Berhasil mengunduh media Instagram!**\n\n*Judul:* ${mediaItems[0].caption || 'Tidak ada deskripsi.'}`;
            
            
            // Mengunduh dan mengirimkan video atau foto
            if (mediaType === 'video') {
                await bot.sendVideo(chatId, mediaUrl, {
                    caption: captionText,
                    parse_mode: 'Markdown'
                });
            } else if (mediaType === 'image') {
                await bot.sendPhoto(chatId, mediaUrl, {
                    caption: captionText,
                    parse_mode: 'Markdown'
                });
            } else {
                 await bot.sendMessage(chatId, `❌ Gagal: Tipe media tidak didukung (${mediaType}).`, { parse_mode: 'Markdown' });
            }

            // --- 4. Hapus pesan "sedang memproses" ---
            await bot.deleteMessage(chatId, waitMessage.message_id).catch(() => {});


        } catch (error) {
            console.error(`Gagal mengunduh IG: ${error.message}`);
             
            await bot.editMessageText(`❌ **Gagal Mengunduh Media Instagram.**\n\nDetail: ${error.message}\n\n*Catatan: API unduhan sering berubah. Jika ini terus terjadi, mungkin diperlukan pembaruan library.*`, {
                chat_id: chatId,
                message_id: waitMessage.message_id,
                parse_mode: 'Markdown'
            });
        }
    }
};