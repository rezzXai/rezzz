const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'addegg',

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text || "";

        

        const eggDbPath = path.join(__dirname, '../database/egg.json');

        // Pemanggilan ID Owner sesuai sistem kamu

        if (!settings.OWNER_ID.includes(userId)) {

            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.", { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        }

        // Cek apakah user me-reply file

        if (!msg.reply_to_message || !msg.reply_to_message.document) {

            return bot.sendMessage(chatId, "⚠️ Silakan reply file Egg (.json) dengan mengetik `/addegg nama_egg`", { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        }

        // Pastikan folder & file database ada

        if (!fs.existsSync(path.join(__dirname, '../database'))) {

            fs.mkdirSync(path.join(__dirname, '../database'));

        }

        if (!fs.existsSync(eggDbPath)) {

            fs.writeFileSync(eggDbPath, JSON.stringify([]));

        }

        let eggDb = JSON.parse(fs.readFileSync(eggDbPath));

        const doc = msg.reply_to_message.document;

        const eggName = text.split(' ').slice(1).join(' ') || doc.file_name;

        // Simpan ke database

        eggDb.push({

            name: eggName,

            file_id: doc.file_id,

            file_name: doc.file_name

        });

        fs.writeFileSync(eggDbPath, JSON.stringify(eggDb, null, 2));

        

        return bot.sendMessage(chatId, `✅ EGG BERHASIL DISIMPAN\n\nNama: \`${eggName}\`\nFile: \`${doc.file_name}\``, { 

            parse_mode: 'Markdown',

            reply_to_message_id: msg.message_id 

        });

    }

};