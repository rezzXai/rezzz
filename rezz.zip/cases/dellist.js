const { getGithubData, updateGithubData } = require('../lib/github');

module.exports = {
    keyword: 'dellist',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        try {
            const github = await getGithubData();
            if (!github) return bot.sendMessage(chatId, "❌ Gagal terhubung ke GitHub.");

            // 1. Cek Owner dari GitHub
            const isOwner = github.data.owners.includes(String(userId));
            if (!isOwner) {
                return bot.sendMessage(chatId, "<blockquote>❌ <b>AKSES DITOLAK</b>\nperintah ini hanya boleh di gunakan devv.</blockquote>", { parse_mode: 'HTML' });
            }

            // 2. Ambil ID Target
            const targetId = msg.text.split(' ')[1];
            if (!targetId) return bot.sendMessage(chatId, "<blockquote>⚠️ <b>Gunakan:</b> /dellist [ID_USER]</blockquote>", { parse_mode: 'HTML' });

            // 3. Proses Hapus
            if (!github.data.list_buyer) return bot.sendMessage(chatId, "❌ List buyer kosong.");
            
            const initialLength = github.data.list_buyer.length;
            github.data.list_buyer = github.data.list_buyer.filter(user => String(user.id) !== String(targetId));

            if (github.data.list_buyer.length < initialLength) {
                await updateGithubData(github.data, github.sha);
                bot.sendMessage(chatId, `<blockquote>✅ <b>BERHASIL DIHAPUS</b>\nID <code>${targetId}</code> telah dihapus dari database GitHub.</blockquote>`, { parse_mode: 'HTML' });
            } else {
                bot.sendMessage(chatId, "❌ ID tidak ditemukan dalam list.");
            }

        } catch (e) {
            bot.sendMessage(chatId, "❌ Terjadi kesalahan sistem.");
        }
    }
};