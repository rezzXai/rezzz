const { pinDownloader } = require('../pin'); 
const axios = require('axios');
const settings = require('../setting');

module.exports = {
    keyword: 'pindl',
    keywordAliases: ['pin', 'pinterest'],
    
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const args = msg.text.trim().split(/\s+/);

        // --- VALIDASI OWNER ---
        if (!settings.OWNER_ID.includes(userId)) {
            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.", { reply_to_message_id: msg.message_id });
        }

        if (args.length < 2) {
            return bot.sendMessage(chatId, "❌ Masukkan link Pinterest!");
        }

        const url = args[1];
        // Validasi link sederhana agar tidak memproses link sampah
        if (!url.includes('pinterest.com') && !url.includes('pin.it')) {
            return bot.sendMessage(chatId, "❌ Itu bukan link Pinterest yang valid!");
        }

        const loadingMsg = await bot.sendMessage(chatId, "⏳ Memproses Pinterest...");

        try {
            const result = await pinDownloader(url);
            
            // --- PROTEKSI RAM 122 MiB ---
            // Cek ukuran file sebelum download ke buffer
            const checkHeader = await axios.head(result.url);
            const fileSizeInBytes = checkHeader.headers['content-length'];
            const fileSizeInMB = fileSizeInBytes / (1024 * 1024);

            if (fileSizeInMB > 20) { // Batasi maksimal 20MB agar RAM aman
                return bot.sendMessage(chatId, `❌ **File Terlalu Besar:** Ukuran file (${fileSizeInMB.toFixed(2)} MB) melebihi batas RAM bot.`);
            }

            // Download ke Buffer
            const response = await axios.get(result.url, { 
                responseType: 'arraybuffer',
                headers: { 'User-Agent': 'Mozilla/5.0' }
            });

            const buffer = Buffer.from(response.data, 'binary');

            if (result.type === 'video') {
                await bot.sendVideo(chatId, buffer, { 
                    caption: `✅ **Pinterest Video Success**\n_By RezzXai_`,
                    parse_mode: 'Markdown'
                });
            } else {
                await bot.sendPhoto(chatId, buffer, { 
                    caption: `✅ **Pinterest Image Success**\n_By RezzXai_`,
                    parse_mode: 'Markdown'
                });
            }

        } catch (e) {
            console.error(`🔴 PinDL Error: ${e.message}`);
            // Pesan error lebih rapi
            bot.sendMessage(chatId, `❌ **Gagal:** ${e.message === 'Media tidak ditemukan' ? 'Link tidak didukung atau privat.' : 'Terjadi gangguan koneksi.'}`);
        } finally {
            // Hapus loading message
            bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
        }
    }
};