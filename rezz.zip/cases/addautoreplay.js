const fs = require('fs');

const path = require('path');

// Path database ke root folder

const dbPath = path.join(__dirname, '../autoreplay.json');

// Pastikan file json ada saat pertama kali dijalankan

if (!fs.existsSync(dbPath)) {

    fs.writeFileSync(dbPath, JSON.stringify([], null, 2));

}

module.exports = {

    keyword: 'addautoreplay',

    keywordAliases: ['delautoreplay', 'listautoreplay'],

    

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text ? msg.text.split(/\s+/).slice(1).join(" ") : "";

        const command = msg.text.split(/\s+/)[0].toLowerCase().replace('/', '');

        

        // Proteksi Owner (Menggunakan global isOwner dari rezz.js kamu)

        if (!global.isOwner(userId)) {

            return bot.sendMessage(chatId, "✘ Akses Ditolak: Khusus Owner!");

        }

        let db = JSON.parse(fs.readFileSync(dbPath, 'utf-8'));

        // === CASE: TAMBAH ===

        if (command === 'addautoreplay') {

            if (!text.includes(',')) {

                return bot.sendMessage(chatId, "✘ Format salah!\n\nContoh: `/addautoreplay tekspesan,teksjawaban`", { parse_mode: 'Markdown' });

            }

            

            const [pesan, jawaban] = text.split(',');

            const keyword = pesan.trim().toLowerCase();

            const response = jawaban.trim();

            const index = db.findIndex(x => x.key === keyword);

            if (index !== -1) {

                db[index].res = response;

            } else {

                db.push({ key: keyword, res: response });

            }

            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

            return bot.sendMessage(chatId, `✅ Auto Reply Disimpan\n\n💬 Jika user ketik: "${keyword}"\n🤖 Bot menjawab: "${response}"`, { parse_mode: 'Markdown' });

        }

        // === CASE: HAPUS ===

        if (command === 'delautoreplay') {

            if (!text) return bot.sendMessage(chatId, "✘ Masukkan kata kunci yang ingin dihapus!");

            const target = text.trim().toLowerCase();

            

            const filteredDb = db.filter(x => x.key !== target);

            if (db.length === filteredDb.length) return bot.sendMessage(chatId, "✘ Kata kunci tidak ditemukan.");

            fs.writeFileSync(dbPath, JSON.stringify(filteredDb, null, 2));

            return bot.sendMessage(chatId, `🗑️ Berhasil menghapus auto reply: ${target}`, { parse_mode: 'Markdown' });

        }

        // === CASE: LIST ===

        if (command === 'listautoreplay') {

            if (db.length === 0) return bot.sendMessage(chatId, "⚠️ Belum ada auto reply.");

            let teks = "📋 DAFTAR AUTO REPLY\n\n";

            db.forEach((v, i) => {

                teks += `${i + 1}. ${v.key} ➔ ${v.res}\n`;

            });

            return bot.sendMessage(chatId, teks, { parse_mode: 'Markdown' });

        }

    }

};