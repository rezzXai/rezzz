// cases/payment.js (REVISI FINAL + DEBUGGING PATH)

const settings = require('../setting');
const path = require('path');
const fs = require('fs');

// --- PASTIKAN NAMA FILE INI 100% BENAR ---
const QRIS_IMAGE_PATH = path.join(__dirname, '..', '11.jpg'); 

// --- Fungsi untuk menghasilkan konten pesan (agar bisa dipakai berulang) ---
function getPaymentContent() {
    // ... (Konten dan Keyboard Anda) ...
    const initialCaption = 
        `𝗦𝗘𝗥𝗧𝗔𝗞𝗔𝗡 𝗕𝗨𝗞𝗧𝗜 𝗧𝗥𝗔𝗡𝗦𝗙𝗘𝗥\n\n` +
        `ᴘɪʟɪʜ ʙᴜᴛᴛᴏɴ 〠`;
    
    const inlineKeyboard = {
        inline_keyboard: [
            [
                { text: ' 𝗗𝗔𝗡𝗔', callback_data: '/dana' }, 
                { text: ' 𝗕𝗖𝗔', callback_data: '/bca' }
            ],
            [
               { text: ' 𝗤𝗥𝗜𝗦', 
                 url: 'https://files.catbox.moe/mr721o.jpg' }
             ],
            [
                { text: '☜ʙᴀᴄᴋ', callback_data: '/start_callback' } 
            ]
           ]
         };
    
    return { initialCaption, inlineKeyboard };
}


module.exports = {
    keyword: '/payment',
    keywordAliases: ['/payment_callback'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        const isCallback = !!msg.callbackQuery; 
        const messageId = isCallback ? msg.callbackQuery.message.message_id : msg.message_id;
        
        const imageExists = fs.existsSync(QRIS_IMAGE_PATH);
        const { initialCaption, inlineKeyboard } = getPaymentContent();

        // ----------------------------------------------------
        // >>> DEBUG PATH CHECK <<<
        console.log(`[DEBUG /payment] Cek Path Gambar: ${QRIS_IMAGE_PATH}`);
        console.log(`[DEBUG /payment] File Ditemukan (fs.existsSync): ${imageExists}`);
        // ----------------------------------------------------

        const options = {
            caption: initialCaption,
            parse_mode: 'HTML', 
            reply_markup: inlineKeyboard,
            reply_to_message_id: isCallback ? undefined : msg.message_id
        };
        
        // --- LOGIKA UTAMA (Edit atau Kirim Baru) ---
        if (isCallback) {
            // Aksi: EDIT CAPTION pesan yang ada
            try {
                await bot.editMessageCaption(initialCaption, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML',
                    reply_markup: inlineKeyboard
                });
            } catch (e) {
                if (e.message && e.message.includes('message is not modified')) { return; }
                
                console.warn(`Gagal mengedit pesan /payment: ${e.message}. Mencoba mengirim baru.`);
                
                // Fallback: Kirim pesan baru
                 if (imageExists) {
                    await bot.sendPhoto(chatId, QRIS_IMAGE_PATH, options);
                } else {
                    await bot.sendMessage(chatId, initialCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
                }
            }
            
        } else {
            // Aksi: KIRIM PESAN BARU (ketika /payment diketik)
            if (imageExists) {
                await bot.sendPhoto(chatId, QRIS_IMAGE_PATH, options)
                .catch(async error => {
                    // Log error spesifik dari bot.sendPhoto di sini!
                    console.error(`🔴 GAGAL EKSEKUSI sendPhoto di /payment. Error Rincian:`, error.message);
                    
                    // Fallback: Kirim pesan teks tanpa foto
                    await bot.sendMessage(chatId, 
                        `❌ **Kesalahan:** Gagal menampilkan QRIS/Foto. (Detail Error: ${error.message.substring(0, 50)}...)\n\nBerikut menu pembayaran:\n\n${initialCaption}`, 
                        { 
                            parse_mode: 'HTML',
                            reply_markup: inlineKeyboard
                        }
                    );
                });
            } else {
                console.warn(`[WARN] File foto QRIS tidak ditemukan di path: ${QRIS_IMAGE_PATH}. Mengirim teks saja.`);
                await bot.sendMessage(chatId, initialCaption, { parse_mode: 'HTML', reply_markup: inlineKeyboard });
            }
        }
    }
};