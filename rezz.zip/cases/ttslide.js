const axios = require('axios');

const settings = require('../setting');

module.exports = {

    keyword: 'ttslide',

    keywordAliases: ['tiktokslide', 'ttfoto'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.trim().split(/\s+/);

        // --- VALIDASI OWNER ---

        if (!settings.OWNER_ID.includes(userId)) {

            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.", { reply_to_message_id: msg.message_id });

        }

        if (args.length < 2) {

            return bot.sendMessage(chatId, "❌ Masukkan link TikTok Slide!");

        }

        const url = args[1];

        const loadingMsg = await bot.sendMessage(chatId, "⏳ Sedang mengambil slide foto...");

        try {

            // Menggunakan API TikWM yang sangat stabil untuk konten slide/photo

            const res = await axios.post('https://www.tikwm.com/api/', new URLSearchParams({

                url: url,

                count: 12,

                cursor: 0,

                web: 1,

                hd: 1

            }));

            const data = res.data.data;

            // Pastikan ini adalah postingan foto/slide

            if (!data.images || data.images.length === 0) {

                throw new Error("Postingan ini bukan tipe slide foto (mungkin video).");

            }

            // --- PROSES KIRIM MEDIA GROUP ---

            const mediaGroup = [];

            

            // Batasi maksimal 10 foto (Limit Telegram Media Group)

            const images = data.images.slice(0, 10);

            for (let i = 0; i < images.length; i++) {

                mediaGroup.push({

                    type: 'photo',

                    media: images[i],

                    caption: i === 0 ? `✅ **TikTok Slide Success**\n📝 ${data.title || '-'}\n\n_By RezzXai_` : '',

                    parse_mode: 'Markdown'

                });

            }

            await bot.sendMediaGroup(chatId, mediaGroup, { reply_to_message_id: msg.message_id });

        } catch (e) {

            console.error(`🔴 TTSlide Error: ${e.message}`);

            bot.sendMessage(chatId, `❌ **Gagal:** ${e.message}`);

        } finally {

            bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

        }

    }

};