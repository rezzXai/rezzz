const axios = require('axios');
const fs = require('fs');
const path = require('path');

// --- PENGATURAN DATABASE LOKAL ---
const dbDir = path.join(__dirname, '../database');
const dbPath = path.join(dbDir, 'adddbtoken.json');

// Auto-Create Folder & File jika belum ada (Mencegah Error ENOENT)
if (!fs.existsSync(dbDir)) {
    fs.mkdirSync(dbDir, { recursive: true });
}
if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({}, null, 2));
}

module.exports = {
    keyword: 'addtoken',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text || "";

        const waitMsg = await bot.sendMessage(chatId, "⏳ <i>Menghubungkan ke Pusat (GitHub)...</i>", { parse_mode: 'HTML' });

        // --- 1. AMBIL DATA DARI GITHUB (OWNER, CONFIG, & TOKENS) ---
        let githubData;
        try {
            const API_URL = `https://api.github.com/repos/${settings.REPO_PATH}/contents/${settings.FILE_PATH}`;
            const { data: fileData } = await axios.get(API_URL, {
                headers: { 
                    'Authorization': `token ${settings.GITHUB_TOKEN}`, 
                    'Accept': 'application/vnd.github.v3+json' 
                }
            });
            githubData = JSON.parse(Buffer.from(fileData.content, 'base64').toString('utf-8'));
            githubData.sha = fileData.sha;
        } catch (e) {
            return bot.editMessageText("<blockquote>❌ <b>GAGAL SYNC</b>\nBot tidak bisa mengambil data konfigurasi dari GitHub.</blockquote>", { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: 'HTML' });
        }

        // Ambil Pengaturan yang Terkunci di GitHub
        const targetChannel = githubData.config.channel_id;
        const targetGroup = githubData.config.group_id;
        const targetLink = githubData.config.group_link;
        const isOwnerGithub = githubData.owners && githubData.owners.includes(String(userId));

        // --- 2. KUNCI SYARAT JOIN (KECUALI OWNER GITHUB) ---
        if (!isOwnerGithub) {
            try {
                const s1 = await bot.getChatMember(targetChannel, userId);
                const s2 = await bot.getChatMember(targetGroup, userId);
                
                const joined = ['member', 'administrator', 'creator'].includes(s1.status) && 
                               ['member', 'administrator', 'creator'].includes(s2.status);

                if (!joined) {
                    await bot.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
                    return bot.sendMessage(chatId, 
                        `<blockquote>🔒 <b>AKSES TERKUNCI</b>\n\nSyarat akses dikunci oleh pusat. Anda wajib bergabung ke saluran dan grup:</blockquote>`, {
                        parse_mode: 'HTML',
                        reply_markup: {
                            inline_keyboard: [
                                [{ text: "📢 Join Saluran", url: `https://t.me/${targetChannel.replace('@','')}` }],
                                [{ text: "👥 Join Grup", url: targetLink }],
                                [{ text: "🔄 REFRESH STATUS", callback_data: "check_join_status" }]
                            ]
                        }
                    });
                }
            } catch (e) {
                return bot.editMessageText("<blockquote>❌ <b>VERIFIKASI GAGAL</b>\nBot harus menjadi Admin di grup & saluran yang terdaftar di GitHub.</blockquote>", { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: 'HTML' });
            }

            // --- 3. LOGIKA LIMIT & MENU BELI ---
            let db = JSON.parse(fs.readFileSync(dbPath));
            
            if (!db[userId]) {
                db[userId] = { limit: 1, usedFree: false, usedTotal: 0 };
                fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));
                await bot.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
                return bot.sendMessage(chatId, "<blockquote>🎁 <b>FREE 1X LIMIT!</b>\n\nGunakan jatah pertama Anda:\n<code>/addtoken TOKEN_ANDA</code></blockquote>", { parse_mode: 'HTML' });
            }

            if (db[userId].limit <= 0) {
                await bot.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
                return bot.sendMessage(chatId, 
                    `<blockquote>🚫 <b>LIMIT HABIS</b>\n\nJatah add token Anda sudah habis. Silakan beli limit tambahan:</blockquote>`, {
                    parse_mode: 'HTML',
                    reply_markup: {
                        inline_keyboard: [
                            [{ text: "➕ 1 LIMIT - Rp 1.000", callback_data: "buy_limit_1" }],
                            [{ text: "➕ 3 LIMIT - Rp 3.000", callback_data: "buy_limit_3" }],
                            [{ text: "➕ 5 LIMIT - Rp 5.000", callback_data: "buy_limit_5" }],
                            [{ text: "❌ BATAL", callback_data: "cancel_purchase" }]
                        ]
                    }
                });
            }
        }

        // --- 4. PROSES UPDATE GITHUB ---
        const args = text.split(' ');
        const newToken = args[1];

        if (!newToken) {
            await bot.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
            return bot.sendMessage(chatId, "<blockquote>⚠️ <b>FORMAT SALAH</b>\nGunakan: <code>/addtoken TOKEN_BOT</code></blockquote>", { parse_mode: 'HTML' });
        }

        if (githubData.tokens.includes(newToken)) {
            await bot.deleteMessage(chatId, waitMsg.message_id).catch(() => {});
            return bot.sendMessage(chatId, "<blockquote>⚠️ <b>TOKEN TERDAFTAR</b>\nToken sudah ada di database GitHub.</blockquote>", { parse_mode: 'HTML' });
        }

        githubData.tokens.push(newToken);
        const updatedContent = Buffer.from(JSON.stringify(githubData, null, 2)).toString('base64');

        try {
            await axios.put(`https://api.github.com/repos/${settings.REPO_PATH}/contents/${settings.FILE_PATH}`, {
                message: `Add Token: ${newToken}`,
                content: updatedContent,
                sha: githubData.sha 
            }, {
                headers: { 'Authorization': `token ${settings.GITHUB_TOKEN}`, 'Accept': 'application/vnd.github.v3+json' }
            });

            // Update Database Lokal (Sisa & Statistik)
            let db = JSON.parse(fs.readFileSync(dbPath));
            if (!db[userId]) db[userId] = { limit: 0, usedTotal: 0 };
            
            db[userId].usedTotal = (db[userId].usedTotal || 0) + 1;
            
            let finalLimit = "∞";
            if (!isOwnerGithub) {
                db[userId].limit -= 1;
                db[userId].usedFree = true;
                finalLimit = `${db[userId].limit}x`;
            }

            fs.writeFileSync(dbPath, JSON.stringify(db, null, 2));

            await bot.editMessageText(`<blockquote>✅ <b>TOKEN DIDAFTARKAN</b>\n\nToken berhasil dikunci ke GitHub.\n🎫 Sisa Limit: <b>${finalLimit}</b></blockquote>`, { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: 'HTML' });

        } catch (error) {
            await bot.editMessageText("<blockquote>✘ <b>GAGAL UPDATE GITHUB</b>\nPeriksa koneksi API atau Token GitHub Anda.</blockquote>", { chat_id: chatId, message_id: waitMsg.message_id, parse_mode: 'HTML' });
        }
    }
};