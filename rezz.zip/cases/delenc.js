const fs = require('fs');

const path = require('path');

const axios = require('axios');

const tempDir = path.join(__dirname, '../temp');

module.exports = {

    keyword: 'delenc',

    keywordAliases: ['/delenc'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const replyMsg = msg.reply_to_message;

        if (!replyMsg || !replyMsg.document) {

            return bot.sendMessage(chatId, 

`✘ 𝙀𝙍𝙊𝙍 𝙊𝙈 𝙆𝙐𝙐

<pre>

━━━━━━━━━━━━━━━━━━━━

INFO   : Reply file yang mau di-clean

STATUS : FAILED

━━━━━━━━━━━━━━━━━━━━

</pre>`, { parse_mode: 'HTML' });

        }

        try {

            const fileLink = await bot.getFileLink(replyMsg.document.file_id);

            const response = await axios.get(fileLink);

            let code = response.data;

            // Logika sederhana: Menghapus komentar dan merapikan sedikit

            // (Karena obfuscation sejati tidak bisa di-reverse total)

            let decoded = code.replace(/\/\*[\s\S]*?\*\/|([^\\:]|^)\/\/.*$/gm, '$1').trim();

            const fileName = `decrypted_${replyMsg.document.file_name}`;

            const filePath = path.join(tempDir, fileName);

            fs.writeFileSync(filePath, decoded);

            await bot.sendDocument(chatId, filePath, {

                caption: `🔓 𝙎𝘾𝙍𝙄𝙋𝙏 𝘿𝙄 𝘽𝙐𝙆𝘼\n<pre>\n𝙎𝙏𝘼𝙏𝙐𝙎 : 𝙎𝙐𝘾𝘾𝙀𝙎\n𝙄𝙉𝙁𝙊   : 𝘾𝙤𝙢𝙢𝙚𝙣𝙩𝙨 𝙍𝙚𝙢𝙤𝙫𝙚𝙙\n</pre>`,

                parse_mode: 'HTML'

            });

            fs.unlinkSync(filePath);

        } catch (e) {

            bot.sendMessage(chatId, `✘ 𝙀𝙍𝙊𝙍\n<pre>${e.message}</pre>`, { parse_mode: 'HTML' });

        }

    }

};