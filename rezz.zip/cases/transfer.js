const Pengguna = require('../lib/pengguna'); // Import Library Pengguna

module.exports = {
    keyword: 'kirimsaldo',
    keywordAliases: ['tf', 'transfer'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id; // ID Pengirim
        const text = msg.text ? msg.text.trim() : "";
        const args = text.split(/\s+/);

        // 1. Cek Registrasi Pengirim via Lib
        if (!Pengguna.isTerdaftar(userId)) {
            return bot.sendMessage(chatId, "⚠️ Kamu belum terdaftar! Silakan daftar dulu untuk menggunakan fitur ini.");
        }

        // 2. Validasi Format Perintah
        if (args.length < 3) {
            return bot.sendMessage(chatId, "📑 **Format Kirimsaldo:**\n`/kirimsaldo [ID_TUJUAN] [NOMINAL]`\n\nContoh: `/kirimsaldo 12345678 5000`", { parse_mode: 'Markdown' });
        }

        const targetId = args[1];
        const nominal = parseInt(args[2]);

        // 3. Validasi Nominal
        if (isNaN(nominal) || nominal < 100) {
            return bot.sendMessage(chatId, "✘ Nominal transfer minimal adalah Rp 100.");
        }

        // 4. Cegah Transfer ke Diri Sendiri
        if (targetId === userId.toString()) {
            return bot.sendMessage(chatId, "🤣 Masa mau kirim saldo ke diri sendiri? Gak bisa ya!");
        }

        // 5. Cek Data Pengirim & Penerima via Lib
        const pengirim = Pengguna.ambil(userId);
        const penerima = Pengguna.ambil(targetId);

        // Cek apakah pengirim punya cukup saldo
        if (pengirim.saldo < nominal) {
            return bot.sendMessage(chatId, `✘ Saldo kamu tidak cukup!\nSaldo saat ini: Rp ${pengirim.saldo.toLocaleString('id-ID')}`);
        }

        // 6. Cek Keberadaan Target di Database
        if (!penerima.registered) {
            return bot.sendMessage(chatId, "✘ **ID Tujuan tidak ditemukan!**\nPastikan orang tersebut sudah terdaftar di bot ini.");
        }

        // --- PROSES TRANSFER VIA LIBRARY ---
        try {
            // Kurangi saldo pengirim
            Pengguna.tambahSaldo(userId, -nominal);
            
            // Tambah saldo penerima
            Pengguna.tambahSaldo(targetId, nominal);

            // Ambil saldo terbaru untuk laporan
            const saldoAkhirPengirim = Pengguna.ambil(userId).saldo;
            const saldoAkhirPenerima = Pengguna.ambil(targetId).saldo;

            // Pesan Konfirmasi ke Pengirim
            await bot.sendMessage(chatId, 
                `✅ **TRANSFER BERHASIL!**\n` +
                `────────────────────\n` +
                `👤 **Ke:** \`${penerima.username}\` (\`${targetId}\`)\n` +
                `💰 **Jumlah:** Rp ${nominal.toLocaleString('id-ID')}\n` +
                `💳 **Sisa Saldo:** Rp ${saldoAkhirPengirim.toLocaleString('id-ID')}\n` +
                `────────────────────`, 
                { parse_mode: 'Markdown' }
            );

            // Pesan Notifikasi ke Penerima
            await bot.sendMessage(targetId, 
                `📩 **SALDO MASUK!**\n` +
                `────────────────────\n` +
                `👤 **Dari:** \`${pengirim.username}\` (\`${userId}\`)\n` +
                `💰 **Jumlah:** Rp ${nominal.toLocaleString('id-ID')}\n` +
                `💳 **Saldo Baru:** Rp ${saldoAkhirPenerima.toLocaleString('id-ID')}\n` +
                `────────────────────`, 
                { parse_mode: 'Markdown' }
            ).catch(() => {}); 

        } catch (e) {
            console.error("🔴 Error Transfer:", e.message);
            return bot.sendMessage(chatId, "✘ Terjadi kesalahan teknis saat melakukan transfer.");
        }
    }
};