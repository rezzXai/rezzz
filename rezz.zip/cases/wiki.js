const axios = require('axios');

const settings = require('../setting'); // Mengambil OWNER_ID dari sini

module.exports = {

    keyword: 'wiki',

    keywordAliases: ['wikipedia', 'apaitu'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const args = msg.text.trim().split(/\s+/).slice(1).join(" ");

        // 1. CEK OTORISASI OWNER_ID (Array Check)

        // Memastikan ID pengirim ada di dalam list OWNER_ID di settings.js

        const isOwner = settings.OWNER_ID.includes(userId);

        

        if (!isOwner) {

            return bot.sendMessage(chatId, "✘ Akses Ditolak!\nFitur ini hanya dapat digunakan oleh Owner Bot.");

        }

        // 2. CEK INPUT

        if (!args) {

            return bot.sendMessage(chatId, "✘ Masukkan kata kunci!\nContoh: `/wiki Proklamasi`", { parse_mode: 'Markdown' });

        }

        // 3. PESAN LOADING

        const loadingMsg = await bot.sendMessage(chatId, `⏳ 𝙇𝙤𝙖𝙙𝙞𝙣𝙜...`);

        try {

            const endpoint = `https://id.wikipedia.org/api/rest_v1/page/summary/${encodeURIComponent(args)}`;

            

            const response = await axios.get(endpoint, {

                headers: {

                    'User-Agent': 'RezzBot/1.0 (Contact: owner_id_telegram)'

                }

            });

            const data = response.data;

            let pesan = `🎓 **WIKIPEDIA INDONESIA**\n\n`;

            pesan += `📌 **Topik:** ${data.title}\n`;

            pesan += `📝 **Penjelasan:** ${data.extract}\n\n`;

            pesan += `🔗 [Baca selengkapnya](${data.content_urls.desktop.page})`;

            // Kirim gambar jika ada, jika tidak hanya teks

            if (data.thumbnail && data.thumbnail.source) {

                await bot.sendPhoto(chatId, data.thumbnail.source, {

                    caption: pesan,

                    parse_mode: 'Markdown'

                });

            } else {

                await bot.sendMessage(chatId, pesan, { 

                    parse_mode: 'Markdown',

                    disable_web_page_preview: false 

                });

            }

        } catch (e) {

            console.error(`🔴 Wiki Error: ${e.message}`);

            if (e.response && e.response.status === 404) {

                bot.sendMessage(chatId, `✘ Maaf, topik "${args}" tidak ditemukan di Wikipedia.`);

            } else {

                bot.sendMessage(chatId, "✘ Terjadi gangguan saat menghubungi server Wikipedia.");

            }

        } finally {

            // 4. HAPUS PESAN LOADING

            // Menghapus pesan "Sedang mencari..." agar chat tidak penuh sampah

            bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

        }

    }

};