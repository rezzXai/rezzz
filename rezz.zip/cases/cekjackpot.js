const fs = require('fs');
const path = require('path');

module.exports = {
    keyword: 'cekjackpot',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // Validasi Owner (Menggunakan global.isOwner agar lebih akurat)
        if (!global.isOwner(userId)) {
            return bot.sendMessage(chatId, "❌ **Akses Ditolak:** Khusus Owner.");
        }

        const logDbPath = path.join(__dirname, '../database/slot_logs.json');

        if (!fs.existsSync(logDbPath)) {
            return bot.sendMessage(chatId, "📭 LOG VACANT: Belum ada data riwayat jackpot.");
        }

        let logs = JSON.parse(fs.readFileSync(logDbPath));
        if (logs.length === 0) return bot.sendMessage(chatId, "📭 LOG EMPTY: Riwayat masih kosong.");

        // Ambil 10 terakhir dan balik urutannya
        let lastLogs = logs.slice(-10).reverse();

        let message = "👑 LIST TOP 10 JACKPOT RECENT \n";
        message += "────────────────────\n\n";

lastLogs.forEach((log, index) => {
    const rank = index === 0 ? "🥇" : index === 1 ? "🥈" : index === 2 ? "🥉" : "🔹";
    
    // ✅ Perbaikan: Cek apakah result itu Array atau String agar tidak error
    const displayResult = Array.isArray(log.result) 
        ? log.result.join(' ') 
        : log.result; // Jika sudah string, langsung tampilkan

    message += `${rank} PLAYER: \`${log.name}\`\n`;
    message += `┣ ✨ Win: Rp ${log.win.toLocaleString('id-ID')}\n`;
    message += `┣ 💸 Bet: Rp ${log.bet.toLocaleString('id-ID')}\n`;
    message += `┣ 🎰 Result: [ ${displayResult} ]\n`;
    message += `┗ 📅 Date: \`${log.date}\`\n\n`;
});

        message += "────────────────────\n";
        message += `_Total Log Tercatat: ${logs.length}_`;

        return bot.sendMessage(chatId, message, { parse_mode: 'Markdown' });
    }
};