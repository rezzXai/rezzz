const axios = require('axios');

const fs = require('fs');

const path = require('path');

const tempDir = path.join(__dirname, '../temp_rename');

if (!fs.existsSync(tempDir)) fs.mkdirSync(tempDir, { recursive: true });

module.exports = {

    keyword: 'rename',

    keywordAliases: ['/rename', 'ubahname'],

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const text = msg.text || "";

        const args = text.split(' ');

        if (msg.chat.type !== 'private') return;

        // 1. Pesan Jika Salah Penggunaan (Tanpa Reply)

        const replyMsg = msg.reply_to_message;

        if (!replyMsg || (!replyMsg.document && !replyMsg.video && !replyMsg.audio)) {

            const usage = 

`❌ ERROR: TARGET TIDAK DITEMUKAN

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS   : FAILED

TARGET   : NULL (Wajib Reply)

PERINTAH : /rename [NamaBaru]

━━━━━━━━━━━━━━━━━━━━

</pre>

<i>Silakan balas sebuah file/zip untuk diubah namanya.</i>`;

            return bot.sendMessage(chatId, usage, { parse_mode: 'HTML' });

        }

        // 2. Pesan Jika Nama Baru Tidak Diisi

        const newNameInput = args.slice(1).join('_'); 

        if (!newNameInput) {

            const noName = 

`⚠️ WARNING: NAMA KOSONG

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS   : INPUT REQUIRED

INFO     : Nama baru belum diisi.

CONTOH   : /rename file_baru

━━━━━━━━━━━━━━━━━━━━

</pre>`;

            return bot.sendMessage(chatId, noName, { parse_mode: 'HTML' });

        }

        const file = replyMsg.document || replyMsg.video || replyMsg.audio;

        const oldName = file.file_name || "file";

        const extension = path.extname(oldName) || ""; 

        const finalFileName = newNameInput + extension;

        const loadingMsg = await bot.sendMessage(chatId, "⏳ <code>SISTEM: Sedang memproses file...</code>", { parse_mode: 'HTML' });

        try {

            const fileId = file.file_id;

            const fileLink = await bot.getFileLink(fileId);

            const tempFilePath = path.join(tempDir, finalFileName);

            const response = await axios({

                method: 'GET',

                url: fileLink,

                responseType: 'stream'

            });

            const writer = fs.createWriteStream(tempFilePath);

            response.data.pipe(writer);

            writer.on('finish', async () => {

                // 3. Pesan Sukses

                const successCaption = 

`✅ SUCCESS: RENAME COMPLETED

<pre>

━━━━━━━━━━━━━━━━━━━━

OLD NAME : ${oldName}

NEW NAME : ${finalFileName}

SIZE     : ${(file.file_size / 1024 / 1024).toFixed(2)} MB

STATUS   : Berhasil Dikirim

━━━━━━━━━━━━━━━━━━━━

</pre>`;

                await bot.sendDocument(chatId, tempFilePath, {

                    caption: successCaption,

                    parse_mode: 'HTML'

                });

                bot.deleteMessage(chatId, loadingMsg.message_id);

                if (fs.existsSync(tempFilePath)) fs.unlinkSync(tempFilePath);

            });

            writer.on('error', (err) => {

                const writeError = 

`❌ ERROR: WRITE SYSTEM

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS : DISK ERROR

INFO   : Gagal menulis file ke sistem.

━━━━━━━━━━━━━━━━━━━━

</pre>`;

                bot.sendMessage(chatId, writeError, { parse_mode: 'HTML' });

            });

        } catch (e) {

            const systemError = 

`❌ ERROR: SYSTEM FAILURE

<pre>

━━━━━━━━━━━━━━━━━━━━

STATUS : SERVER ERROR

INFO   : Gagal mengambil file.

LOG    : ${e.message.substring(0, 20)}...

━━━━━━━━━━━━━━━━━━━━

</pre>`;

            bot.sendMessage(chatId, systemError, { parse_mode: 'HTML' });

        }

    }

};