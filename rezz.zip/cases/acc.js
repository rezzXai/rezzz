const Pengguna = require('../lib/pengguna');
const fs = require('fs');
const path = require('path');

module.exports = {
    keyword: 'accdepo',
    callbackHandler: async (bot, callbackQuery, settings) => {
        const data = callbackQuery.data;
        const chatId = callbackQuery.message.chat.id;
        const messageId = callbackQuery.message.message_id;
        const dbLimitPath = path.join(__dirname, '../database/adddbtoken.json');
        const premPath = path.join(__dirname, '../database/premium.json'); // Tambahkan path premium

        // --- 1. LOGIKA BATAL (Oleh User) ---
        if (data.startsWith('cancel_depo_') || data === 'cancel_purchase') {
            const targetId = data.includes('_') ? data.split('_')[2] : callbackQuery.from.id;
            
            if (callbackQuery.from.id != targetId) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "❌ Ini bukan sesi Anda!", show_alert: true });
            }

            if (global.depositSession && global.depositSession[targetId]) {
                delete global.depositSession[targetId];
            }
            
            await bot.deleteMessage(chatId, messageId).catch(() => {});
            await bot.sendMessage(chatId, "<blockquote>❌ <b>Permintaan dibatalkan.</b></blockquote>", { parse_mode: 'HTML' });
            return true; 
        }

        // --- 2. LOGIKA ACC/TOLAK (Oleh Owner) ---
        if (data.startsWith('acc_depo_') || data.startsWith('rej_depo_')) {
            const targetUserId = data.split('_')[2];
            const session = global.depositSession[targetUserId];

            if (!session) {
                return bot.answerCallbackQuery(callbackQuery.id, { text: "⚠️ Sesi tidak ditemukan/kadaluwarsa." });
            }

            if (data.startsWith('acc_depo_')) {
                // --- A. JIKA INI PEMBELIAN PREMIUM LIMIT (TAMBAHAN BARU) ---
                if (session.type === 'BUY_PREMIUM') {
                    if (!fs.existsSync(premPath)) fs.writeFileSync(premPath, JSON.stringify({}));
                    let premDb = JSON.parse(fs.readFileSync(premPath));
                    
                    const now = Date.now();
                    let expiryTime;
                    let labelDurasi;

                    if (session.days === 999) {
                        expiryTime = now + (100 * 365 * 24 * 60 * 60 * 1000); // 100 Tahun
                        labelDurasi = "PERMANEN";
                    } else {
                        expiryTime = now + (session.days * 24 * 60 * 60 * 1000);
                        labelDurasi = `${session.days} HARI`;
                    }

                    // Format waktu WIB untuk pesan
                    const dateWIB = new Date(expiryTime).toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' });

                    premDb[targetUserId] = {
                        id: targetUserId,
                        expiry: expiryTime,
                        type: labelDurasi,
                        dateStr: dateWIB
                    };

                    fs.writeFileSync(premPath, JSON.stringify(premDb, null, 2));

                    // Notif ke User
                    await bot.sendMessage(targetUserId, 
                        `<blockquote>✅ <b>PREMIUM AKTIF</b>\n\n` +
                        `Selamat! Akun Anda kini berstatus <b>PREMIUM ${labelDurasi}</b>.\n` +
                        `Masa aktif s/d: <b>${dateWIB} WIB</b>.\n\n` +
                        `Sekarang Anda bebas menggunakan <code>/addtoken</code> tanpa limit!</blockquote>`, 
                        { parse_mode: 'HTML' }
                    );

                    // Broadcast ke Saluran
                    const logMsg = `<blockquote>💎 <b>PREMIUM SOLD!</b>\n\n` +
                                   `📦 Paket: <b>PREMIUM ${labelDurasi}</b>\n` +
                                   `👤 User: @${session.username || targetUserId}\n` +
                                   `💰 Nominal: <b>Rp ${session.nominal.toLocaleString()}</b>\n` +
                                   `✅ Status: <b>AKTIF (ACC)</b></blockquote>`;
                    await bot.sendMessage(settings.CHANNEL_ID, logMsg, { parse_mode: 'HTML' }).catch(() => {});

                // --- B. JIKA INI PEMBELIAN LIMIT ADDTOKEN (STOK LAMA) ---
                } else if (session.type === 'BUY_LIMIT') {
                    let dbLimit = JSON.parse(fs.readFileSync(dbLimitPath));
                    if (!dbLimit[targetUserId]) dbLimit[targetUserId] = { limit: 0, usedFree: true };
                    
                    dbLimit[targetUserId].limit += session.qty;
                    fs.writeFileSync(dbLimitPath, JSON.stringify(dbLimit, null, 2));

                    await bot.sendMessage(targetUserId, `<blockquote>✅ <b>PEMBELIAN BERHASIL</b>\n\nLimit <b>+${session.qty}</b> telah ditambahkan ke akun Anda.</blockquote>`, { parse_mode: 'HTML' });

                    const logMsg = `<blockquote>📢 <b>ADA YANG BUY</b>\n\n` +
                                   `📦 Produk: <b>+${session.qty} Limit Add Token</b>\n` +
                                   `👤 User: @${session.username || targetUserId}\n` +
                                   `💰 Nominal: <b>Rp ${session.nominal.toLocaleString()}</b>\n` +
                                   `✅ Status: <b>BERHASIL (ACC)</b></blockquote>`;
                    await bot.sendMessage(settings.CHANNEL_ID, logMsg, { parse_mode: 'HTML' }).catch(() => {});

                } else { 
                    // --- C. JIKA INI DEPOSIT SALDO BIASA ---
                    Pengguna.tambahSaldo(targetUserId, session.nominal);
                    await bot.sendMessage(targetUserId, `<blockquote>🔔 <b>DEPOSIT BERHASIL</b>\n\nSaldo sebesar <b>Rp ${session.nominal.toLocaleString()}</b> telah ditambahkan.</blockquote>`, { parse_mode: 'HTML' });
                }

                // Update Pesan di Bot Owner
                await bot.editMessageCaption(`<blockquote>✅ <b>TRANSAKSI DI-ACC</b>\nUser: @${session.username}\nTipe: ${session.type || 'DEPOSIT'}</blockquote>`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML'
                });

            } else {
                // --- JIKA DITOLAK ---
                await bot.sendMessage(targetUserId, "<blockquote>❌ <b>PERMINTAAN DITOLAK</b>\nBukti transfer tidak valid atau tidak masuk.</blockquote>", { parse_mode: 'HTML' });
                await bot.editMessageCaption(`<blockquote>❌ <b>TRANSAKSI DITOLAK</b></blockquote>`, {
                    chat_id: chatId,
                    message_id: messageId,
                    parse_mode: 'HTML'
                });
            }

            delete global.depositSession[targetUserId];
            return true;
        }

        return false;
    }
};