const { getVoucher, saveVoucher } = require('../lib/voucherdb');

module.exports = {

    keyword: 'voucher',

    // Gabungkan alias agar bot mengenali perintah tanpa / maupun dengan /

    keywordAliases: ['delvoucher', '/voucher', '/delvoucher', 'cekvoucher', '/cekvoucher'],

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text || "";

        const args = text.split(' ');

        

        // Membersihkan command dari '/' dan spasi

        const command = args[0].toLowerCase().replace('/', '').trim();

        

        const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;

        if (String(userId) !== String(ownerId)) {

            return bot.sendMessage(chatId, "❌ Hanya Owner yang bisa mengelola voucher.");

        }

        let db = getVoucher();

        if (!db.list) db.list = {}; // Safety check jika list belum ada

        // --- 1. FITUR CEK DAFTAR VOUCHER ---

        if (command === 'cekvoucher') {

            const keys = Object.keys(db.list);

            if (keys.length === 0) return bot.sendMessage(chatId, "🎟️ Belum ada voucher aktif.");

            let listMsg = "📜 **DAFTAR VOUCHER AKTIF:**\n\n";

            keys.forEach((kode, index) => {

                const v = db.list[kode];

                listMsg += `${index + 1}. Kode: \`${kode}\`\n`;

                listMsg += `   Diskon: ${v.diskon}% | Terpakai: ${v.used}/${v.limit}\n\n`;

            });

            return bot.sendMessage(chatId, listMsg, { parse_mode: 'Markdown' });

        }

        // --- 2. HAPUS VOUCHER (Dipindahkan ke atas agar tidak bentrok dengan pembuatan) ---

        if (command === 'delvoucher') {

            // Mengambil kode setelah spasi (contoh: /delvoucher PROMO)

            const kode = args[1]?.trim().toUpperCase();

            

            if (!kode) return bot.sendMessage(chatId, "💡 Format: `/delvoucher KODE`\nContoh: `/delvoucher PROMO50`", { parse_mode: 'Markdown' });

            

            if (!db.list[kode]) {

                return bot.sendMessage(chatId, `❌ Voucher **${kode}** tidak ditemukan dalam database.`, { parse_mode: 'Markdown' });

            }

            delete db.list[kode];

            saveVoucher(db);

            return bot.sendMessage(chatId, `🗑️ Voucher **${kode}** berhasil dihapus dari sistem.`);

        }

        // --- 3. TAMBAH VOUCHER (/voucher KODE,DISKON,LIMIT) ---

        if (command === 'voucher') {

            const inputText = args.slice(1).join(' ');

            const input = inputText.split(',');

            if (input.length < 3) {

                return bot.sendMessage(chatId, "💡 **Cara Tambah Voucher:**\n`/voucher KODE,DISKON,LIMIT` \n\nContoh: `/voucher PROMO50,50,5`", { parse_mode: 'Markdown' });

            }

            const kode = input[0].trim().toUpperCase();

            const diskon = parseInt(input[1].replace(/[^0-9]/g, ''));

            const limit = parseInt(input[2].replace(/[^0-9]/g, ''));

            if (isNaN(diskon) || diskon <= 0 || diskon > 100 || isNaN(limit)) {

                return bot.sendMessage(chatId, "❌ Input diskon (1-100) atau limit harus berupa angka valid.");

            }

            db.list[kode] = {

                diskon: diskon,

                limit: limit,

                used: 0

            };

            

            saveVoucher(db);

            return bot.sendMessage(chatId, `✅ **Voucher Berhasil Dibuat!**\n\nKode: \`${kode}\`\nPotongan: ${diskon}%\nKuota: ${limit} Pengguna.`, { parse_mode: 'Markdown' });

        }

    }

};