// /cases/listaksesa2f.js - REVISI MENGGUNAKAN global.isOwner()

const { getAccessList } = require('../lib/a2f_db');

module.exports = {
    keyword: 'listaksesa2f', 
    keywordAliases: ['/listaksesa2f'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id; // Ambil ID sebagai Number
        
        // --- 1. Cek Keamanan (Gunakan helper global.isOwner yang terdefinisi di rezz.js) ---
        // Pengecekan ini harus menggunakan fungsi global.isOwner() yang ada di rezz.js
        if (typeof global.isOwner !== 'function' || !global.isOwner(senderId)) {
             return bot.sendMessage(chatId, 
                "❌ **Akses Ditolak.** Perintah ini hanya untuk Owner bot.", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 2. Ambil Daftar ID ---
        const allowedIds = getAccessList();
        
        // --- 3. Susun Pesan ---
        let response = `👥 **Daftar Pengguna dengan Akses /a2f:**\n\n`;
        
        if (allowedIds.length === 0) {
            response += "*(Kosong) Belum ada ID pengguna yang ditambahkan selain Owner.*";
        } else {
            // Urutkan ID untuk tampilan yang rapi
            // Note: Jika ID disimpan sebagai String, sorting akan berupa lexicographical
            allowedIds.sort((a, b) => String(a).localeCompare(String(b)));
            
            allowedIds.forEach((id, index) => {
                response += `${index + 1}. \`${id}\`\n`;
            });
            
            response += `\n*Total ID Terdaftar: ${allowedIds.length}*`;
        }

        // --- 4. Kirim Pesan ---
        await bot.sendMessage(chatId, response, { 
            parse_mode: 'Markdown', 
            reply_to_message_id: msg.message_id 
        });
    }
};