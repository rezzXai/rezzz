const axios = require('axios');

module.exports = {

    keyword: 'deltoken',

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text || "";

        // 1. KEAMANAN: Hanya Owner Pusat yang bisa akses

        if (!global.githubOwners || !global.githubOwners.includes(String(userId))) {

            return bot.sendMessage(chatId, "<blockquote><b>❌ AKSES DITOLAK</b>\nFitur ini khusus Owner Pusat.</blockquote>", { parse_mode: 'HTML' });

        }

        const args = text.split(' ');

        const targetToken = args[1];

        if (!targetToken) {

            return bot.sendMessage(chatId, "<blockquote><b>⚠️ FORMAT SALAH</b>\nGunakan:\n <code>/deltoken [nomor/token]</code></blockquote>", { parse_mode: 'HTML' });

        }

        bot.sendMessage(chatId, "<blockquote>⏳ Sedang memproses penghapusan...</blockquote>", { parse_mode: 'HTML' });

        try {

            // 2. AMBIL DATA DARI GITHUB

            const API_URL = `https://api.github.com/repos/${settings.REPO_PATH}/contents/${settings.FILE_PATH}`;

            const { data: fileData } = await axios.get(API_URL, {

                headers: { 

                    'Authorization': `token ${settings.GITHUB_TOKEN}`,

                    'Accept': 'application/vnd.github.v3+json'

                }

            });

            let content = JSON.parse(Buffer.from(fileData.content, 'base64').toString('utf-8'));

            let tokens = content.tokens;

            let initialCount = tokens.length;

            // 3. LOGIKA PENGHAPUSAN

            if (!isNaN(targetToken)) {

                const index = parseInt(targetToken) - 1;

                if (index >= 0 && index < tokens.length) {

                    tokens.splice(index, 1);

                } else {

                    return bot.sendMessage(chatId, "<blockquote><b>❌ GAGAL</b>\nNomor urut tidak ditemukan.</blockquote>", { parse_mode: 'HTML' });

                }

            } else {

                content.tokens = tokens.filter(t => t !== targetToken);

            }

            if (content.tokens.length === initialCount) {

                return bot.sendMessage(chatId, "<blockquote><b>❌ GAGAL</b>\nToken tidak ditemukan dalam database.</blockquote>", { parse_mode: 'HTML' });

            }

            // 4. UPDATE KE GITHUB

            const updatedContent = Buffer.from(JSON.stringify(content, null, 2)).toString('base64');

            await axios.put(API_URL, {

                message: `Update: Delete Token via Bot`,

                content: updatedContent,

                sha: fileData.sha

            }, {

                headers: { 

                    'Authorization': `token ${settings.GITHUB_TOKEN}`,

                    'Accept': 'application/vnd.github.v3+json'

                }

            });

            return bot.sendMessage(chatId, "<blockquote><b>✅ BERHASIL</b>\nToken telah dicabut dari database pusat.</blockquote>", { parse_mode: 'HTML' });

        } catch (error) {

            return bot.sendMessage(chatId, "<blockquote><b>❌ ERROR</b>\nGagal menghubungi GitHub API.</blockquote>", { parse_mode: 'HTML' });

        }

    }

};