const settings = require('../setting');

module.exports = {

    keyword: 'maintenance',

    keywordAliases: ['/mt', 'mt'],

    handler: async (bot, msg) => {

        const userId = msg.from.id;

        if (!global.isOwner(userId)) return;

        const args = msg.text.split(' ')[1]?.toLowerCase();

        if (args === 'on') {

            settings.MAINTENANCE_MODE = true;

            return bot.sendMessage(msg.chat.id, "✔ ᴏɴ ᴍᴀɪɴᴛᴀɴᴄᴇ.");

        } else if (args === 'off') {

            settings.MAINTENANCE_MODE = false;

            return bot.sendMessage(msg.chat.id, "✘ ᴏғғ ᴍᴀɪɴᴛᴀɴᴄᴇ.");

        } else {

            return bot.sendMessage(msg.chat.id, "Gunakan: <code>/mt on</code> atau <code>/mt off</code>", { parse_mode: 'HTML' });

        }

    }

};