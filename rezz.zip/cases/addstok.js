// cases/addstok.js (V5: Mendukung Kategori + Stok + File + Blockquote HTML)

const { addProduct, findProduct } = require('../lib/stokdb'); 

module.exports = {
    keyword: 'addstok', 
    keywordAliases: ['/addstok', '/tambahstok'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        // 1. Cek Owner
        const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;
        if (String(msg.from.id) !== String(ownerId)) {
            return bot.sendMessage(chatId, "<blockquote>❌ <b>AKSES DITOLAK</b>\nHanya owner yang dapat menggunakan perintah ini.</blockquote>", { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        }

        const isReply = msg.reply_to_message;
        const isFileOrTextReply = isReply && (msg.reply_to_message.document || msg.reply_to_message.photo || (msg.reply_to_message.text && msg.reply_to_message.text.length > 0));
        
        // Cek apakah user mereply file/teks
        if (!isReply || !isFileOrTextReply) {
             return bot.sendMessage(chatId, 
                "<blockquote>❌ <b>FORMAT SALAH</b>\n\n" +
                "Mohon <b>Reply File/Script/Foto</b> Anda, lalu kirim:\n" +
                "<code>/addstok [NAMA],[HARGA],[KUANTITAS],[KATEGORI]</code>\n\n" +
                "<b>Contoh:</b>\n" +
                "<code>/addstok ML100,25000,10,GAME</code></blockquote>", 
                { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        }

        // 2. Parsing Argumen
        const textMsg = msg.text || "";
        const args = textMsg.split(' ').slice(1).join(' ').trim();
        const header = args.split('\n')[0].split(',').map(p => p.trim());
        const extraItems = args.split('\n').slice(1).join('\n'); 

        if (header.length < 4) {
             return bot.sendMessage(chatId, "<blockquote>❌ <b>WAJIB DIISI</b>\nMohon sertakan NAMA,HARGA,KUANTITAS,dan KATEGORI.</blockquote>", { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        }

        const stockNameRaw = header[0]; 
        const stockName = stockNameRaw.toUpperCase().trim(); 
        const price = parseInt(header[1].replace(/\./g, '').replace(/rp/i, ''));
        const count = parseInt(header[2]);
        const category = header[3].toUpperCase().trim(); 
        const description = header.length > 4 ? header.slice(4).join(', ') : 'Tidak ada deskripsi';
        
        if (isNaN(price) || price <= 0 || isNaN(count) || count <= 0) {
            return bot.sendMessage(chatId, "<blockquote>❌ <b>INPUT TIDAK VALID</b>\nHarga dan Kuantitas harus berupa angka valid.</blockquote>", { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
        }
        
        if (findProduct(stockName)) {
            return bot.sendMessage(chatId, `<blockquote>⚠️ <b>GAGAL</b>\nProduk <b>${stockNameRaw}</b> sudah ada dalam database.</blockquote>`, { parse_mode: 'HTML' });
        }

        // 3. Ambil File ID / Data
        const replyMsg = msg.reply_to_message;
        let fileId = null;
        let fileType = 'text';

        if (replyMsg.document) {
            fileId = replyMsg.document.file_id;
            fileType = 'document';
        } else if (replyMsg.photo) {
            fileId = replyMsg.photo[replyMsg.photo.length - 1].file_id;
            fileType = 'photo';
        } else if (replyMsg.text) {
             fileId = replyMsg.text; 
             fileType = 'text';
        }
        
        // 4. Simpan ke Database
        const newProduct = {
            name: stockName,
            nameDisplay: stockNameRaw,
            price: price,
            count: count,
            category: category,
            description: description,
            fileId: fileId,
            fileType: fileType,
            extraItems: extraItems, 
            addedDate: new Date().toISOString()
        };

        addProduct(newProduct); 
        
        // 5. Respon Berhasil
        const response = 
            `<blockquote>✅ <b>PRODUK BERHASIL DITAMBAHKAN</b>\n\n` +
            `📦 <b>Nama:</b> ${stockNameRaw}\n` +
            `📂 <b>Kategori:</b> ${category}\n` +
            `💰 <b>Harga:</b> Rp ${price.toLocaleString('id-ID')}\n` +
            `✨ <b>Stok:</b> ${count} unit\n` + 
            `🛠 <b>Tipe:</b> ${fileType.toUpperCase()}</blockquote>`;

        bot.sendMessage(chatId, response, { parse_mode: 'HTML', reply_to_message_id: msg.message_id });
    }
};