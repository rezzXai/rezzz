const fs = require('fs');

const path = require('path');

module.exports = {

    keyword: 'getegg',

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const text = msg.text || "";

        const args = text.split(' ')[1];

        

        const eggDbPath = path.join(__dirname, '../database/egg.json');

        if (!fs.existsSync(eggDbPath)) {

            return bot.sendMessage(chatId, "📭 Belum ada Egg yang disimpan di database.");

        }

        let eggDb = JSON.parse(fs.readFileSync(eggDbPath));

        if (eggDb.length === 0) {

            return bot.sendMessage(chatId, "📭 Database Egg masih kosong.");

        }

        // Tampilkan daftar jika tidak ada argumen nomor

        if (!args) {

            let listMsg = "📂 DAFTAR EGG TERSEDIA\n\n";

            eggDb.forEach((egg, index) => {

                listMsg += `${index + 1}. \`${egg.name}\`\n`;

            });

            listMsg += "\nContoh ambil: `/getegg 1`";

            return bot.sendMessage(chatId, listMsg, { 

                parse_mode: 'Markdown',

                reply_to_message_id: msg.message_id 

            });

        }

        // Ambil file berdasarkan nomor

        const index = parseInt(args) - 1;

        if (eggDb[index]) {

            const target = eggDb[index];

            return bot.sendDocument(chatId, target.file_id, { 

                caption: `✅ Berhasil mengambil Egg: ${target.name}`,

                reply_to_message_id: msg.message_id 

            });

        } else {

            return bot.sendMessage(chatId, "❌ Nomor Egg tidak ditemukan. Ketik `/getegg` untuk cek daftar.");

        }

    }

};