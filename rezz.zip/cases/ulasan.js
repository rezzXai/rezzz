const fs = require('fs');

const path = require('path');

const folderPath = path.join(__dirname, '../data');

const ulasanPath = path.join(folderPath, 'ulasan.json');

if (!fs.existsSync(folderPath)) fs.mkdirSync(folderPath, { recursive: true });

if (!fs.existsSync(ulasanPath)) fs.writeFileSync(ulasanPath, JSON.stringify([], null, 2));

const getData = () => {

    try {

        return JSON.parse(fs.readFileSync(ulasanPath));

    } catch (e) { return []; }

};

const saveData = (d) => fs.writeFileSync(ulasanPath, JSON.stringify(d, null, 2));

module.exports = {

    // Pastikan keyword hanya satu kata kunci utama

    keyword: 'ulasan',

    // Aliases ditambahkan tanpa garis miring jika sistem rezz.js sudah otomatis menanganinya

    keywordAliases: ['cekulasan', 'testi'],

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const text = msg.text || "";

        const args = text.split(' ');

        

        // Menentukan command tanpa /

        const command = args[0].toLowerCase().replace(/^\//, '');

        let ulasanDb = getData();

        // LOGIKA 1: MEMBERI ULASAN

        if (command === 'ulasan') {

            const rating = parseInt(args[1]);

            const pesan = args.slice(2).join(' ');

            if (isNaN(rating) || rating < 1 || rating > 5 || !pesan) {

                return bot.sendMessage(chatId, " <b>✘ 𝙎𝘼𝙇𝘼𝙃 𝙊𝙈</b>\n\nGunakan: <code>/ulasan [🌟1-5] [pesan]</code>\nContoh: <code>/ulasan 5 bot sangat cepat</code>", { parse_mode: 'HTML' });

            }

            const dataBaru = {

                id_tele: msg.from.id,

                username: msg.from.username ? `@${msg.from.username}` : "-",

                nama: msg.from.first_name || "User",

                rating: rating,

                pesan: pesan,

                date: new Date().toLocaleString("id-ID", { timeZone: "Asia/Jakarta" }) + " WIB"

            };

            ulasanDb.push(dataBaru);

            saveData(ulasanDb);

            return bot.sendMessage(chatId, `✅ <b>Terima Kasih ${msg.from.first_name}!</b>\nUlasan bintang ${"⭐".repeat(rating)} telah disimpan.`, { parse_mode: 'HTML' });

        }

        // LOGIKA 2: CEK ULASAN (10 PER HALAMAN)

        if (command === 'cekulasan' || command === 'testi') {

            if (ulasanDb.length === 0) {

                return bot.sendMessage(chatId, " <b>✘ 𝙏𝙄𝘿𝘼𝙆 𝘼𝘿𝘼 𝙐𝙇𝘼𝙎𝘼𝙉</b>\n𝘣𝘦𝘳𝘪 𝘳𝘢𝘵𝘪𝘯𝘨 𝘥𝘦𝘯𝘨𝘢𝘯 𝘬𝘦𝘵𝘪𝘬 /𝘶𝘭𝘢𝘴𝘢𝘯", { parse_mode: 'HTML' });

            }

            const limit = 10;

            const totalUlasan = ulasanDb.length;

            const totalPages = Math.ceil(totalUlasan / limit);

            

            let page = parseInt(args[1]) || 1;

            if (page < 1) page = 1;

            if (page > totalPages) page = totalPages;

            const startIndex = (page - 1) * limit;

            const endIndex = startIndex + limit;

            const tampil = [...ulasanDb].reverse().slice(startIndex, endIndex);

            let res = `🌟 <b>𝙐𝙡𝙖𝙨𝙖𝙣 𝙋𝙚𝙢𝙗𝙚𝙡𝙞 (𝘩𝘢𝘭𝘢𝘮𝘢𝘯 ${page}/${totalPages})</b>\n`;

            res += `━━━━━━━━━━━━━━━━━━\n<pre>`;

            

            tampil.forEach((u, i) => {

                const num = startIndex + i + 1;

                res += `${num}. ${u.nama}\n`;

                res += `   ID: ${u.id_tele}\n`;

                res += `   Rating: ${"⭐".repeat(u.rating)}\n`;

                res += `   Pesan: "${u.pesan}"\n`;

                res += `   Tgl: ${u.date}\n`;

                res += `──────────────────\n`;

            });

            res += `</pre>\n`;

            res += `✍️ <b>𝘽𝙚𝙧𝙞 𝙐𝙡𝙖𝙨𝙖𝙣 𝘿𝙚𝙣𝙜𝙖𝙣 𝙆𝙚𝙩𝙞𝙠 /𝘶𝘭𝘢𝘴𝘢𝘯 </b>\n`;

            res += `<i>Total: ${totalUlasan} ulasan.</i>`;

            // Gunakan tombol keyboard teks biasa agar tidak perlu edit rezz.js

            let btns = [];

            if (page > 1) btns.push({ text: `/cekulasan ${page - 1}` });

            if (page < totalPages) btns.push({ text: `/cekulasan ${page + 1}` });

            return bot.sendMessage(chatId, res, {

                parse_mode: 'HTML',

                reply_markup: {

                    keyboard: btns.length > 0 ? [btns] : [],

                    resize_keyboard: true,

                    one_time_keyboard: true

                }

            });

        }

    }

};