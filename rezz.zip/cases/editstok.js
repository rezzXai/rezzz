const { updateProductDetail } = require('../lib/stokdb');

module.exports = {
    keyword: 'editstok',
    keywordAliases: ['/editstok', 'ubahstok'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // 1. Cek Owner
        const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;
        if (String(userId) !== String(ownerId)) {
            return bot.sendMessage(chatId, "<blockquote>❌ <b>AKSES DITOLAK</b>\nHanya owner yang dapat mengedit stok.</blockquote>", { parse_mode: 'HTML' });
        }

        // 2. Ambil Argumen (Format: NamaLama, NamaBaru, Harga, Stok)
        const text = msg.text || "";
        const args = text.split(' ').slice(1).join(' ').split(',');

        if (args.length < 4) {
            return bot.sendMessage(chatId, 
                `<blockquote>⚠️ <b>FORMAT SALAH</b>\n\n` +
                `Gunakan:\n<code>/editstok NamaLama,NamaBaru,Harga,Kuantitas</code>\n\n` +
                `<b>Contoh:</b>\n<code>/editstok ML100,ML 100 PROMO,15000,50</code></blockquote>`, 
                { parse_mode: 'HTML' });
        }

        const oldName = args[0].trim();
        const newNameDisplay = args[1].trim();
        const newPrice = parseInt(args[2].replace(/\./g, '').replace(/rp/i, '').trim());
        const newCount = parseInt(args[3].trim());

        if (isNaN(newPrice) || isNaN(newCount)) {
            return bot.sendMessage(chatId, "<blockquote>❌ <b>INPUT TIDAK VALID</b>\nPastikan harga dan jumlah berupa angka valid.</blockquote>", { parse_mode: 'HTML' });
        }

        // 3. Eksekusi Update ke Database (LowDB)
        const success = updateProductDetail(oldName, {
            name: newNameDisplay,
            price: newPrice,
            count: newCount
        });

        if (success) {
            const response = 
                `<blockquote>✅ <b>PRODUK DIPERBARUI</b>\n\n` +
                `📝 <b>Nama:</b> <s>${oldName.toUpperCase()}</s> ➜ <b>${newNameDisplay}</b>\n` +
                `💰 <b>Harga:</b> Rp ${newPrice.toLocaleString('id-ID')}\n` +
                `📦 <b>Stok:</b> ${newCount} unit\n\n` +
                `<i>Kategori dan file produk tetap dipertahankan.</i></blockquote>`;

            return bot.sendMessage(chatId, response, { parse_mode: 'HTML' });
        } else {
            return bot.sendMessage(chatId, `<blockquote>❌ <b>GAGAL</b>\nProduk <b>${oldName}</b> tidak ditemukan.</blockquote>`, { parse_mode: 'HTML' });
        }
    }
};