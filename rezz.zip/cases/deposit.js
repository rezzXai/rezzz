const fs = require('fs');
const path = require('path');
const Pengguna = require('../lib/pengguna');

// Memori sementara untuk menunggu bukti foto
if (!global.depositSession) global.depositSession = {};

module.exports = {
    keyword: 'deposit',
    keywordAliases: ['ceksaldo'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const args = msg.text.split(' ');
        const qrisPath = path.join(__dirname, '..', 'qris.jpg');

        // --- 1. FITUR CEK SALDO ---
        if (msg.text.startsWith('/ceksaldo')) {
            const dataUser = Pengguna.ambil(userId);
            return bot.sendMessage(chatId, 
                `<blockquote>💰 <b>YOUR BALANCE</b>\n\n` +
                `👤 User: <b>${msg.from.first_name}</b>\n` +
                `💳 Saldo: <b>Rp ${dataUser.saldo.toLocaleString('id-ID')}</b>\n\n` +
                `<i>Gunakan saldo untuk belanja hemat & cepat!</i></blockquote>`, 
                { parse_mode: 'HTML' }
            );
        }

        // --- 2. FITUR REQUEST DEPOSIT ---
        const nominal = parseInt(args[1]?.replace(/\D/g, ''));
        if (!nominal || nominal < 1000) {
            return bot.sendMessage(chatId, "<blockquote>⚠️ <b>FORMAT SALAH</b>\nMinimal deposit Rp 1.000\nContoh: <code>/deposit 10000</code></blockquote>", { parse_mode: 'HTML' });
        }

        const depoId = `DEP${Math.floor(1000 + Math.random() * 9000)}`;

        // Simpan sesi ke global
        global.depositSession[userId] = {
            depoId: depoId,
            nominal: nominal,
            status: 'AWAITING_PROOF',
            name: msg.from.first_name,
            username: msg.from.username || msg.from.first_name
        };

        const caption = `<blockquote>💳 <b>REQUEST DEPOSIT</b>\n\n` +
                        `🆔 ID: <b>${depoId}</b>\n` +
                        `💰 Nominal: <b>Rp ${nominal.toLocaleString('id-ID')}</b>\n\n` +
                        `📌 <b>INSTRUKSI:</b>\n` +
                        `1. Scan QRIS & Bayar sesuai nominal.\n` +
                        `2. Kirim <b>FOTO BUKTI TF</b> sekarang.\n\n` +
                        `<i>Klik batal jika ingin mengganti nominal.</i></blockquote>`;

        const keyboard = {
            inline_keyboard: [
                [{ text: "❌ BATALKAN DEPOSIT", callback_data: `cancel_depo_${userId}` }]
            ]
        };

        if (fs.existsSync(qrisPath)) {
            return bot.sendPhoto(chatId, qrisPath, { caption: caption, parse_mode: 'HTML', reply_markup: keyboard });
        } else {
            return bot.sendMessage(chatId, "❌ Foto QRIS tidak ditemukan.\n\n" + caption, { parse_mode: 'HTML', reply_markup: keyboard });
        }
    },

    // --- 3. LOGIKA MENERIMA FOTO BUKTI ---
    onPhoto: async (bot, msg, settings) => {
        const userId = msg.from.id;
        const session = global.depositSession[userId];

        if (session && session.status === 'AWAITING_PROOF') {
            const photoId = msg.photo[msg.photo.length - 1].file_id;
            const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;

            session.status = 'WAITING_CONFIRMATION';

            await bot.sendMessage(msg.chat.id, "<blockquote>✅ <b>BUKTI TERKIRIM</b>\nMohon tunggu....</blockquote>", { parse_mode: 'HTML' });

            const captionOwner = `<blockquote>🔔 <b>KONFIRMASI DEPOSIT</b>\n\n` +
                                 `🆔 ID: <b>${session.depoId}</b>\n` +
                                 `👤 User: @${session.username}\n` +
                                 `💰 Nominal: <b>Rp ${session.nominal.toLocaleString()}</b></blockquote>`;

            const keyboard = {
                inline_keyboard: [[
                    { text: "✅ ACC", callback_data: `acc_depo_${userId}` },
                    { text: "❌ TOLAK", callback_data: `rej_depo_${userId}` }
                ]]
            };

            return bot.sendPhoto(ownerId, photoId, { 
                caption: captionOwner, 
                reply_markup: keyboard, 
                parse_mode: 'HTML' 
            });
        }
    }
};