// /cases/openzip.js (VERSI FINAL: EKSTRAKSI DAN PENGIRIMAN KONTEN)

const fs = require('fs');
const path = require('path');
const yauzl = require('yauzl'); 
const { promisify } = require('util');
const stream = require('stream');

const TEMP_DIR = path.join(__dirname, '..', 'temp_zip');
const pipeline = promisify(stream.pipeline);

if (!fs.existsSync(TEMP_DIR)) {
    fs.mkdirSync(TEMP_DIR);
}

const openZipPromise = promisify(yauzl.open);

// Helper function untuk mengekstrak satu entry (file)
function extractEntry(zip, entry, extractPath) {
    return new Promise((resolve, reject) => {
        zip.openReadStream(entry, (err, readStream) => {
            if (err) return reject(err);
            
            readStream.on('end', resolve);
            readStream.on('error', reject);
            
            const writeStream = fs.createWriteStream(extractPath);
            readStream.pipe(writeStream);
        });
    });
}

// Helper untuk menghapus direktori secara rekursif
function deleteFolderRecursive(directoryPath) {
    if (fs.existsSync(directoryPath)) {
        fs.readdirSync(directoryPath).forEach((file) => {
            const curPath = path.join(directoryPath, file);
            if (fs.lstatSync(curPath).isDirectory()) { // rekursif
                deleteFolderRecursive(curPath);
            } else { // hapus file
                fs.unlinkSync(curPath);
            }
        });
        fs.rmdirSync(directoryPath);
    }
}


module.exports = {
    keyword: 'openzip',
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        if (!global.isOwner(userId)) {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya bisa digunakan oleh Owner Bot.');
        }

        const repliedMessage = msg.reply_to_message;

        if (!repliedMessage || !repliedMessage.document) {
            return bot.sendMessage(chatId, '⚠️ Gagal: Silakan reply pesan yang berisi file ZIP saat menggunakan perintah `/openzip`.', { parse_mode: 'Markdown' });
        }

        const document = repliedMessage.document;
        const fileId = document.file_id;
        const fileName = document.file_name;

        // Buat folder unik untuk hasil ekstraksi
        const extractDir = path.join(TEMP_DIR, `extracted_${Date.now()}`); 

        const processingMsg = await bot.sendMessage(chatId, 
            `⏳ Sedang memproses dan mengekstrak file **${fileName}**...`,
            { parse_mode: 'Markdown' }
        );

        let actualFilePath = null;
        let fileCount = 0;
        const MAX_FILES_TO_SEND = 20; // Batasan pengiriman untuk menghindari flood
        let sendCount = 0;
        
        try {
            // 1. Unduh File ZIP dan Dapatkan Path Asli
            actualFilePath = await bot.downloadFile(fileId, TEMP_DIR);
            
            if (!fs.existsSync(extractDir)) {
                fs.mkdirSync(extractDir);
            }

            // 2. Ekstraksi File Menggunakan yauzl
            const zip = await openZipPromise(actualFilePath, { lazyEntries: true, decodeStrings: true });
            
            await new Promise((resolve, reject) => {
                zip.on('entry', async (entry) => {
                    const entryName = entry.fileName;
                    
                    if (entryName.endsWith('/')) { // Lewati direktori
                        zip.readEntry();
                        return;
                    }

                    fileCount++;

                    // Hanya ekstrak dan kirim jika belum mencapai batas
                    if (sendCount < MAX_FILES_TO_SEND) {
                        // Hanya ambil nama file, buang path folder di dalam zip
                        const baseFileName = path.basename(entryName); 
                        const fullExtractPath = path.join(extractDir, baseFileName);

                        try {
                            // Ekstrak file
                            await extractEntry(zip, entry, fullExtractPath);
                            
                            // Kirim file yang baru diekstrak
                            await bot.sendDocument(chatId, fullExtractPath, { 
                                caption: `𝙍𝙀𝙕𝙕 𖣐 ${baseFileName}`,
                                // Balas pesan aslinya agar terurut
                                reply_to_message_id: msg.message_id 
                            });
                            sendCount++;
                        } catch (e) {
                            console.error(`Gagal ekstrak/kirim entry ${entryName}:`, e.message);
                        }
                    }
                    
                    zip.readEntry(); // Lanjutkan ke entri berikutnya
                });

                zip.on('end', resolve);
                zip.on('error', reject);
                
                zip.readEntry();
            });
            
            // 4. Kirim Konfirmasi Akhir
            let confirmationText = `✅ **Ekstraksi Selesai!** ${fileCount} file ditemukan di dalam ZIP.`;
            if (sendCount > 0) {
                 confirmationText += ` Bot berhasil mengirim ${sendCount} file ke chat ini.`;
            }
            if (fileCount > MAX_FILES_TO_SEND) {
                 confirmationText += `\n⚠️ Catatan: Hanya ${MAX_FILES_TO_SEND} file pertama yang dikirim (limit).`;
            }

            await bot.editMessageText(
                confirmationText,
                { chat_id: chatId, message_id: processingMsg.message_id, parse_mode: 'Markdown' }
            );


        } catch (error) {
            const errorText = `❌ **File zip tidak dapat di proses UBAH FILE:** ${error.message}`;
            console.error(`[OPENZIP] Error memproses ${fileName}:`, error);

            await bot.editMessageText(
                errorText,
                { chat_id: chatId, message_id: processingMsg.message_id, parse_mode: 'Markdown' }
            );

        } finally {
            // 5. Bersihkan (Hapus ZIP asli dan folder hasil ekstraksi)
            try {
                if (actualFilePath && fs.existsSync(actualFilePath)) {
                    fs.unlinkSync(actualFilePath);
                }
                if (fs.existsSync(extractDir)) {
                    deleteFolderRecursive(extractDir);
                }
            } catch (e) {
                console.error(`[OPENZIP] Gagal membersihkan file: ${e.message}`);
            }
        }
    }
};