const Pengguna = require('../lib/pengguna'); // Import Library Pengguna

module.exports = {
    keyword: 'tebak',
    keywordAliases: ['tebakangka', 'guess'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id; // Selalu pakai userId agar sinkron
        const text = msg.text ? msg.text.trim() : "";
        const args = text.split(/\s+/);

        // 1. Cek Registrasi via Library
        if (!Pengguna.isTerdaftar(userId)) {
            return bot.sendMessage(chatId, "⚠️ Kamu belum terdaftar! Ketik /daftar dulu.");
        }

        // 2. Validasi Format: /tebak [nominal] [angka 1-5]
        if (args.length < 3) {
            return bot.sendMessage(chatId, 
                `🎲 **GUESS THE NUMBER** 🎲\n\n` +
                `Cara main: \`/tebak [nominal] [angka]\`\n` +
                `Pilih angka antara: **1 sampai 5**\n\n` +
                `Contoh: \`/tebak 1000 3\``, { parse_mode: 'Markdown' });
        }

        const nominal = parseInt(args[1]);
        const tebakan = parseInt(args[2]);

        // 3. Validasi Input & Saldo
        if (isNaN(nominal) || nominal < 1000) {
            return bot.sendMessage(chatId, "✘ Minimal taruhan adalah Rp 1.000.");
        }

        if (isNaN(tebakan) || tebakan < 1 || tebakan > 5) {
            return bot.sendMessage(chatId, "✘ Tebakan harus berupa angka antara 1 sampai 5.");
        }

        const dataUser = Pengguna.ambil(userId);
        if (dataUser.saldo < nominal) {
            return bot.sendMessage(chatId, `✘ Saldo tidak cukup!\nSaldo kamu: Rp ${dataUser.saldo.toLocaleString('id-ID')}`);
        }

        // --- PROSES PERMAINAN ---
        // Potong saldo di awal via Library (Anti-Cheat)
        Pengguna.tambahSaldo(userId, -nominal);

        const waitMsg = await bot.sendMessage(chatId, `🎲 Mengocok dadu...`);
        
        // Animasi singkat
        await new Promise(r => setTimeout(r, 1200));

        // Acak angka 1 sampai 5
        const angkaBot = Math.floor(Math.random() * 5) + 1;
        
        let menang = tebakan === angkaBot;
        let pesanHasil = "";

        if (menang) {
            // Hadiah kali 2
            const reward = nominal * 2;
            Pengguna.tambahSaldo(userId, reward); // Tambah kemenangan via Library
            pesanHasil = `🎉 **MENANG TEPAT!**\n\nAngka keluar: **${angkaBot}**\nTebakanmu: **${tebakan}**\nKamu mendapatkan: **Rp ${reward.toLocaleString('id-ID')}**`;
        } else {
            pesanHasil = `💀 **ZONK / KALAH!**\n\nAngka keluar: **${angkaBot}**\nTebakanmu: **${tebakan}**\nTaruhan **Rp ${nominal.toLocaleString('id-ID')}** hangus.`;
        }

        // Ambil saldo terbaru setelah update
        const saldoAkhir = Pengguna.ambil(userId).saldo;

        const finalMsg = 
            `🎲 **HASIL TEBAK ANGKA** 🎲\n` +
            `────────────────────\n` +
            `${pesanHasil}\n` +
            `────────────────────\n` +
            `💳 **Saldo Akhir:** Rp ${saldoAkhir.toLocaleString('id-ID')}`;

        return bot.editMessageText(finalMsg, { 
            chat_id: chatId, 
            message_id: waitMsg.message_id, 
            parse_mode: 'Markdown' 
        });
    }
};