// cases/bca.js (FIXED: PERBAIKAN MARKDOWN AMAN)

module.exports = {
    keyword: '/bca',
    handler: (bot, msg, settings) => {
        const chatId = msg.chat.id;
        
        // --- GANTI DETAIL INI ---
        const detailText = `
**𝗗𝗘𝗧𝗔𝗜𝗟 🜲**
Number pay : \`7985909172\`
Name pay   : Bayu Ahmad Fahrezi 
Name E-wallet/Bank : BCA (Bank Central Asia)

➖➖➖➖➖➖➖➖➖➖➖➖
**sᴇʀᴛᴀᴋᴀɴ ʙᴜᴋᴛɪ ᴛʀᴀɴsғᴇʀ️**
        `;
        // PERHATIAN: Karakter * di Name pay dan Name E-wallet/Bank telah dihapus.
        // Format ini lebih aman dari error "can't parse entities".

        // Tombol Kembali
        const backKeyboard = {
            inline_keyboard: [
                [{ text: '◀️', callback_data: '/payment' }]
            ]
        };
        
        // Kirim Pesan BARU
        bot.sendMessage(chatId, detailText, {
            parse_mode: 'Markdown',
            reply_markup: backKeyboard
        })
        .catch(e => {
            console.error("Gagal mengirim detail BCA:", e.message);
        });
    }
};