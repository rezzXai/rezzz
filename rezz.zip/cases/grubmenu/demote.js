// cases/delpromote.js

module.exports = {
    keyword: '/demote',
    keywordAliases: ['/delpromot', '/demote'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        // 1. Cek apakah pesan berasal dari grup
        if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
            return bot.sendMessage(chatId, "❌ Perintah ini hanya bisa digunakan di dalam grup.");
        }

        // 2. Validasi Hak Akses (Hanya Owner/Admin Grup yang bisa menurunkan admin)
        const chatMember = await bot.getChatMember(chatId, userId);
        const isGroupAdmin = chatMember.status === 'administrator' || chatMember.status === 'creator';
        
        if (!isGroupAdmin) {
            return bot.sendMessage(chatId, "❌ Anda harus menjadi Admin atau Pembuat Grup untuk menggunakan perintah ini.", { reply_to_message_id: msg.message_id });
        }

        // 3. Menentukan Target Demosi (Harus Tag atau Reply)
        let targetUserId;
        let targetUsername;

        if (msg.reply_to_message) {
            // Target adalah pengguna yang di-reply
            targetUserId = msg.reply_to_message.from.id;
            targetUsername = msg.reply_to_message.from.username ? `@${msg.reply_to_message.from.username}` : `ID: ${targetUserId}`;
        } else {
            // Target adalah pengguna yang di-tag dalam pesan
            const entities = msg.entities || [];
            const mentionEntity = entities.find(e => e.type === 'mention' || e.type === 'text_mention');

            if (mentionEntity && mentionEntity.user) {
                targetUserId = mentionEntity.user.id;
                targetUsername = mentionEntity.user.username ? `@${mentionEntity.user.username}` : `ID: ${targetUserId}`;
            } else {
                return bot.sendMessage(chatId, 
                    "❌ Format salah. Mohon balas pesan pengguna yang ingin diturunkan atau tag pengguna tersebut setelah perintah.", 
                    { reply_to_message_id: msg.message_id });
            }
        }
        
        try {
            // 4. Turunkan Status Admin (Demosi)
            // Cara standar untuk menurunkan admin adalah memanggil promoteChatMember
            // dengan semua hak disetel ke false, atau menggunakan restrictChatMember
            
            // Menggunakan promoteChatMember dengan semua hak diatur ke false
            // Jika bot adalah Creator Grup, ini akan berhasil. Jika bot hanya admin,
            // bot hanya bisa menghapus hak yang diberikan oleh dirinya sendiri.
            await bot.promoteChatMember(chatId, targetUserId, {
                can_change_info: false,
                can_delete_messages: false,
                can_invite_users: false,
                can_restrict_members: false,
                can_pin_messages: false,
                can_manage_topics: false 
                // Biarkan hak lainnya default (false)
            });


            // 5. Kirim Konfirmasi
            const successMsg = `✅ **Demosi Sukses!**\n\n**${targetUsername}** sekarang kembali menjadi member biasa.`;
            bot.sendMessage(chatId, successMsg, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });

        } catch (error) {
            console.error("🔴 Error promoteChatMember (Demosi):", error.message);
            let errorMessage = `❌ Gagal menurunkan status admin ${targetUsername}. Pastikan:
- Bot adalah Admin Grup dengan hak yang cukup.
- Admin yang diturunkan bukan Creator Grup atau Admin yang diangkat oleh Creator Grup.`;
            
            bot.sendMessage(chatId, errorMessage, { reply_to_message_id: msg.message_id });
        }
    }
};