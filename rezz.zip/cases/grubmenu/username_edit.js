// cases/username_edit.js

// Import fungsi isAdmin dari global scope yang ada di rezz.js

const { isAdmin } = global;

const usernameEditHandler = async (bot, msg, settings) => {

    const chatId = msg.chat.id;

    const chatType = msg.chat.type;

    const userId = msg.from.id;

    // 1. Validasi Tipe Chat

    if (chatType === 'private') {

        return bot.sendMessage(chatId, 

            '✘ ᴘᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴅᴀᴘᴀᴛ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴅᴀʟᴀᴍ ɢʀᴜʙ.', 

            { reply_to_message_id: msg.message_id }

        );

    }

    

    // 2. Parsing Nama Baru

    // Mengambil semua teks setelah /usernameedit

    const newNameText = msg.text.split(/\s+/).slice(1).join(' ').trim();

    

    if (!newNameText) {

        return bot.sendMessage(chatId, 

            '✘ **ᴘᴇʀɪɴᴛᴀʜ sᴀʟᴀʜ!**\n\n' +

            'ɢᴜɴᴀᴋᴀɴ: `/usernameedit <Nama_Grup_Baru>`\n' +

            'Contoh: `/usernameedit public room`', 

            { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }

        );

    }

    

    // 3. Otorisasi Pengguna (Hanya Admin Grup atau Owner Bot yang Boleh)

    let userIsAdmin = false; 

    try {

        userIsAdmin = await isAdmin(bot, chatId, userId);

    } catch (e) {

        /* Gagal mendapatkan status admin */

    }

    if (!userIsAdmin && !global.isOwner(userId)) {

        return bot.sendMessage(chatId, 

            '✘ ᴋᴀᴜ sᴀᴘᴀ? ᴋᴏᴋ ᴍᴀᴋᴇ ᴠɪᴛᴜʀ ᴘᴜʟᴀᴋ ᴡᴋᴡᴋ.', 

            { reply_to_message_id: msg.message_id }

        );

    }

    

    const processingMessage = await bot.sendMessage(chatId, 

        `⏳ ᴘʀᴏsᴇs ᴘᴇɴɢᴜʙᴀʜᴀɴ **Nama Grup (Title)** ᴍᴇɴᴊᴀᴅɪ *${newNameText}*...`, 

        { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }

    );

    

    try {

        // 4. Cek Izin Bot

        const botMember = await bot.getChatMember(chatId, settings.BOT_TOKEN.split(':')[0]); 

        

        // Bot harus bisa mengubah info grup

        if (botMember.status !== 'administrator' || !botMember.can_change_info) {

             await bot.deleteMessage(chatId, processingMessage.message_id).catch(() => {});

             return bot.sendMessage(chatId, 

                '✘ **ᴀᴋsᴇs ᴛᴇʀʙᴀᴛᴀs.**\n\n' +

                'ᴊᴀᴅɪᴋᴀɴ ʙᴏᴛ sᴇʙᴀɢᴀɪ ᴀᴅᴍɪɴ ᴅᴀɴ ʙᴇʀɪᴋᴀɴ sᴇᴍᴜᴀ ɪᴢɪɴ ♀.', 

                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }

            );

        }

        // 5. Eksekusi Perubahan NAMA GRUP (setChatTitle)

        const success = await bot.setChatTitle(chatId, newNameText);

        

        await bot.deleteMessage(chatId, processingMessage.message_id).catch(() => {});

        if (success) {

            bot.sendMessage(chatId, 

                `✔ **sᴜᴄᴄᴇs**\n\n` +

                `ɴᴇᴡ ɴᴀᴍᴇ: *${newNameText}*`, 

                { parse_mode: 'Markdown' }

            );

        } 

        

    } catch (error) {

        await bot.deleteMessage(chatId, processingMessage.message_id).catch(() => {});

        console.error(`🔴 [TITLE EDIT ERROR] Gagal mengubah nama grup ${chatId}: ${error.message}`);

        

        let errorMessage = '✘ ᴀᴅᴜʜʜ ᴇʀᴏʀ ᴘᴜʟᴀᴋ ɪɴɪ. ';

        if (error.message.includes('CHAT_ADMIN_REQUIRED') || error.message.includes('rights')) {

            errorMessage += 'ʜᴅᴇʜʜʜ ʙᴇɢᴏᴏ,ᴜᴅᴀ ɴʏᴜʀᴜʜ ᴛᴀᴘɪ ɪᴢɪɴ ʙᴏᴛ ɢᴀ ᴅɪ ᴋᴀsɪ.';

        } else {

            errorMessage += 'Terjadi kesalahan tidak terduga. Cek konsol.';

        }

        

        bot.sendMessage(chatId, errorMessage, { reply_to_message_id: msg.message_id });

    }

};

module.exports = {

    keyword: ['usernameedit'],

    keywordAliases: ['/usernameedit'],

    handler: usernameEditHandler

};