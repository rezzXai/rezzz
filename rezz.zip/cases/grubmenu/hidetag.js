// =======================================================
// cases/hidetag.js (KOREKSI FINAL UNTUK KOMPATIBILITAS REZZ.JS)
// =======================================================

module.exports = {
    // Keyword yang dicari oleh rezz.js (tanpa '/')
    keyword: 'hidetag', 
    
    // Alias yang juga dikenali
    keywordAliases: ['h', 'tagall', 'mentionall', 'ht'], 
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const isPrivate = msg.chat.type === 'private';
        const MAX_TAGS = 50; 
        
        // --- Ekstraksi argumen manual ---
        const text = msg.text || '';
        const args = text.split(/\s+/).slice(1); 
        // ---------------------------------
        
        console.log(`[HIDETAG] Perintah ${msg.text} diterima dari user ${userId} di chat ${chatId}.`);

        // 1. CEK: HARUS DI GRUP
        if (isPrivate) {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya bisa digunakan di Grup atau Supergrup.');
        }

        // 2. CEK: HAK PENGGUNA (Admin Grup atau Owner Bot)
        const isOwnerUser = global.isOwner(userId);

        let userIsAdmin = false;
        
        if (!isOwnerUser) {
            try {
                // Menggunakan global.isAdmin yang sudah didefinisikan di rezz.js
                userIsAdmin = await global.isAdmin(bot, chatId, userId);
            } catch (e) { 
                console.error(`[HIDETAG] Gagal cek admin (getChatMember error): ${e.message}`);
            }
            
            // Pengecekan akhir: Jika bukan Owner DAN bukan Admin
            if (!userIsAdmin) {
                return bot.sendMessage(chatId, '❌ Anda harus menjadi **Admin Grup** atau **Owner Bot** untuk menggunakan perintah ini.', { 
                    reply_to_message_id: msg.message_id 
                });
            }
        }
        
        // ----------------------------------------------------
        // --- Ekstraksi Pesan ---
        // ----------------------------------------------------
        
        let targetText = args.join(' ').trim(); 
        
        if (!targetText && msg.reply_to_message && msg.reply_to_message.text) {
             targetText = msg.reply_to_message.text;
        } else if (!targetText) {
             targetText = "Pesan Penting!";
        }

        
        // ----------------------------------------------------
        // --- Ambil Daftar Anggota dari Global (Member DB) ---
        // ----------------------------------------------------
        
        let tags = [];
        // Mengambil Set<username> yang sudah dimuat persisten dari memberdb.js
        const trackedUsernamesSet = global.allChatMembers[chatId] || new Set();
        
        // Konversi Set menjadi Array dan filter username yang kosong
        const usernames = Array.from(trackedUsernamesSet).filter(u => u); 
        
        let tagCount = 0;
        
        for (const username of usernames) {
            if (tagCount >= MAX_TAGS) break;
            
            // Perlu dicek agar tidak men-tag diri sendiri (username yang mengirim command)
            if (username.toLowerCase() !== (msg.from.username ? msg.from.username.toLowerCase() : null)) { 
                tags.push(`@${username}`); 
                tagCount++;
            }
        }
        
        let memberCount = tags.length;
        
        if (memberCount === 0) {
            return bot.sendMessage(chatId, '⚠️ Tidak ada anggota grup yang tercatat memiliki *username* yang valid dan berinteraksi. Tag All dibatalkan.');
        }

        // ----------------------------------------------------
        // --- Kirim Pesan Akhir ---
        // ----------------------------------------------------
        
        let tagList = tags.join(' '); 
        
        const finalMessage = `
📢 **Pesan dari Admin:** ${targetText}
        
*Total Member Ter-Tag:* ${memberCount}
        
${tagList}
        `.trim();

        // Hapus pesan perintah /h
        try {
            await bot.deleteMessage(chatId, msg.message_id);
        } catch (e) { 
            console.warn(`[HIDETAG] Gagal menghapus pesan: ${e.message}`); 
        }
        
        // Kirim pesan dengan Markdown dan disable notifikasi
        await bot.sendMessage(chatId, finalMessage, { 
            parse_mode: 'Markdown' ,
            disable_notification: true
        })
            .catch(async error => {
                console.error(`[HIDETAG] Gagal mengirim pesan akhir: ${error.message}`);
                await bot.sendMessage(chatId, `❌ Gagal mengirim pesan Tag All. Error: ${error.message}`);
            });
    }
};