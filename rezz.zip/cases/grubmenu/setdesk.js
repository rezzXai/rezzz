// /cases/setdesk.js (Mengatur dan Menghapus Deskripsi Grup)

module.exports = {
    keyword: 'setdesk',
    keywordAliases: ['/setdesk', '/deldesk'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const msgText = msg.text.trim();
        const command = msgText.split(' ')[0]; // Ambil /setdesk atau /deldesk
        
        // --- 1. Validasi Admin Telegram ---
        // Pengecekan apakah pengguna yang menjalankan perintah adalah administrator
        const chatMember = await bot.getChatMember(chatId, msg.from.id);
        if (chatMember.status !== 'creator' && chatMember.status !== 'administrator') {
             return bot.sendMessage(chatId, "❌ Anda harus menjadi **Admin Grup** untuk menggunakan perintah ini.", { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        let newDescription = null;
        let successMessage = '';
        
        // --- 2. Logika Berdasarkan Perintah ---
        
        if (command === '/setdesk') {
            newDescription = msgText.slice(command.length).trim();
            
            if (newDescription.length === 0) {
                 return bot.sendMessage(chatId, "❌ **Format Salah.** Gunakan format:\n" +
                    "`/setdesk [teks deskripsi baru]`",
                    { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }
            successMessage = `✅ Deskripsi grup berhasil diatur ke:\n\n*${newDescription}*`;
            
        } else if (command === '/deldesk') {
            // Deskripsi diatur menjadi string kosong untuk menghapus/mengosongkan deskripsi
            newDescription = ''; 
            successMessage = "✅ Deskripsi grup berhasil **dikosongkan** (dihapus).";
        }

        // --- 3. Pengecekan Target Chat ---
        // Pastikan perintah dijalankan di dalam Grup, bukan chat pribadi
        if (chatId > 0) {
            return bot.sendMessage(chatId, "❌ Perintah ini hanya dapat digunakan di **dalam Grup**.", { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }


        // --- 4. Mengubah Deskripsi Grup ---
        try {
            await bot.setChatDescription(chatId, newDescription);
            
            await bot.sendMessage(chatId, successMessage, { 
                parse_mode: 'Markdown', 
                reply_to_message_id: msg.message_id 
            });

        } catch (error) {
            console.error(`Gagal mengubah deskripsi grup ${chatId}: ${error.message}`);
            
            let errorMessage = "Terjadi kesalahan saat mencoba mengubah deskripsi.";
            if (error.message.includes('not enough rights')) {
                errorMessage = "Bot **bukan Admin** atau **tidak memiliki izin 'Change Group Info'**. Harap berikan izin tersebut!";
            } else if (error.message.includes('description is too long')) {
                 errorMessage = "Deskripsi yang Anda masukkan terlalu panjang. Maksimal 255 karakter.";
            }

            await bot.sendMessage(chatId, `❌ Gagal mengubah deskripsi grup.\nDetail: ${errorMessage}`, {
                parse_mode: 'Markdown',
                reply_to_message_id: msg.message_id
            });
        }
    }
};