// cases/grub_control.js (Handler untuk Membuka dan Menutup Grup)

// Definisi izin untuk mode 'Open' dan 'Close'
const PERMISSIONS_OPEN = {
    can_send_messages: true,        // Semua bisa mengirim pesan
    can_send_audios: true,
    can_send_documents: true,
    can_send_photos: true,
    can_send_videos: true,
    can_send_video_notes: true,
    can_send_voice_notes: true,
    can_send_polls: true,
    can_send_other_messages: true,
    can_add_web_page_previews: true,
    can_change_info: false,
    can_invite_users: false,
    can_pin_messages: false,
    can_manage_topics: false
};

const PERMISSIONS_CLOSE = {
    can_send_messages: false,       // HANYA Admin yang bisa mengirim pesan
    can_send_audios: false,
    can_send_documents: false,
    can_send_photos: false,
    can_send_videos: false,
    can_send_video_notes: false,
    can_send_voice_notes: false,
    can_send_polls: false,
    can_send_other_messages: false,
    can_add_web_page_previews: false,
    can_change_info: false,
    can_invite_users: false,
    can_pin_messages: false,
    can_manage_topics: false
};


module.exports = {
    keyword: '/grub',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const senderId = msg.from.id;
        
        // Ambil argumen setelah /grub (misal: 'open' atau 'close')
        const args = msg.text.split(' ').slice(1);
        const command = args[0] ? args[0].toLowerCase() : '';

        // --- 1. Pengecekan Izin Pengguna (Admin/Owner) ---
        const ownerIds = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.map(Number) 
            : [Number(settings.OWNER_ID)].filter(id => !isNaN(id));
        const isOwner = ownerIds.includes(senderId);
        
        let isAdmin = false;
        try {
            const chatMember = await bot.getChatMember(chatId, senderId);
            if (['administrator', 'creator'].includes(chatMember.status)) {
                isAdmin = true;
            }
        } catch (e) {
            console.error("Gagal memeriksa izin admin:", e.message);
        }

        if (!isOwner && !isAdmin) {
            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
            return bot.sendMessage(chatId, 
                '❌ **Akses Ditolak.**\n\nPerintah `/grub` hanya dapat digunakan oleh **Owner Bot** atau **Admin Grup**.', 
                { parse_mode: 'Markdown' });
        }
        
        // --- 2. Pengecekan Izin Bot (Penting!) ---
        // Bot harus memiliki hak 'Restrict Members' untuk bisa menggunakan setChatPermissions.
        let botCanRestrict = false;
        try {
            const botMember = await bot.getChatMember(chatId, settings.BOT_TOKEN.split(':')[0]);
            if (botMember.can_restrict_members) {
                botCanRestrict = true;
            }
        } catch (e) {
            console.error("Gagal memeriksa izin batasi bot:", e.message);
        }

        if (!botCanRestrict) {
            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
            return bot.sendMessage(chatId, 
                '⚠️ **Izin Kurang:** Bot tidak memiliki hak **Restrict Members** di grup ini. Harap berikan izin.', 
                { parse_mode: 'Markdown' });
        }


        let newPermissions = null;
        let statusMessage = '';

        if (command === 'open') {
            newPermissions = PERMISSIONS_OPEN;
            statusMessage = '🟢 **GRUP DIBUKA!**\n\nSemua member kini dapat mengirim pesan.';
        } else if (command === 'close') {
            newPermissions = PERMISSIONS_CLOSE;
            statusMessage = '🔴 **GRUP DITUTUP!**\n\nHanya Admin yang dapat mengirim pesan.';
        } else {
            // Jika argumen salah
            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
            return bot.sendMessage(chatId, 
                '❓ **Format Salah.** Gunakan:\n• `/grub open` (untuk membuka grup)\n• `/grub close` (untuk menutup grup)', 
                { parse_mode: 'Markdown' });
        }

        // --- 3. Eksekusi Perubahan Izin ---
        try {
            await bot.setChatPermissions(chatId, newPermissions);

            // Hapus perintah Admin/Owner
            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});

            // Kirim pesan status
            await bot.sendMessage(chatId, statusMessage, { 
                parse_mode: 'Markdown' 
            });

        } catch (error) {
            console.error(`Gagal mengubah izin grup (${command}): ${error.message}`);
            bot.sendMessage(chatId, 
                `❌ **Gagal:** Terjadi kesalahan saat mencoba mengubah izin grup. (${error.message})`,
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};