// cases/antivideo.js
const settings = require('../../setting'); 

// --- Helper: Cek Status Admin ---
async function isAdmin(bot, chatId, userId) {
    try {
        const member = await bot.getChatMember(chatId, userId);
        return member.status === 'administrator' || member.status === 'creator';
    } catch (e) {
        return false;
    }
}

// --- Helper: Cek Otoritas Owner ---
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};


module.exports = {
    keyword: '/antivideo',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const args = msg.text.split(/\s+/).slice(1); 
        const command = args[0] ? args[0].toLowerCase() : null;

        // Pastikan ini dijalankan di grup
        if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya dapat digunakan di dalam Grup.', { reply_to_message_id: msg.message_id });
        }
        
        // 1. Cek izin: Admin atau Owner
        const isOwnerUser = isOwner(userId, settings);
        const userIsAdmin = await isAdmin(bot, chatId, userId);

        if (!isOwnerUser && !userIsAdmin) {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya bisa digunakan oleh Admin Grup atau Owner Bot.', { reply_to_message_id: msg.message_id });
        }
        
        // 2. Tangani perintah 'on' atau 'off'
        if (command === 'on') {
            global.antivideoStatus[chatId] = true; // Set status global anti-video ke true
            return bot.sendMessage(chatId, '✅ **Anti Video Diaktifkan!**\nSekarang hanya Admin Grup dan Owner Bot yang diizinkan mengirim video.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else if (command === 'off') {
            global.antivideoStatus[chatId] = false; // Set status global anti-video ke false
            return bot.sendMessage(chatId, '❌ **Anti Video Dinonaktifkan.**\nSemua member kini bisa mengirim video.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else {
            const currentStatus = global.antivideoStatus[chatId] ? 'AKTIF' : 'NONAKTIF';
            return bot.sendMessage(chatId, 
                `🛡️ **Status Anti Video:** ${currentStatus}\n\n` +
                `**Penggunaan:**\n` +
                `• \`/antivideo on\` - Aktifkan (Hanya Admin/Owner yang boleh kirim video).\n` +
                `• \`/antivideo off\` - Nonaktifkan (Semua member boleh kirim video).`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
            );
        }
    }
};