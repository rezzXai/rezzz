// cases/antispam.js (FINAL FIX: OWNER MUTLAK, HTML & LOGIKA ANTI-SPAM COMMAND)

const settings = require('../../setting');

// Helper function untuk memeriksa apakah pengguna adalah owner bot (Pengecekan Mutlak)
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};

module.exports = {
    keyword: '/antispam',
    keywordAliases: ['/as'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const chatType = msg.chat.type;
        const text = msg.text ? msg.text.trim() : '';
        const parts = text.split(' ');
        
        if (chatType === 'private') {
            return bot.sendMessage(chatId, '❌ <b>Kesalahan:</b> Perintah ini hanya dapat digunakan di dalam grup.', { parse_mode: 'HTML' });
        }

        const isOwnerBot = isOwner(userId, settings);
        let isAdminFlag = false; 

        try {
            const member = await bot.getChatMember(chatId, userId);
            isAdminFlag = member.status === 'creator' || member.status === 'administrator';
        } catch (e) { /* error */ }

        if (!isOwnerBot && !isAdminFlag) {
            return bot.sendMessage(chatId, '❌ <b>Akses Ditolak:</b> Perintah ini hanya bisa digunakan oleh Admin Grup atau Owner Bot.', { parse_mode: 'HTML' });
        }
        
        const command = parts[1] ? parts[1].toLowerCase() : null;

        if (command === 'on' || command === 'off') {
            const status = command === 'on';
            global.antispamStatus[chatId] = status;

            const statusText = status ? 'AKTIF' : 'NONAKTIF';
            const statusEmoji = status ? '✅' : '❌';

            let reply = `${statusEmoji} <b>Anti-Spam Berhasil Ditetapkan</b>\n`;
            reply += `Status Grup saat ini: <b>${statusText}</b>.\n`;
            reply += status ? '<i>Semua command tak dikenal akan dihapus.</i>' : '<i>Fitur Anti-Spam dinonaktifkan.</i>';
            
            return bot.sendMessage(chatId, reply, { parse_mode: 'HTML' });
        } else {
            const currentStatus = global.antispamStatus[chatId] ? 'AKTIF' : 'NONAKTIF';
            let reply = `ℹ️ <b>Status Anti-Spam</b>\n`;
            reply += `Status saat ini: <b>${currentStatus}</b>.\n`;
            reply += `Gunakan: <code>/antispam on</code> atau <code>/antispam off</code> untuk mengubah status.`;

            return bot.sendMessage(chatId, reply, { parse_mode: 'HTML' });
        }
    },
    
    textHandler: async (bot, msg, settings, allHandlers) => {
        const chatId = msg.chat.id;
        const msgText = msg.text ? msg.text.toLowerCase() : '';
        const currentStatus = global.antispamStatus[chatId] || false; 
        
        if (!currentStatus) return; 

        if (!msgText.startsWith('/')) return; 
        
        const validKeywords = allHandlers
            .flatMap(handler => [handler.keyword, ...(handler.keywordAliases || [])])
            .filter(k => k); 

        const command = msgText.split(' ')[0].split('@')[0];

        if (validKeywords.includes(command)) return; 
        
        try {
            await bot.deleteMessage(chatId, msg.message_id);
        } catch (e) { /* error */ }
    }
};