// cases/welcome.js (HANDLER UNTUK /WELCOME, /SETWELCOME, /SETOUT)
const settings = require('../../setting'); 

// --- Helper: Cek Otoritas Owner ---
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};

// --- Helper: Cek Status Admin ---
async function isAdmin(bot, chatId, userId) {
    try {
        const member = await bot.getChatMember(chatId, userId);
        return member.status === 'administrator' || member.status === 'creator';
    } catch (e) {
        return false;
    }
}

module.exports = {
    keyword: '/welcome',
    keywordAliases: ['/setwelcome', '/setout'], 
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const fullCommand = msg.text.trim();
        const parts = fullCommand.split(/\s+/);
        const command = parts[0].toLowerCase(); // /welcome, /setwelcome, atau /setout
        const argument = parts[1] ? parts[1].toLowerCase() : null; // on/off atau teks

        // Pastikan dijalankan di grup
        if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya dapat digunakan di dalam Grup.', { reply_to_message_id: msg.message_id });
        }
        
        // 1. Cek izin: Admin atau Owner untuk SEMUA perintah ini
        const isOwnerUser = isOwner(userId, settings);
        const userIsAdmin = await isAdmin(bot, chatId, userId);

        if (!isOwnerUser && !userIsAdmin) {
            return bot.sendMessage(chatId, '❌ Perintah ini (Welcome System) hanya bisa diatur oleh Admin Grup atau Owner Bot.', { reply_to_message_id: msg.message_id });
        }

        // ===========================================
        // === LOGIKA PERINTAH UTAMA (/WELCOME) ===
        // ===========================================
        if (command === '/welcome') {
            if (argument === 'on') {
                global.welcomeStatus[chatId] = true;
                return bot.sendMessage(chatId, '✅ **Welcome System Diaktifkan!**\nSekarang bot akan merespons member masuk/keluar menggunakan pesan yang telah diset (atau pesan default).', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            } else if (argument === 'off') {
                global.welcomeStatus[chatId] = false;
                return bot.sendMessage(chatId, '❌ **Welcome System Dinonaktifkan.**', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            } else {
                const status = global.welcomeStatus[chatId] ? 'AKTIF' : 'NONAKTIF';
                return bot.sendMessage(chatId, 
                    `🛡️ **Status Welcome System:** ${status}\n\n` +
                    `**Penggunaan:**\n` +
                    `• \`/welcome on/off\` - Aktifkan/Nonaktifkan sistem.\n` +
                    `• \`/setwelcome (teks)\` - Atur pesan selamat datang.\n` +
                    `• \`/setout (teks)\` - Atur pesan selamat jalan.`,
                    { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
                );
            }
        }
        
        // ===========================================
        // === LOGIKA SET PESAN (/SETWELCOME) ===
        // ===========================================
        if (command === '/setwelcome') {
            const welcomeText = fullCommand.substring(command.length).trim();
            if (!welcomeText) {
                return bot.sendMessage(chatId, 'Silakan masukkan teks selamat datang.\n**Placeholder:** `{name}` (member baru), `{group}` (nama grup).', { reply_to_message_id: msg.message_id });
            }
            
            global.welcomeText[chatId] = welcomeText;
            return bot.sendMessage(chatId, `🎉 **Pesan Selamat Datang berhasil diatur!**\n\n**Teks:** \n\`${welcomeText}\``, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        // ===========================================
        // === LOGIKA SET PESAN (/SETOUT) ===
        // ===========================================
        if (command === '/setout') {
            const outText = fullCommand.substring(command.length).trim();
            if (!outText) {
                return bot.sendMessage(chatId, 'Silakan masukkan teks selamat jalan.\n**Placeholder:** `{name}` (member keluar), `{group}` (nama grup).', { reply_to_message_id: msg.message_id });
            }
            
            global.outText[chatId] = outText;
            return bot.sendMessage(chatId, `🚪 **Pesan Selamat Jalan berhasil diatur!**\n\n**Teks:** \n\`${outText}\``, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};