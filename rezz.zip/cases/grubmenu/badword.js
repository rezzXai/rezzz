// cases/badword.js (HANDLER UNTUK /BADWORD, /ADDBADWORD, /DELBADWORD, /LISTBADWORD)
const settings = require('../../setting'); 

// --- Helper: Cek Otoritas Owner ---
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};

// --- Helper: Cek Status Admin ---
async function isAdmin(bot, chatId, userId) {
    try {
        const member = await bot.getChatMember(chatId, userId);
        return member.status === 'administrator' || member.status === 'creator';
    } catch (e) {
        return false;
    }
}

module.exports = {
    keyword: '/badword',
    keywordAliases: ['/addbadword', '/delbadword', '/listbadword'], // <--- /listbadword DITAMBAHKAN DI SINI
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const fullCommand = msg.text.trim();
        const parts = fullCommand.split(/\s+/);
        const command = parts[0].toLowerCase(); 
        const args = parts.slice(1);

        // Pastikan dijalankan di grup
        if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya dapat digunakan di dalam Grup.', { reply_to_message_id: msg.message_id });
        }
        
        // 1. Cek izin: Admin atau Owner untuk SEMUA perintah ini
        const isOwnerUser = isOwner(userId, settings);
        const userIsAdmin = await isAdmin(bot, chatId, userId);

        // Otorisasi
        if (!isOwnerUser && !userIsAdmin) {
            return bot.sendMessage(chatId, '❌ Perintah ini (Anti Badword System) hanya bisa diatur oleh Admin Grup atau Owner Bot.', { reply_to_message_id: msg.message_id });
        }

        // Pastikan Set untuk badword sudah ada di grup ini
        if (!global.badwordsList[chatId]) {
            global.badwordsList[chatId] = new Set();
        }
        let currentBadwords = global.badwordsList[chatId];


        // ===========================================
        // === LOGIKA PERINTAH UTAMA (/BADWORD) ===
        // ===========================================
        if (command === '/badword') {
            const argument = args[0] ? args[0].toLowerCase() : null;
            
            if (argument === 'on') {
                global.badwordStatus[chatId] = true;
                return bot.sendMessage(chatId, '✅ **Anti Badword Diaktifkan!**\nSemua pesan yang mengandung kata terlarang akan dihapus.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            } else if (argument === 'off') {
                global.badwordStatus[chatId] = false;
                return bot.sendMessage(chatId, '❌ **Anti Badword Dinonaktifkan.**', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            } else {
                const status = global.badwordStatus[chatId] ? 'AKTIF' : 'NONAKTIF';
                const count = currentBadwords.size;
                return bot.sendMessage(chatId, 
                    `🛡️ **Status Anti Badword:** ${status}\n` +
                    `📝 **Jumlah Kata Terlarang:** ${count} kata.\n\n` +
                    `**Penggunaan:**\n` +
                    `• \`/badword on/off\` - Aktifkan/Nonaktifkan sistem.\n` +
                    `• \`/addbadword (kata1 kata2...)\` - Tambah kata terlarang.\n` +
                    `• \`/delbadword (kata1 kata2...)\` - Hapus kata terlarang.\n` +
                    `• \`/listbadword\` - Lihat daftar kata terlarang.`, // <--- PANDUAN BARU
                    { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
                );
            }
        }
        
        // ===========================================
        // === LOGIKA TAMBAH KATA (/ADDBADWORD) ===
        // ===========================================
        if (command === '/addbadword') {
            if (!global.badwordStatus[chatId]) {
                 return bot.sendMessage(chatId, '⚠️ **Gagal.** Fitur Anti Badword harus diaktifkan terlebih dahulu dengan `/badword on`.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }
            if (args.length === 0) {
                return bot.sendMessage(chatId, 'Silakan masukkan kata-kata yang ingin ditambahkan (dipisahkan spasi).\nContoh: `/addbadword ayam kacung bebek`', { reply_to_message_id: msg.message_id });
            }
            
            let addedCount = 0;
            args.forEach(word => {
                const cleanWord = word.toLowerCase().trim();
                if (cleanWord && !currentBadwords.has(cleanWord)) {
                    currentBadwords.add(cleanWord);
                    addedCount++;
                }
            });

            if (addedCount > 0) {
                return bot.sendMessage(chatId, `✅ **Berhasil!** ${addedCount} kata telah ditambahkan ke daftar terlarang.`, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            } else {
                return bot.sendMessage(chatId, '⚠️ Semua kata yang Anda masukkan sudah ada di daftar terlarang.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }
        }

        // ===========================================
        // === LOGIKA HAPUS KATA (/DELBADWORD) ===
        // ===========================================
        if (command === '/delbadword') {
            if (!global.badwordStatus[chatId]) {
                 return bot.sendMessage(chatId, '⚠️ **Gagal.** Fitur Anti Badword harus diaktifkan terlebih dahulu dengan `/badword on`.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }
            if (args.length === 0) {
                return bot.sendMessage(chatId, 'Silakan masukkan kata-kata yang ingin dihapus (dipisahkan spasi).\nContoh: `/delbadword ayam bebek`', { reply_to_message_id: msg.message_id });
            }
            
            let deletedCount = 0;
            args.forEach(word => {
                const cleanWord = word.toLowerCase().trim();
                if (currentBadwords.has(cleanWord)) {
                    currentBadwords.delete(cleanWord);
                    deletedCount++;
                }
            });

            if (deletedCount > 0) {
                return bot.sendMessage(chatId, `❌ **Berhasil!** ${deletedCount} kata telah dihapus dari daftar terlarang.`, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            } else {
                return bot.sendMessage(chatId, '⚠️ Semua kata yang Anda masukkan tidak ditemukan di daftar terlarang.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }
        }

        // ===========================================
        // === LOGIKA LIST KATA (/LISTBADWORD) === <--- BARU
        // ===========================================
        if (command === '/listbadword') {
            
            const wordsArray = Array.from(currentBadwords).sort(); // Ubah Set ke Array lalu urutkan
            
            if (wordsArray.length === 0) {
                return bot.sendMessage(chatId, '📜 **Daftar Kata Terlarang (Badword):**\n\n_Saat ini belum ada kata terlarang yang disetel._\n\nGunakan `/addbadword` untuk menambahkan kata.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
            }
            
            // Format daftar kata: 1. kata1, 2. kata2, ...
            const wordList = wordsArray.map((word, index) => `${index + 1}. \`${word}\``).join('\n');
            
            let response = `📜 **Daftar ${wordsArray.length} Kata Terlarang di Grup:**\n\n${wordList}`;
            
            // Batasi panjang pesan jika terlalu panjang (Telegram memiliki batas 4096 karakter)
            if (response.length > 4000) {
                response = `📜 **Daftar ${wordsArray.length} Kata Terlarang di Grup:**\n\n${wordsArray.slice(0, 50).map((word, index) => `${index + 1}. \`${word}\``).join('\n')}\n\n... dan ${wordsArray.length - 50} kata lainnya.`;
            }

            return bot.sendMessage(chatId, response, { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};