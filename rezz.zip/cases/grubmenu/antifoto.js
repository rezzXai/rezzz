// cases/antifoto.js
const settings = require('../../setting'); 

// --- Helper: Cek Status Admin (Diperlukan di sini jika logic utamanya di rezz.js belum memadai) ---
async function isAdmin(bot, chatId, userId) {
    try {
        const member = await bot.getChatMember(chatId, userId);
        return member.status === 'administrator' || member.status === 'creator';
    } catch (e) {
        // Jika bot gagal mengambil status member (misalnya, bot bukan admin)
        return false;
    }
}

// --- Helper: Cek Otoritas Owner ---
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};


module.exports = {
    keyword: '/antifoto',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const args = msg.text.split(/\s+/).slice(1); 
        const command = args[0] ? args[0].toLowerCase() : null;

        // Pastikan ini dijalankan di grup
        if (msg.chat.type !== 'group' && msg.chat.type !== 'supergroup') {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya dapat digunakan di dalam Grup.', { reply_to_message_id: msg.message_id });
        }
        
        // 1. Cek izin: Admin atau Owner
        const isOwnerUser = isOwner(userId, settings);
        const userIsAdmin = await isAdmin(bot, chatId, userId);

        if (!isOwnerUser && !userIsAdmin) {
            return bot.sendMessage(chatId, '❌ Perintah ini hanya bisa digunakan oleh Admin Grup atau Owner Bot.', { reply_to_message_id: msg.message_id });
        }
        
        // 2. Tangani perintah 'on' atau 'off'
        if (command === 'on') {
            global.antifotoStatus[chatId] = true; // Set status global ke true
            return bot.sendMessage(chatId, '✅ **Anti Foto/Gambar Diaktifkan!**\nSekarang hanya Admin Grup dan Owner Bot yang diizinkan mengirim media.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else if (command === 'off') {
            global.antifotoStatus[chatId] = false; // Set status global ke false
            return bot.sendMessage(chatId, '❌ **Anti Foto/Gambar Dinonaktifkan.**\nSemua member kini bisa mengirim media.', { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        } else {
            const currentStatus = global.antifotoStatus[chatId] ? 'AKTIF' : 'NONAKTIF';
            return bot.sendMessage(chatId, 
                `🛡️ **Status Anti Foto:** ${currentStatus}\n\n` +
                `**Penggunaan:**\n` +
                `• \`/antifoto on\` - Aktifkan (Hanya Admin/Owner yang boleh kirim foto).\n` +
                `• \`/antifoto off\` - Nonaktifkan (Semua member boleh kirim foto).`, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id }
            );
        }
    }
};