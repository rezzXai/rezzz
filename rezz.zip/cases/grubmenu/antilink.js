// cases/antilink.js (FINAL FIX: OWNER MUTLAK, HTML & LOGIKA DETEKSI LINK)

const settings = require('../../setting');

// Helper function untuk memeriksa apakah pengguna adalah owner bot (Pengecekan Mutlak)
const isOwner = (userId, settings) => {
    const ownerIdClean = parseInt(String(settings.OWNER_ID));
    const userIdClean = parseInt(String(userId));
    return userIdClean === ownerIdClean; 
};

module.exports = {
    keyword: '/antilink',
    keywordAliases: ['/al'], 
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const chatType = msg.chat.type;
        const text = msg.text ? msg.text.trim() : '';
        const parts = text.split(' ');
        
        if (chatType === 'private') {
            return bot.sendMessage(chatId, '❌ <b>Kesalahan:</b> Perintah ini hanya dapat digunakan di dalam grup.', { parse_mode: 'HTML' });
        }

        const isOwnerBot = isOwner(userId, settings);
        let isAdmin = false;

        try {
            const member = await bot.getChatMember(chatId, userId);
            isAdmin = member.status === 'creator' || member.status === 'administrator';
        } catch (e) { /* error */ }

        if (!isOwnerBot && !isAdmin) {
            return bot.sendMessage(chatId, '❌ <b>Akses Ditolak:</b> Perintah ini hanya bisa digunakan oleh Admin Grup atau Owner Bot.', { parse_mode: 'HTML' });
        }

        const command = parts[1] ? parts[1].toLowerCase() : null;

        if (command === 'on' || command === 'off') {
            const status = command === 'on';
            global.antilinkStatus[chatId] = status;

            const statusText = status ? 'AKTIF' : 'NONAKTIF';
            const statusEmoji = status ? '✅' : '❌';

            let reply = `${statusEmoji} <b>Anti-Link Berhasil Ditetapkan</b>\n`;
            reply += `Status Grup saat ini: <b>${statusText}</b>.\n`;
            reply += status ? '<i>Link dari member akan dihapus otomatis.</i>' : '<i>Member diizinkan mengirim link.</i>';
            
            return bot.sendMessage(chatId, reply, { parse_mode: 'HTML' });
        } else {
            const currentStatus = global.antilinkStatus[chatId] ? 'AKTIF' : 'NONAKTIF';
            let reply = `ℹ️ <b>Status Anti-Link</b>\n`;
            reply += `Status saat ini: <b>${currentStatus}</b>.\n`;
            reply += `Gunakan: <code>/antilink on</code> atau <code>/antilink off</code> untuk mengubah status.`;

            return bot.sendMessage(chatId, reply, { parse_mode: 'HTML' });
        }
    },
    
    textHandler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const msgText = msg.text ? msg.text.toLowerCase() : '';
        const msgId = msg.message_id;
        const userId = msg.from.id;

        const currentStatus = global.antilinkStatus[chatId] || false; 
        if (!currentStatus) return; 

        const isOwnerBot = isOwner(userId, settings);
        let isAdmin = false;
        try {
            const member = await bot.getChatMember(chatId, userId);
            isAdmin = member.status === 'creator' || member.status === 'administrator';
        } catch (e) { /* Abaikan error */ }
        
        if (isOwnerBot || isAdmin) return; 

        const linkRegex = /(http(s)?:\/\/.)?(www\.)?[-a-zA-Z0-9@:%._\+~#=]{2,256}\.[a-z]{2,6}\b([-a-zA-Z0-9@:%_\+.~#?&//=]*)|t\.me\/(joinchat|invite)\/[a-zA-Z0-9_-]+/g;

        if (linkRegex.test(msgText)) {
            try {
                await bot.deleteMessage(chatId, msgId);
                await bot.sendMessage(chatId, 
                    `🚫 <b>[Anti-Link]</b> Pesan dari ${msg.from.first_name} telah dihapus karena mengandung link!`, 
                    { parse_mode: 'HTML' }
                );
            } catch (e) { /* error */ }
        }
    }
};