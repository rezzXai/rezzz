const ms = require('ms');

const { addSewa, getSewa, removeSewa, loadSewa } = require('../../lib/sewadb');

module.exports = {

    keyword: 'sewa', 

    keywordAliases: ['addsewa', 'ceksewa', 'delsewa'],

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        const text = msg.text || "";

        const args = text.split(' ');

        const command = args[0].toLowerCase().replace('/', '');

        // 1. Validasi Owner

        if (!global.isOwner(userId)) return;

        // 2. Validasi Private Chat

        if (msg.chat.type !== 'private') {

            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});

            return bot.sendMessage(userId, "✘ ʜᴀɴʏᴀ ᴏᴡɴᴇʀ ʏᴀɴɢ ᴅᴀᴘᴀᴛ ᴍᴇɴɢɢᴜɴᴀᴋᴀɴ ᴘᴇʀɪɴᴛᴀʜ.");

        }

        // Fungsi Helper untuk format waktu WIB

        const formatWIB = (timestamp) => {

            return new Date(timestamp).toLocaleString('id-ID', {

                timeZone: 'Asia/Jakarta',

                dateStyle: 'full',

                timeStyle: 'medium'

            }) + ' WIB';

        };

        // --- COMMAND: ADD SEWA ---

        if (command === 'addsewa') {

            if (args.length < 3) {

                return bot.sendMessage(chatId, "✘ ** **𝙂𝙄𝙉𝙄: `/addsewa [ID_GRUP] [DURASI]`\nᴄᴏɴᴛᴏʜ: `/addsewa -1001234567 30d`", { parse_mode: 'Markdown' });

            }

            const targetId = args[1];

            const durationMs = ms(args[2]);

            if (!durationMs) return bot.sendMessage(chatId, "✘ ғᴏʀᴍᴀᴛ ᴅᴜʀᴀsɪ ɪs ɴᴏᴛ ᴠᴀʟɪᴅ!! ɢᴜɴᴀᴋᴀɴ s, m, h, atau d.");

            const expiredAt = addSewa(targetId, durationMs);

            return bot.sendMessage(chatId, `✅ **Sewa Berhasil Didaftarkan!**\n\n🆔 **ID Grup:** \`${targetId}\`\n📅 **Berakhir pada:**\n\`${formatWIB(expiredAt)}\``, { parse_mode: 'Markdown' });

        }

        // --- COMMAND: CEK SEWA ---

        if (command === 'ceksewa') {

            if (args.length < 2) return bot.sendMessage(chatId, "✘ ɢᴜɴᴀᴋᴀɴ: /ceksewa [IDGRUP]");

            

            const targetId = args[1];

            const data = getSewa(targetId);

            if (!data) return bot.sendMessage(chatId, "✘ ɪᴅ ɢʀᴜʙ ᴛɪᴅᴀᴋ ᴛᴇʀsᴇᴅɪᴀ ᴅɪ ᴅᴀᴛᴀʙᴀsᴇ.");

            const sisaMs = data.expired - Date.now();

            return bot.sendMessage(chatId, `📊 **Informasi Masa Sewa**\n\n🆔 **ID Grup:** \`${targetId}\`\n📅 **Expired:** \`${formatWIB(data.expired)}\`\n⏳ **Sisa:** ${sisaMs > 0 ? ms(sisaMs, { long: true }) : 'Sudah Habis'}`, { parse_mode: 'Markdown' });

        }

        // --- COMMAND: DEL SEWA ---

        if (command === 'delsewa') {

            if (args.length < 2) return bot.sendMessage(chatId, "✘ ɢᴜɴᴀᴋᴀɴ: /delsewa [IDGRUP]");

            const targetId = args[1];

            removeSewa(targetId);

            return bot.sendMessage(chatId, ` sᴜᴄᴄᴇs\nᴍᴀsᴀ sᴇᴡᴀ \`${targetId}\` ᴅɪ ʜᴀᴘᴜs☑︎.`);

        }

    }

};