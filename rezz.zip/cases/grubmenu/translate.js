const axios = require('axios');

module.exports = {

    keyword: 'tr',

    keywordAliases: ['translate', 'terjemah'],

    

    handler: async (bot, msg) => {

        const chatId = msg.chat.id;

        const args = msg.text.trim().split(/\s+/).slice(1);

        // Jika tidak ada argumen, kirim panduan lengkap

        if (args.length < 2) {

            let helpMsg = ` 𝙋𝘼𝙉𝘿𝙐𝘼𝙉\n\n`;

            helpMsg += `Format: /tr [kode_bahasa] [teks]\n\n`;

            helpMsg += `📌 𝘾𝙤𝙣𝙩𝙤𝙝:\n`;

            helpMsg += `/tr en Halo apa kabar\n\n`;

            helpMsg += `🔠 ＫＯＤＥ ＢＡＨＡＳＡ:\n`;

            helpMsg += `<code>id</code> - Indonesia\n`;

            helpMsg += `<code>en</code> - Inggris\n`;

            helpMsg += `<code>ja</code> - Jepang\n`;

            helpMsg += `<code>ko</code> - Korea\n`;

            helpMsg += `<code>ar</code> - Arab\n`;

            helpMsg += `<code>jv</code> - Jawa\n`;

            helpMsg += `<code>su</code> - Sunda\n`;

            helpMsg += `<code>zh</code> - Mandarin\n\n`;

            helpMsg += `Ketik kode di atas setelah perintah /tr`;

            return bot.sendMessage(chatId, helpMsg, { parse_mode: 'HTML' });

        }

        const lang = args[0].toLowerCase();

        const text = args.slice(1).join(" ");

        try {

            const response = await axios.get(`https://translate.googleapis.com/translate_a/single?client=gtx&sl=auto&tl=${lang}&dt=t&q=${encodeURIComponent(text)}`);

            

            const result = response.data[0].map(part => part[0]).join("");

            if (!result) throw new Error("Hasil kosong");

            let pesan = `🌐 ＲＥＳＵＬＴ (<code>${lang.toUpperCase()}</code>)\n`;

            pesan += `──────────────────\n`;

            pesan += `${result}`;

            await bot.sendMessage(chatId, pesan, { 

                parse_mode: 'HTML',

                reply_to_message_id: msg.message_id 

            });

        } catch (e) {

            console.error(`🔴 Error Translate: ${e.message}`);

            bot.sendMessage(chatId, "✘ Gagal menerjemahkan. Pastikan kode bahasa benar.");

        }

    }

};