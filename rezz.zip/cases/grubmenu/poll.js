// cases/poll.js (Pembuatan Polling/Kuis)

module.exports = {
    keyword: 'poll',
    keywordAliases: ['/poll', '/quiz'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const fullText = msg.text;
        
        // Hapus perintah dan ambil sisa teks
        const argsText = fullText.split(' ').slice(1).join(' ').trim();
        
        if (!argsText) {
            return bot.sendMessage(chatId, 
                "format salah, contoh penggunaan /poll pertanya ;jawaban :jawaban ;jawaban", 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        // Pisahkan teks menjadi bagian-bagian menggunakan titik koma (;)
        const parts = argsText.split(';');

        if (parts.length < 3) {
            return bot.sendMessage(chatId, 
                "❌ **Opsi Kurang.** Anda harus menyediakan minimal 1 pertanyaan dan minimal 2 opsi (total 3 bagian dipisahkan titik koma).", 
                { reply_to_message_id: msg.message_id });
        }

        // Bagian pertama adalah pertanyaan
        const question = parts[0].trim();
        
        // Sisa bagian adalah opsi jawaban (mulai dari indeks 1)
        const options = parts.slice(1).map(opt => opt.trim());

        if (options.length > 10) {
            return bot.sendMessage(chatId, 
                "❌ **Opsi Terlalu Banyak.** Telegram membatasi polling maksimum 10 opsi jawaban.", 
                { reply_to_message_id: msg.message_id });
        }

        try {
            // 2. Gunakan bot.sendPoll() dari Telegram API
            // Fungsi ini secara otomatis membuat dan mengirim Polling/Kuis
            
            // Opsi Tambahan (Opsional, untuk membuat kuis):
            // const is_quiz = false; 
            // const correct_option_id = 0; // Index opsi yang benar (jika is_quiz=true)

            await bot.sendPoll(chatId, question, options, {
                is_anonymous: false, // Disarankan agar terlihat siapa yang memilih
                allows_multiple_answers: false, // Hanya satu jawaban diizinkan
                reply_to_message_id: msg.message_id,
                // type: is_quiz ? 'quiz' : 'regular' // Tambahkan jika ingin membuat fitur kuis terpisah
            });

            // Hapus pesan perintah pengguna untuk menjaga kebersihan chat
            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});

        } catch (error) {
            console.error(`🔴 Error saat membuat Polling: ${error.message}`);
            bot.sendMessage(chatId, 
                `❌ **Gagal Membuat Polling.** Pastikan bot Anda adalah Admin di grup ini dan memiliki izin 'Send Polls'. Error: ${error.message}`, 
                { reply_to_message_id: msg.message_id });
        }
    }
};