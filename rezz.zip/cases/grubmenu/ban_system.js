const banDB = require('../../lib/bandb'); 

module.exports = {
    keyword: 'ban',
    keywordAliases: ['unban'],
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        
        try {
            const text = msg.text || "";
            const args = text.split(/\s+/);
            const command = args[0].toLowerCase().replace('/', '');

            if (msg.chat.type === 'private') {
                return bot.sendMessage(chatId, "✘ ᴘᴇʀɪɴᴛᴀʜ ʜᴀɴʏᴀ ᴅᴀᴘᴀᴛ ᴅɪ ɢᴜɴᴀᴋᴀɴ ᴅᴀʟᴀᴍ ɢʀᴜʙ.");
            }

            // --- PERBAIKAN CEK IZIN ---
            const userIsOwner = global.isOwner(userId);
            const userIsAdmin = userIsOwner ? true : await global.isAdmin(bot, chatId, userId);

            if (!userIsAdmin) return; // Jika bukan Admin/Owner, bot diam (abaikan)

            let targetId;
            let targetName = "User";

            // Deteksi Target
            if (msg.reply_to_message) {
                targetId = msg.reply_to_message.from.id;
                targetName = msg.reply_to_message.from.first_name || "User";
            } else if (msg.entities) {
                const mention = msg.entities.find(e => e.type === 'mention' || e.type === 'text_mention');
                if (mention) {
                    if (mention.type === 'text_mention') {
                        targetId = mention.user.id;
                        targetName = mention.user.first_name;
                    } else if (args[1]) {
                        // Jika mention biasa @user, ambil argumen kedua (biasanya ID atau bot butuh reply)
                        targetId = args[1].match(/^\d+$/) ? args[1] : null;
                    }
                }
            }

            if (!targetId) {
                return bot.sendMessage(chatId, "✘ ʀᴇᴘʟᴀʏ ᴘᴇsᴀɴ ᴍᴇᴍʙᴇʀ ᴀᴛᴀᴜ ᴛᴀɢ ᴍᴇᴍʙᴇʀ.");
            }

            if (global.isOwner(targetId)) return bot.sendMessage(chatId, "✘ ʏᴇᴜ ʙᴇɢᴏ, ᴏᴡɴᴇʀ ᴍᴀᴜ ᴅɪ ʙᴀɴ -_");

            if (command === 'unban') {
                banDB.removeBan(targetId);
                return bot.sendMessage(chatId, `✔ ᴜɴʙᴀɴ sᴜᴄᴄᴇs <a href="tg://user?id=${targetId}">${targetName}</a>`, { parse_mode: 'HTML' });
            }

            // Eksekusi Ban
            banDB.addBan(targetId);
            
            const opts = {
                parse_mode: 'HTML',
                reply_markup: {
                    inline_keyboard: [
                        [
                            { text: '🚫 𝙆𝙄𝘾𝙆', callback_data: `kick_member:${targetId}` },
                            { text: '🔓 𝘽𝙐𝙆𝘼 𝘽𝘼𝙉', callback_data: `unban_member:${targetId}` }
                        ]
                    ]
                }
            };

            await bot.sendMessage(chatId, `<b>𝙈𝘼𝙈𝙋𝙐𝙎 𝘿𝙄 𝘽𝘼𝙉</b>\n\n<b>ᴍᴇᴍʙᴇʀ:</b> <a href="tg://user?id=${targetId}">${targetName}</a>\n<b>ID:</b> <code>${targetId}</code>\n\nsᴇᴍᴜᴀ ᴀᴋᴛɪғɪᴛᴀs ɢʀᴜʙ ᴅɪ ᴛᴜᴛᴜᴘ ᴜɴᴛᴜᴋ ɪᴅ ɪɴɪ.`, opts);

        } catch (error) {
            console.error("ERROR BAN HANDLER:", error);
            bot.sendMessage(chatId, "✘ ᴇʀᴏʀ: " + error.message);
        }
    },

    callbackHandler: async (bot, query, settings) => {
        const { data, message } = query;
        const chatId = message.chat.id;
        const userId = query.from.id;

        if (!data.startsWith('kick_member:') && !data.startsWith('unban_member:')) return false;

        try {
            // --- PERBAIKAN CEK IZIN TOMBOL ---
            const userIsOwner = global.isOwner(userId);
            const userIsAdmin = userIsOwner ? true : await global.isAdmin(bot, chatId, userId);
            
            if (!userIsAdmin) {
                await bot.answerCallbackQuery(query.id, { text: "✘ ʜᴀɴʏᴀ ᴀᴅᴍɪɴ ʏᴀɴɢ ʙɪsᴀ ᴋʟɪᴋ!", show_alert: true });
                return true;
            }

            const targetId = data.split(':')[1];

            if (data.startsWith('kick_member:')) {
                // Gunakan banChatMember untuk mengeluarkan (Kick)
                await bot.banChatMember(chatId, targetId);
                await bot.unbanChatMember(chatId, targetId); // Unban agar bisa join lagi nanti
                await bot.editMessageText(`✔ ᴍᴇᴍʙᴇʀ <code>${targetId}</code> sᴜᴄᴄᴇs <b>ᴋɪᴄᴋ</b>.`, { chat_id: chatId, message_id: message.message_id, parse_mode: 'HTML' });
            } else {
                banDB.removeBan(targetId);
                await bot.editMessageText(`🔓 ʙᴀɴ ᴍᴇᴍʙᴇʀ <code>${targetId}</code> sᴜᴄᴄᴇs <b>ᴅɪʙᴜᴋᴀ</b>.`, { chat_id: chatId, message_id: message.message_id, parse_mode: 'HTML' });
            }
        } catch (e) {
            console.error("CALLBACK ERROR:", e.message);
            bot.answerCallbackQuery(query.id, { text: "❌ Gagal: Pastikan bot Admin!", show_alert: true });
        }
        return true;
    }
};