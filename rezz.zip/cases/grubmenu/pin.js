// cases/pin.js

module.exports = {
    keyword: '/pin',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const reply = msg.reply_to_message;
        const senderId = msg.from.id;
        const ownerIds = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.map(Number) 
            : [Number(settings.OWNER_ID)].filter(id => !isNaN(id));

        // 1. Validasi Reply
        if (!reply) {
            return bot.sendMessage(chatId, 
                '❌ **Kesalahan:** Silakan **reply** pada pesan yang ingin di-pin.', 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 2. Pengecekan Izin Pengguna (Owner/Admin) ---
        
        // Pengecekan Izin untuk Owner Bot
        const isOwner = ownerIds.includes(senderId);

        let isAdmin = false;
        if (!isOwner) {
            try {
                // Mendapatkan status anggota bot
                const chatMember = await bot.getChatMember(chatId, senderId);
                
                // Cek apakah pengguna adalah admin (termasuk creator/owner grup)
                if (['administrator', 'creator'].includes(chatMember.status)) {
                    isAdmin = true;
                }
            } catch (e) {
                // Jika gagal mendapatkan status, asumsikan bukan admin/owner
                console.error("Gagal memeriksa izin admin pengguna:", e.message);
            }
        }
        
        // Jika bukan Owner dan bukan Admin, tolak
        if (!isOwner && !isAdmin) {
            return bot.sendMessage(chatId, 
                '❌ **Akses Ditolak.**\n\nPerintah ini hanya dapat digunakan oleh **Owner Bot** atau **Admin Grup**.', 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
        
        // --- 3. Pengecekan Izin Bot Dihapus Total! ---
        // Kita berasumsi izin bot SUDAH benar di pengaturan grup (sesuai konfirmasi Anda)
        // dan langsung melompat ke eksekusi.

        
        // --- 4. Eksekusi Pin Pesan ---
        try {
            // Coba Pin Pesan
            await bot.pinChatMessage(chatId, reply.message_id, {
                // Pin dengan notifikasi (default: true)
            });

            // Kirim pesan konfirmasi
            const confirmationMessage = await bot.sendMessage(chatId, 
                `📌 Pesan berhasil di-pin!`, 
                { reply_to_message_id: reply.message_id, parse_mode: 'Markdown' });
                
            // Hapus pesan konfirmasi dan perintah /pin setelah 5 detik
            setTimeout(() => {
                bot.deleteMessage(chatId, confirmationMessage.message_id).catch(() => {});
                bot.deleteMessage(chatId, msg.message_id).catch(() => {}); 
            }, 5000); 

        } catch (error) {
            // Jika bot tidak memiliki izin pin, error akan ditangkap di sini
            console.error(`Gagal melakukan pin pesan: ${error.message}`);
            
            // Periksa apakah error disebabkan oleh izin bot
            const errorMessage = error.message && error.message.includes('not enough rights')
                ? '⚠️ **Gagal Pin Pesan:** Bot mungkin masih tidak memiliki izin **Pin Messages** di grup ini. Mohon periksa kembali izin bot.'
                : `❌ **Gagal Pin Pesan:** Terjadi kesalahan yang tidak terduga. (${error.message})`;

            bot.sendMessage(chatId, 
                errorMessage,
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }
    }
};