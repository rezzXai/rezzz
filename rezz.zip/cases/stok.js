const { getAllProducts } = require('../lib/stokdb'); 
const { getVoucher } = require('../lib/voucherdb'); 

const escapeHTML = (text) => {
    if (!text) return '';
    return text.toString()
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;');
};

const CATBOX_IMAGE_URL = 'https://files.catbox.moe/t74erf.jpg'; 

if (!global.userState) global.userState = {};

module.exports = {
    keyword: 'stok',
    keywordAliases: ['/stok', 'stok', 'back_to_stok_menu', 'cek_voucher', 'show_cat'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const isCallback = !!msg.callbackQuery;
        const data = isCallback ? msg.callbackQuery.data : (msg.text || '');
        const args = data.split(' ');
        const command = args[0].toLowerCase().replace('/', '');
        const messageIdToEdit = isCallback ? msg.callbackQuery.message.message_id : null;

        // --- 1. MENU UTAMA STOK ---
        if (command === 'stok' || data === 'stok' || data === 'back_to_stok_menu') {
            const menuCaption = `<blockquote>✨ <b>PROMO & DISKON TERSEDIA</b> ✨\n\nSilakan pilih metode belanja atau masukan kode voucher di bawah ini:</blockquote>`;
            const menuMarkup = {
                inline_keyboard: [
                    [{ text: "🎟️ MASUKAN VOUCHER DISKON", callback_data: "input_voucher" }],
                    [{ text: "🛒 LIHAT SEMUA KATEGORI", callback_data: "show_cat_0_none" }],
                    [{ text: "☜ ʙᴀᴄᴋ", callback_data: "/start_callback" }]                   
                ]
            };

            if (isCallback) {
                return bot.editMessageCaption(menuCaption, { chat_id: chatId, message_id: messageIdToEdit, parse_mode: 'HTML', reply_markup: menuMarkup })
                    .catch(() => bot.sendPhoto(chatId, CATBOX_IMAGE_URL, { caption: menuCaption, parse_mode: 'HTML', reply_markup: menuMarkup }));
            } else {
                return bot.sendPhoto(chatId, CATBOX_IMAGE_URL, { caption: menuCaption, parse_mode: 'HTML', reply_markup: menuMarkup });
            }
        }

        // --- 2. LOGIKA TAMPILKAN KATEGORI ---
        if (command === 'cek_voucher' || data.startsWith('show_cat_')) {
            let diskonPersen = 0;
            let voucherUsed = "none";

            if (data.startsWith('show_cat_')) {
                const parts = data.split('_');
                diskonPersen = parseInt(parts[2]) || 0;
                voucherUsed = parts[3] || "none";
            } else if (command === 'cek_voucher') {
                const kode = args[1]?.toUpperCase();
                const vDb = getVoucher();
                const vData = vDb.list[kode];
                
                if (!vData || vData.used >= vData.limit) {
                    return bot.sendMessage(chatId, "<blockquote>❌ <b>Voucher tidak valid atau kuota habis.</b></blockquote>", { parse_mode: 'HTML' });
                }
                diskonPersen = vData.diskon;
                voucherUsed = kode;
            }

            const allProducts = getAllProducts();
            const categories = [...new Set(allProducts.filter(p => p.count > 0).map(p => p.category || 'LAINNYA'))];

            if (categories.length === 0) return bot.sendMessage(chatId, "<blockquote>⚠️ <b>Mohon maaf, stok saat ini sedang kosong.</b></blockquote>", { parse_mode: 'HTML' });

            const catButtons = categories.map(cat => ([{
                text: `📂 ${cat}`,
                callback_data: `list_prod_${cat}_${diskonPersen}_${voucherUsed}`
            }]));
            catButtons.push([{ text: "☜ Kembali", callback_data: "stok" }]);

            const catMsg = `<blockquote>📂 <b>PILIH KATEGORI PRODUK</b>\n\n${voucherUsed !== 'none' ? `✅ <i>Voucher: ${voucherUsed} (-${diskonPersen}%)</i>` : 'Silakan pilih kategori di bawah:'}</blockquote>`;

            return bot.editMessageCaption(catMsg, { 
                chat_id: chatId, 
                message_id: messageIdToEdit, 
                parse_mode: 'HTML', 
                reply_markup: { inline_keyboard: catButtons } 
            }).catch(() => bot.sendPhoto(chatId, CATBOX_IMAGE_URL, { caption: catMsg, parse_mode: 'HTML', reply_markup: { inline_keyboard: catButtons } }));
        }

        // --- 3. LOGIKA DAFTAR PRODUK ---
        if (data.startsWith('list_prod_')) {
            const parts = data.split('_');
            const category = parts[2];
            const diskon = parts[3];
            const vName = parts[4];
            
            const allProducts = getAllProducts();
            const filteredProducts = allProducts.filter(p => p.category === category && p.count > 0);

            let stockMsg = `<blockquote>🛒 <b>DAFTAR STOK: ${category}</b>\n${vName !== 'none' ? `🎟️ <i>Voucher Terpasang: ${vName}</i>` : ''}</blockquote>\n`;
            const buttons = [];

            filteredProducts.forEach(product => {
                const hargaAsli = product.price || 0;
                const diskonNilai = parseInt(diskon);
                const hargaSetelahDiskon = hargaAsli - (hargaAsli * (diskonNilai / 100));
                const priceShow = hargaSetelahDiskon.toLocaleString('id-ID');
                const sisaStok = product.count || 0;

                stockMsg += `<b>${escapeHTML(product.nameDisplay || product.name)}</b>\n`;
                stockMsg += `└ 💰 <b>Rp ${priceShow}</b> (Stok: ${sisaStok})\n\n`; 

                const cbData = vName !== 'none' ? `stok_detail_${product.name}_${diskon}_${vName}` : `stok_detail_${product.name}_0_NONE`;
                buttons.push([{ text: `Beli ${product.nameDisplay} (${sisaStok})`, callback_data: cbData }]);
            });

            buttons.push([{ text: "☜ Kembali ke Kategori", callback_data: `show_cat_${diskon}_${vName}` }]);

            return bot.editMessageCaption(stockMsg, {
                chat_id: chatId,
                message_id: messageIdToEdit,
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: buttons }
            });
        }
    },

    callbackHandler: async (bot, callbackQuery) => {
        const chatId = callbackQuery.message.chat.id;
        const data = callbackQuery.data;

        if (data === 'input_voucher') {
            if (!global.userState) global.userState = {};
            global.userState[chatId] = { action: 'WAITING_VOUCHER' };

            await bot.sendMessage(chatId, "<blockquote>🎟️ <b>KIRIM KODE VOUCHER</b>\n\nKetik kode voucher kamu sekarang untuk mendapatkan potongan harga.</blockquote>", { parse_mode: 'HTML' });
            return true;
        }
        return false;
    }
};