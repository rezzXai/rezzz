const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');

let isProcessingPass = false;

module.exports = {
    keyword: 'vpspass',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // --- KONFIGURASI BROADCAST & HARGA ---
        const HARGA_GANTI = 1000;
        const ID_SALURAN = "-1002927416845"; // ID Saluran Log
        const IMAGE_URL = "https://files.catbox.moe/40p7bv.jpg"; // Gambar Broadcast
        const userDbPath = path.join(__dirname, '../../database/users_data.json');

        let userDb = fs.existsSync(userDbPath) ? JSON.parse(fs.readFileSync(userDbPath)) : {};

        const isOwner = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.includes(userId) 
            : settings.OWNER_ID == userId;

        const usernameUser = msg.from.username ? `@${msg.from.username}` : (msg.from.first_name || "User");

        // 1. Validasi Saldo
        if (!isOwner) {
            const currentSaldo = userDb[userId]?.saldo || 0;
            if (currentSaldo < HARGA_GANTI) {
                return bot.sendMessage(chatId, `✘ SALDO TIDAK CUKUP\nBiaya ganti password: Rp ${HARGA_GANTI.toLocaleString('id-ID')}`);
            }
        }

        if (isProcessingPass) return bot.sendMessage(chatId, "⏳ 𝘼𝙉𝙏𝙍𝙄 𝙊𝙈");

        const args = msg.text.split(/\s+/)[1];
        if (!args || args.split(',').length < 3) {
            return bot.sendMessage(chatId, "✘ Format: `/vpspass ipvps,pass_lama,pass_baru`", { parse_mode: 'Markdown' });
        }

        const [ip, oldPass, newPass] = args.split(',').map(item => item.trim());

        // 2. Potong Saldo
        let sudahBayar = false;
        if (!isOwner) {
            userDb[userId].saldo -= HARGA_GANTI;
            fs.writeFileSync(userDbPath, JSON.stringify(userDb, null, 2));
            sudahBayar = true;
        }

        isProcessingPass = true;
        let isSuccess = false;
        let isSSHReady = false;
        const conn = new Client();

        const doRefund = (reason) => {
            if (sudahBayar && !isSuccess) {
                let dbCurrent = JSON.parse(fs.readFileSync(userDbPath));
                if (!dbCurrent[userId]) dbCurrent[userId] = { saldo: 0 };
                dbCurrent[userId].saldo += HARGA_GANTI;
                fs.writeFileSync(userDbPath, JSON.stringify(dbCurrent, null, 2));
                bot.sendMessage(chatId, `🔄 REFUND BERHASIL\n${reason}`);
                sudahBayar = false;
            }
            isProcessingPass = false;
            conn.end();
        };

        conn.on('ready', () => {
            isSSHReady = true;
            bot.sendMessage(chatId, "𝙋𝙍𝙊𝘾𝙀𝙎𝙎...");

            conn.shell((err, stream) => {
                if (err) return doRefund("Gagal membuka Shell VPS.");

                stream.write('passwd\n');

                stream.on('data', (data) => {
                    const output = data.toString();
                    console.log('STDOUT:', output);

                    if (output.includes("New password:")) {
                        stream.write(`${newPass}\n`);
                    }
                    if (output.includes("Retype new password:")) {
                        stream.write(`${newPass}\n`);
                    }

                    if (output.includes("password updated successfully")) {
                        isSuccess = true;
                        
                        // 1. Notif Sukses ke User
                        bot.sendMessage(chatId, "✔ 𝘾𝙃𝘼𝙉𝙂𝙀 𝙋𝘼𝙎𝙒𝙊𝙍𝘿 𝙎𝙐𝘾𝘾𝙀𝙎");

                        // 2. Broadcast ke Saluran
                        const sekarang = new Date();
                        const hari = sekarang.toLocaleDateString('id-ID', { weekday: 'long' });
                        const tanggal = sekarang.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

                        let caption = `📢 ADA YANG GANTI PASS VPS NI\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `👤 Username: ${usernameUser}\n`;
                        caption += `🛒 Produk: Ganti Password VPS\n`;
                        caption += `💰 Harga: Rp ${HARGA_GANTI.toLocaleString('id-ID')}\n`;
                        caption += `📅 Hari: ${hari}\n`;
                        caption += `📆 Tanggal: ${tanggal}\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `✅ Status: Sukses Terganti`;

                        bot.sendPhoto(ID_SALURAN, IMAGE_URL, { 
                            caption: caption, 
                            parse_mode: 'Markdown' 
                        });

                        isProcessingPass = false;
                        conn.end();
                    }
                });

                stream.on('close', () => {
                    if (!isSuccess) doRefund("Koneksi terputus sebelum password terganti.");
                });
            });

        }).on('error', (err) => {
            if (!isSSHReady) {
                doRefund(`Gagal Login (IP/Password Lama Salah). Error: ${err.message}`);
            } else {
                isProcessingPass = false;
                bot.sendMessage(chatId, `❌ SSH Error: ${err.message}`);
            }
        }).connect({
            host: ip,
            port: 22,
            username: 'root',
            password: oldPass,
            readyTimeout: 15000
        });
    }
};