const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');

// Variabel status untuk mengontrol antrean
let isProcessing = false;

module.exports = {
    keyword: 'instalpanel',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // --- KONFIGURASI ---
        const HARGA_INSTAL = 3000;
        const TIMEOUT_LIMIT = 15 * 60 * 1000; // 15 Menit
        const userDbPath = path.join(__dirname, '../../database/users_data.json');
        
        // Konfigurasi Broadcast
        const ID_SALURAN = "-1002927416845"; // ID Saluran Log
        const IMAGE_URL = "https://files.catbox.moe/40p7bv.jpg"; // Gambar Broadcast

        // Load Database
        let userDb = fs.existsSync(userDbPath) ? JSON.parse(fs.readFileSync(userDbPath)) : {};

        // Cek Owner
        const isOwner = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.includes(userId) 
            : settings.OWNER_ID == userId;

        const usernameUser = msg.from.username ? `@${msg.from.username}` : (msg.from.first_name || "User");

        // 1. Validasi Saldo (Hanya jika bukan owner)
        if (!isOwner) {
            const currentSaldo = userDb[userId]?.saldo || 0;
            if (currentSaldo < HARGA_INSTAL) {
                return bot.sendMessage(chatId, `✘ SALDO TIDAK CUKUP\n\nHarga: Rp ${HARGA_INSTAL.toLocaleString('id-ID')}\nSaldo: Rp ${currentSaldo.toLocaleString('id-ID')}\n\nSilakan ketik /deposit.`);
            }
        }

        // 2. Cek Antrean
        if (isProcessing) {
            return bot.sendMessage(chatId, "⏳ 𝘼𝙉𝙏𝙍𝙄 𝙊𝙈\n𝘴𝘦𝘣𝘦𝘭𝘢𝘩 𝘭𝘢𝘨𝘪 𝘪𝘯𝘴𝘵𝘢𝘭 𝘱𝘢𝘯𝘦𝘭 𝘴𝘰𝘢𝘭𝘯𝘺𝘢");
        }

        const args = msg.text.split(/\s+/)[1];
        if (!args || args.split(',').length < 4) {
            return bot.sendMessage(chatId, "✘ Format: /instalpanel domain,username,ipvps,passvps", { parse_mode: 'Markdown' });
        }

        // 3. Potong Saldo di Awal
        let sudahBayar = false;
        if (!isOwner) {
            userDb[userId].saldo -= HARGA_INSTAL;
            fs.writeFileSync(userDbPath, JSON.stringify(userDb, null, 2));
            sudahBayar = true;
        }

        const [domain, username, ip, passwordVps] = args.split(',');
        const panelPassword = `${username}${Math.floor(100 + Math.random() * 900)}`; 
        const emailUser = `${username}@gmail.com`;

        isProcessing = true;
        let isSuccess = false;
        let isSSHReady = false; 
        let timerRefund = null;
        const conn = new Client();

        // --- FUNGSI REFUND ---
        const doRefund = (reason) => {
            if (sudahBayar) {
                let dbCurrent = JSON.parse(fs.readFileSync(userDbPath));
                if (!dbCurrent[userId]) dbCurrent[userId] = { saldo: 0 };
                dbCurrent[userId].saldo += HARGA_INSTAL;
                fs.writeFileSync(userDbPath, JSON.stringify(dbCurrent, null, 2));
                bot.sendMessage(chatId, `🔄 REFUND BERHASIL\n${reason}\nSaldo Rp ${HARGA_INSTAL.toLocaleString('id-ID')} dikembalikan.`);
                sudahBayar = false;
            }
            isProcessing = false;
            conn.end();
        };

        const resetTimer = () => {
            if (timerRefund) clearTimeout(timerRefund);
            timerRefund = setTimeout(() => {
                if (!isSuccess) doRefund("Bot stuck/tidak ada respon selama 15 menit.");
            }, TIMEOUT_LIMIT);
        };

        conn.on('ready', () => {
            isSSHReady = true; 
            bot.sendMessage(chatId, "✅ SISTEM TERHUBUNG SSH\nInstalasi dimulai....");
            resetTimer();

            conn.shell((err, stream) => {
                if (err) {
                    isProcessing = false;
                    if (timerRefund) clearTimeout(timerRefund);
                    return bot.sendMessage(chatId, `❌ Error: ${err.message}`);
                }

                stream.write(`bash <(curl -s https://pterodactyl-installer.se)\n`);

                stream.on('data', (data) => {
                    resetTimer(); 
                    const output = data.toString();
                    console.log('STDOUT:', output);

                    if (output.includes("Input 0-6:")) stream.write("0\n");
                    if (output.includes("Database name (panel):")) stream.write("\n");
                    if (output.includes("Database username (pterodactyl):")) stream.write("\n");
                    if (output.includes("Password (press enter to use randomly generated password):")) stream.write(`${panelPassword}\n`);
                    if (output.includes("Select timezone")) stream.write("Asia/Jakarta\n");
                    if (output.includes("Provide the email address that will be used")) stream.write(`${emailUser}\n`);
                    if (output.includes("Email address for the initial admin account:")) stream.write(`${emailUser}\n`);
                    if (output.includes("Username for the initial admin account:")) stream.write(`${username}\n`);
                    if (output.includes("First name for the initial admin account:")) stream.write(`${username}\n`);
                    if (output.includes("Last name for the initial admin account:")) stream.write(`${username}\n`);
                    if (output.includes("Password for the initial admin account:")) stream.write(`${panelPassword}\n`);
                    if (output.includes("Set the FQDN of this panel")) stream.write(`${domain}\n`);
                    if (output.includes("I agree that this HTTPS request is performed")) stream.write("y\n");

                    if (output.includes("Proceed anyways") && output.includes("(y/N)")) {
                        stream.write("y\n");
                        bot.sendMessage(chatId, "⚠️ 𝙈𝙄𝙎𝙎 𝙋𝙍𝙊𝙎𝙀𝙎.");
                    }

                    if (output.includes("automatically configure UFW") || 
                        output.includes("automatically configure Nginx") ||
                        output.includes("automatically configure HTTPS")) {
                        stream.write("y\n");
                    }

                    if (output.includes("Continue with installation?")) stream.write("y\n");
                    if (output.includes("anonymous telemetry data?")) stream.write("yes\n");
                    if (output.includes("(Y)es/(N)o")) stream.write("y\n");

                    if (output.includes("Thank you for using this script")) {
                        isSuccess = true;
                        if (timerRefund) clearTimeout(timerRefund);
                        
                        // 1. Notifikasi Sukses ke User
                        bot.sendMessage(chatId, 
                            `✅ **SUCCESS INSTALASI**\n\n` +
                            `🌐 **URL:** https://${domain}\n` +
                            `👤 **User:** \`${username}\`\n` +
                            `🔑 **Pass:** \`${panelPassword}\``, 
                            { parse_mode: 'Markdown' }
                        );

                        // 2. Broadcast ke Saluran
                        const sekarang = new Date();
                        const hari = sekarang.toLocaleDateString('id-ID', { weekday: 'long' });
                        const tanggal = sekarang.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

                        let caption = `📢 ADA YANG INSTAL PANEL NI\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `👤 Username: ${usernameUser}\n`;
                        caption += `🛒 Produk: Instal Panel Pterodactyl\n`;
                        caption += `💰 Harga: Rp ${HARGA_INSTAL.toLocaleString('id-ID')}\n`;
                        caption += `📅 Hari: ${hari}\n`;
                        caption += `📆 Tanggal: ${tanggal}\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `✅ Status: Sukses Terinstal`;

                        bot.sendPhoto(ID_SALURAN, IMAGE_URL, { 
                            caption: caption, 
                            parse_mode: 'Markdown' 
                        });

                        isProcessing = false;
                        conn.end();
                    }
                });

                stream.on('close', () => {
                    isProcessing = false;
                    if (timerRefund) clearTimeout(timerRefund);
                    conn.end();
                });
            });
        }).on('error', (err) => {
            isProcessing = false;
            if (timerRefund) clearTimeout(timerRefund);
            
            if (!isSSHReady) {
                doRefund(`Gagal Login SSH (Cek IP/Password VPS). Error: ${err.message}`);
            } else {
                bot.sendMessage(chatId, `❌ SSH Error: ${err.message}`);
            }
        }).connect({
            host: ip,
            port: 22,
            username: 'root',
            password: passwordVps,
            readyTimeout: 20000
        });
    }
};