const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');

let isProcessing = false;

module.exports = {
    keyword: 'uninstallpanel',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // --- KONFIGURASI BROADCAST & HARGA ---
        const ID_SALURAN = "-1002927416845"; 
        const IMAGE_URL = "https://files.catbox.moe/40p7bv.jpg"; // Menggunakan image yang sama dengan instalnode
        const HARGA_UNINSTALL = 2000; 
        const TIMEOUT_LIMIT = 10 * 60 * 1000; 
        const userDbPath = path.join(__dirname, '../../database/users_data.json');

        let userDb = fs.existsSync(userDbPath) ? JSON.parse(fs.readFileSync(userDbPath)) : {};

        const isOwner = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.includes(userId) 
            : settings.OWNER_ID == userId;

        const usernameUser = msg.from.username ? `@${msg.from.username}` : (msg.from.first_name || "User");

        // 1. Validasi Saldo
        if (!isOwner) {
            const currentSaldo = userDb[userId]?.saldo || 0;
            if (currentSaldo < HARGA_UNINSTALL) {
                return bot.sendMessage(chatId, `✘ **SALDO TIDAK CUKUP**\nHarga: Rp ${HARGA_UNINSTALL.toLocaleString('id-ID')}\nSaldo: Rp ${currentSaldo.toLocaleString('id-ID')}\n\nSilakan ketik /deposit.`);
            }
        }

        if (isProcessing) return bot.sendMessage(chatId, "⏳ 𝘼𝙉𝙏𝙍𝙄 𝙊𝙈, sedang ada proses lain.");

        const argsRaw = (msg.text || "").split(/\s+/)[1];
        if (!argsRaw || argsRaw.split(',').length < 2) {
            return bot.sendMessage(chatId, "✘ Format: `/uninstallpanel ipvps,passvps`", { parse_mode: 'Markdown' });
        }

        // 2. Potong Saldo di Awal
        let sudahBayar = false;
        if (!isOwner) {
            userDb[userId].saldo -= HARGA_UNINSTALL;
            fs.writeFileSync(userDbPath, JSON.stringify(userDb, null, 2));
            sudahBayar = true;
        }

        const [ip, passwordVps] = argsRaw.split(',').map(item => item.trim());
        isProcessing = true;

        let isSuccess = false;
        let isSSHReady = false;
        let timerRefund = null;

        bot.sendMessage(chatId, "🔗 𝘔𝘦𝘯𝘨𝘩𝘶𝘣𝘶𝘯𝘨𝘬𝘢𝘯 𝘷𝘱𝘴.....");

        const conn = new Client();

        const doRefund = (reason) => {
            if (sudahBayar && !isSuccess) {
                let dbCurrent = JSON.parse(fs.readFileSync(userDbPath));
                if (!dbCurrent[userId]) dbCurrent[userId] = { saldo: 0 };
                dbCurrent[userId].saldo += HARGA_UNINSTALL;
                fs.writeFileSync(userDbPath, JSON.stringify(dbCurrent, null, 2));
                bot.sendMessage(chatId, `🔄 **REFUND BERHASIL**\n${reason}\nSaldo dikembalikan.`);
                sudahBayar = false;
            }
            isProcessing = false;
            conn.end();
        };

        const resetTimer = () => {
            if (timerRefund) clearTimeout(timerRefund);
            timerRefund = setTimeout(() => {
                if (!isSuccess) doRefund("Proses stuck/timeout selama 10 menit.");
            }, TIMEOUT_LIMIT);
        };

        conn.on('ready', () => {
            isSSHReady = true;
            bot.sendMessage(chatId, "✅ **TERHUBUNG**\n𝘔𝘦𝘮𝘶𝘭𝘢𝘪 𝘱𝘳𝘰𝘴𝘦𝘴 𝘶𝘯𝘪𝘯𝘴𝘵𝘢𝘭𝘭 𝘱𝘢𝘯𝘦𝘭...");
            resetTimer();

            conn.shell((err, stream) => {
                if (err) return doRefund("Gagal membuka shell");
                stream.write(`bash <(curl -s https://pterodactyl-installer.se)\n`);

                stream.on('data', (data) => {
                    const output = data.toString();
                    resetTimer();

                    // Logika Jawaban Otomatis
                    if (output.includes("0-6")) stream.write("6\n");
                    else if (output.includes("Do you want to remove panel?")) stream.write("y\n");
                    else if (output.includes("Do you want to remove Wings (daemon)?")) stream.write("y\n");
                    else if (output.includes("Continue with uninstallation?")) stream.write("y\n");
                    else if (output.includes("Database called panel has been detected.")) stream.write("y\n");
                    else if (output.includes("User called pterodactyl has been detected.")) stream.write("y\n");

                    // Cek Selesai
                    if (output.includes("Thank you for using this script.") || output.includes("Uninstallation completed")) {
                        isSuccess = true;
                        if (timerRefund) clearTimeout(timerRefund);

                        bot.sendMessage(chatId, "🎯 **𝙐𝙉𝙄𝙉𝙎𝙏𝘼𝙇𝙇 𝙎𝙐𝘾𝘾𝙀𝙎**\n✔ Panel & Wings berhasil dihapus.");

                        // --- LOGIKA BROADCAST KE SALURAN ---
                        const sekarang = new Date();
                        const hari = sekarang.toLocaleDateString('id-ID', { weekday: 'long' });
                        const tanggal = sekarang.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

                        let caption = `📢 **ADA YANG UNINSTALL PANEL NI**\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `👤 Username: ${usernameUser}\n`;
                        caption += `🛒 Produk: Uninstall Panel & Wings\n`;
                        caption += `💰 Harga: Rp ${HARGA_UNINSTALL.toLocaleString('id-ID')}\n`;
                        caption += `📅 Hari: ${hari}\n`;
                        caption += `📆 Tanggal: ${tanggal}\n`;
                        caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                        caption += `✅ Status: Sukses Terhapus`;

                        bot.sendPhoto(ID_SALURAN, IMAGE_URL, { caption: caption, parse_mode: 'Markdown' }).catch(e => console.error("Gagal Broadcast:", e.message));

                        isProcessing = false;
                        conn.end();
                    }
                });
            });

        }).on('error', (err) => {
            if (timerRefund) clearTimeout(timerRefund);
            if (!isSSHReady) {
                doRefund(`Gagal Login SSH (Cek IP/Password). Error: ${err.message}`);
            } else {
                isProcessing = false;
                bot.sendMessage(chatId, `❌ SSH Error: ${err.message}`);
            }
        }).connect({
            host: ip,
            port: 22,
            username: 'root',
            password: passwordVps,
            readyTimeout: 20000
        });
    }
};