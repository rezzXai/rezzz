const { Client } = require('ssh2');
const fs = require('fs');
const path = require('path');

let isProcessingNode = false;
let activeStream = null;
let currentInstallerId = null; 

module.exports = {
    keyword: 'instalnode',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // --- KONFIGURASI BROADCAST ---
        const ID_SALURAN = "-1002927416845"; 
        const IMAGE_URL = "https://files.catbox.moe/40p7bv.jpg"; 
        const HARGA_INSTAL = 3000;
        const TIMEOUT_LIMIT = 15 * 60 * 1000; 
        const userDbPath = path.join(__dirname, '../../database/users_data.json');

        let userDb = fs.existsSync(userDbPath) ? JSON.parse(fs.readFileSync(userDbPath)) : {};

        const isOwner = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.includes(userId) 
            : settings.OWNER_ID == userId;

        const usernameUser = msg.from.username ? `@${msg.from.username}` : (msg.from.first_name || "User");

        if (!isOwner) {
            const currentSaldo = userDb[userId]?.saldo || 0;
            if (currentSaldo < HARGA_INSTAL) {
                return bot.sendMessage(chatId, `✘ SALDO TIDAK CUKUP\nHarga: Rp ${HARGA_INSTAL.toLocaleString('id-ID')}\nSaldo: Rp ${currentSaldo.toLocaleString('id-ID')}\n\nSilakan ketik /deposit.`);
            }
        }

        if (isProcessingNode) return bot.sendMessage(chatId, "⏳  𝘼𝙉𝙏𝙍𝙄 𝙇𝙀𝙆");

        const argsRaw = (msg.text || "").split(/\s+/)[1];

        if (!argsRaw || argsRaw.split(',').length < 5) {
            return bot.sendMessage(chatId, "✘ Format: `/instalnode node,passpanel,userpanel,ipvps,pwvps`", { parse_mode: 'Markdown' });
        }

        let sudahBayar = false;
        if (!isOwner) {
            userDb[userId].saldo -= HARGA_INSTAL;
            fs.writeFileSync(userDbPath, JSON.stringify(userDb, null, 2));
            sudahBayar = true;
        }

        const [node, passPanel, userPanel, ip, pwVps] = argsRaw.split(',').map(item => item.trim());
        const emailUser = `${userPanel.toLowerCase()}@gmail.com`;

        isProcessingNode = true;
        currentInstallerId = userId;
        // Simpan data untuk broadcast nanti
        global.tempNodeData = { usernameUser, harga: HARGA_INSTAL, idSaluran: ID_SALURAN, imageUrl: IMAGE_URL };

        let isSuccess = false; 
        let isSSHReady = false;
        let timerRefund = null;

        bot.sendMessage(chatId, "🔗 𝘔𝘦𝘯𝘨𝘩𝘶𝘣𝘶𝘯𝘨𝘬𝘢𝘯.....");

        const conn = new Client();

        const doRefund = (reason) => {
            if (sudahBayar && !isSuccess) {
                let dbCurrent = JSON.parse(fs.readFileSync(userDbPath));
                if (!dbCurrent[userId]) dbCurrent[userId] = { saldo: 0 };
                dbCurrent[userId].saldo += HARGA_INSTAL;
                fs.writeFileSync(userDbPath, JSON.stringify(dbCurrent, null, 2));
                bot.sendMessage(chatId, `🔄 REFUND BERHASIL\n${reason}\nSaldo dikembalikan.`);
                sudahBayar = false;
            }
            isProcessingNode = false;
            activeStream = null;
            conn.end();
        };

        const resetTimer = () => {
            if (timerRefund) clearTimeout(timerRefund);
            if (isSuccess) return; 

            timerRefund = setTimeout(() => {
                if (!isSuccess) doRefund("Bot stuck/tidak ada respon selama 15 menit.");
            }, TIMEOUT_LIMIT);
        };

        conn.on('ready', () => {
            isSSHReady = true;
            bot.sendMessage(chatId, "✅ 𝘛𝘦𝘳ʜ𝘶𝘣𝘶𝘯𝘨\n𝘱𝘳𝘰𝘴𝘦𝘴 𝘥𝘪 𝘮𝘶𝘭𝘢𝘪...");
            resetTimer();

            conn.shell((err, stream) => {
                if (err) { isProcessingNode = false; return; }
                activeStream = stream;
                stream.write(`bash <(curl -s https://pterodactyl-installer.se)\n`);

                stream.on('data', (data) => {
                    const output = data.toString();
                    resetTimer(); 

                    if (output.includes("Input 0-6:")) stream.write("1\n");
                    else if (output.includes("automatically configure UFW")) stream.write("y\n");
                    else if (output.includes("user for database hosts")) stream.write("y\n");
                    else if (output.includes("MySQL to be accessed externally")) stream.write("y\n");
                    else if (output.includes("Enter the panel address")) stream.write("\n");
                    else if (output.includes("port 3306") || output.includes("port 3395")) stream.write("y\n");
                    else if (output.includes("Database host username")) stream.write("\n");
                    else if (output.includes("Database host password")) stream.write(`${passPanel}\n`);
                    else if (output.includes("configure HTTPS using Let's Encrypt")) stream.write("y\n");
                    else if (output.includes("Set the FQDN")) stream.write(`${node}\n`);
                    else if (output.includes("HTTPS request is performed")) stream.write("y\n");
                    else if (output.includes("email address for Let's Encrypt")) {
                        setTimeout(() => { stream.write(`${emailUser}\n`); }, 1000);
                    }
                    else if (output.includes("Proceed with installation?")) stream.write("y\n");

                    if (output.includes("systemctl start wings") || output.includes("Once you have verified")) {
                        isSuccess = true; 
                        if (timerRefund) {
                            clearTimeout(timerRefund);
                            timerRefund = null;
                        }
                        bot.sendMessage(chatId, "𝗣𝗘𝗡𝗬𝗘𝗦𝗨𝗔𝗜𝗔𝗡 𝗔𝗞𝗛𝗜𝗥!! \n\n𝘚𝘢𝘭𝘪𝘯 𝘛𝘰𝙠𝘦𝘯 𝘊𝘰𝘯𝘧𝘪𝘨𝘶𝘳𝘢𝘵𝘪𝘰𝘯,𝘋𝘢𝘯 𝘒𝘪𝘳𝘪𝘮 𝘋𝘪𝘴𝘪𝘯𝘪. .");
                    }
                });

                stream.on('close', () => {
                    isProcessingNode = false;
                    activeStream = null;
                    if (timerRefund) clearTimeout(timerRefund);
                    conn.end();
                });
            });

        }).on('error', (err) => {
            if (timerRefund) clearTimeout(timerRefund);
            if (!isSSHReady) {
                doRefund(`Gagal Login SSH (Cek IP/Password). Error: ${err.message}`);
            } else {
                isProcessingNode = false;
                bot.sendMessage(chatId, `✘ Gagal: ${err.message}`);
            }
        }).connect({ host: ip, port: 22, username: 'root', password: pwVps });

        global.nodeTimer = timerRefund;
    },

    textHandler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const text = msg.text || "";

        const isOwner = Array.isArray(settings.OWNER_ID) 
            ? settings.OWNER_ID.includes(userId) 
            : settings.OWNER_ID == userId;

        if (text.includes('wings configure') && activeStream && (userId === currentInstallerId || isOwner)) {
            
            bot.sendMessage(chatId, "𝗧𝗢𝗞𝗘𝗡 𝗔ＣＣ\nＬＯＡＤＩＮＧ ＤＩＫＩＴ....");

            if (global.nodeTimer) {
                clearTimeout(global.nodeTimer);
                global.nodeTimer = null;
            }

            activeStream.write(`${text.trim()}\n`);

            setTimeout(() => {
                activeStream.write(`systemctl enable --now wings\n`);
                activeStream.write(`systemctl restart wings\n`);
                activeStream.write(`systemctl start wings\n`);
            }, 2000);

            setTimeout(() => {
                activeStream.write(`systemctl start wings\n`);
                bot.sendMessage(chatId, "ＤＯＮＥ ＬＥＥＥ\n𝘢𝘤𝘤𝘦𝘴𝘴 𝘥𝘪 𝘵𝘶𝘵𝘶𝘱,𝘴𝘦𝘴𝘪 𝘪𝘯𝘴𝘵𝘢𝘭 𝘯𝘰𝘥𝘦&𝘸𝘪𝘯𝘨𝘴 𝘴𝘶𝘤𝘤𝘦𝘴.");
                
                // --- LOGIKA BROADCAST DI SINI ---
                if (global.tempNodeData) {
                    const { usernameUser, harga, idSaluran, imageUrl } = global.tempNodeData;
                    const sekarang = new Date();
                    const hari = sekarang.toLocaleDateString('id-ID', { weekday: 'long' });
                    const tanggal = sekarang.toLocaleDateString('id-ID', { day: '2-digit', month: 'long', year: 'numeric' });

                    let caption = `📢 ADA YANG INSTAL NODE NI\n`;
                    caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                    caption += `👤 Username: ${usernameUser}\n`;
                    caption += `🛒 Produk: Instal Node & Wings\n`;
                    caption += `💰 Harga: Rp ${harga.toLocaleString('id-ID')}\n`;
                    caption += `📅 Hari: ${hari}\n`;
                    caption += `📆 Tanggal: ${tanggal}\n`;
                    caption += `━━━━━━━━━━━━━━━━━━━━\n`;
                    caption += `✅ Status: Sukses Terinstal`;

                    bot.sendPhoto(idSaluran, imageUrl, { caption: caption, parse_mode: 'Markdown' });
                }

                isProcessingNode = false;
                activeStream.end();
            }, 5000);

            return true; 
        }
        return false;
    }
};