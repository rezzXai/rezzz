const fs = require('fs');
const path = require('path');
const AdmZip = require('adm-zip');
const { OWNER_ID } = require('../setting');

module.exports = {
    keyword: 'backup',
    keywordAliases: ['/backup'],
    handler: async (bot, msg) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;

        // PROTEKSI OWNER
        if (Number(userId) !== Number(OWNER_ID)) {
            return bot.sendMessage(chatId, 
`✘ <b>ACCESS DENIED</b>
<pre>
━━━━━━━━━━━━━━━━━━━━
STATUS : REJECTED
ID     : ${userId}
INFO   : Khusus Owner!
━━━━━━━━━━━━━━━━━━━━
</pre>`, { parse_mode: 'HTML' });
        }

        const dataFolder = path.join(__dirname, '../data');
        const dbFolder = path.join(__dirname, '../database');
        const backupFile = path.join(__dirname, '../backup_full_system.zip');

        try {
            const zip = new AdmZip();

            // Tambahkan folder 'data' jika ada
            if (fs.existsSync(dataFolder)) {
                zip.addLocalFolder(dataFolder, 'data'); 
            }

            // Tambahkan folder 'database' jika ada
            if (fs.existsSync(dbFolder)) {
                zip.addLocalFolder(dbFolder, 'database');
            }

            // Cek jika tidak ada satupun folder yang ditemukan
            if (!fs.existsSync(dataFolder) && !fs.existsSync(dbFolder)) {
                return bot.sendMessage(chatId, "⚠️ <b>Gagal:</b> Folder data & database tidak ditemukan.", { parse_mode: 'HTML' });
            }

            zip.writeZip(backupFile);
            const stats = fs.statSync(backupFile);

            await bot.sendDocument(chatId, backupFile, {
                caption: `📦 <b>BACKUP SELESAI</b>\n<pre>\nSIZE : ${(stats.size / 1024).toFixed(2)} KB\nTYPE : Data & Database Folder\nDATE : ${new Date().toLocaleString('id-ID')}\n</pre>`,
                parse_mode: 'HTML'
            });

            // Hapus file ZIP setelah dikirim agar tidak memenuhi penyimpanan
            if (fs.existsSync(backupFile)) fs.unlinkSync(backupFile);

        } catch (e) {
            bot.sendMessage(chatId, `<pre>ERROR: ${e.message}</pre>`, { parse_mode: 'HTML' });
        }
    }
};