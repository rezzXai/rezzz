const { getGithubData } = require('../lib/github');

module.exports = {

    keyword: 'listbuyer',

    handler: async (bot, msg, settings) => {

        const github = await getGithubData();

        

        if (!github) return bot.sendMessage(msg.chat.id, "❌ Gagal mengambil data.");

        const ownerName = settings.AUTHOR_BOT || 'rezzXai';

        const ownerUser = settings.OWNER_USERNAME || 'rezzXai';

        let response = `<b>ＤＥＶＥＬＯＰＥＲ</b>\n`;

        response += `⪼ ${ownerName}, @${ownerUser} [ᴅᴇᴠᴇʟᴏᴘᴇʀ]\n\n`;

        

        response += `<b>ＡＬＬ ＭＥＭＢＥＲ</b>\n`;

        

        if (!github.data.list_buyer || github.data.list_buyer.length === 0) {

            response += `⪼ <i>Belum ada member terdaftar.</i>`;

        } else {

            github.data.list_buyer.forEach((user) => {

                const mention = user.username !== 'No_Username' ? `@${user.username}` : user.id;

                response += `⪼ ${user.name}, ${mention} [${user.role}]\n`;

            });

        }

        bot.sendMessage(msg.chat.id, response, { parse_mode: 'HTML' });

    }

};