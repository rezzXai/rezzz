// File: cases/play.js

// PENTING: Mengimpor dari file 'yt.js' di root folder
const { ytPlayMp3 } = require('../yt'); 

module.exports = {
    keyword: 'play',
    keywordAliases: ['music', 'audio'],
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const text = msg.text.trim();
        const parts = text.split(/\s+/);
        
        if (parts.length < 2) {
            return bot.sendMessage(chatId, 
                `❌ Format salah.\n\nGunakan: \`/play <Judul Audio/Musik>\``, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const query = parts.slice(1).join(' '); 

        const loadingMsg = await bot.sendMessage(chatId, `🎧 Mencari dan memproses audio untuk: **${query}**`, { parse_mode: 'Markdown' });

        try {
            const result = await ytPlayMp3(query); 
            
            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});

            if (!result || !result.url) {
                return bot.sendMessage(chatId, "❌ Gagal menemukan atau memproses audio untuk judul tersebut.", { reply_to_message_id: msg.message_id });
            }
            
            const caption = `
🎵 **PLAY MUSIK BERHASIL**
            
**Judul:** ${result.title}
**Channel:** ${result.channel}
**Views:** ${result.views.toLocaleString()}
            `;

            await bot.sendAudio(chatId, result.url, { 
                caption: caption,
                parse_mode: 'Markdown',
                title: result.title,
                performer: result.channel,
                reply_to_message_id: msg.message_id 
            });

        } catch (e) {
            console.error(`🔴 Error di /play:`, e);
            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
            bot.sendMessage(chatId, "Terjadi kesalahan saat memproses permintaan audio. Cek log konsol.");
        }
    }
};