// cases/me.js (Fitur /me: Informasi Pengguna & Statistik)

// Catatan: global.allChatIds diinisialisasi dan diisi di file rezz.js

module.exports = {
    keyword: '/me',
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const userId = msg.from.id;
        const username = msg.from.username || 'N/A';
        const firstName = msg.from.first_name || 'Pengguna';
        
        // Dapatkan Total Pengguna dari global.allChatIds
        // Pastikan Set sudah terinisialisasi
        const totalUsers = global.allChatIds ? global.allChatIds.size : 0;
        
        // Cek apakah pengguna adalah Owner Bot
        const isOwner = userId.toString() === settings.OWNER_ID.toString();
        const statusIcon = isOwner ? '👑 Owner Bot' : '👤 Pengguna Biasa';
        
        // --- Tampilan Pesan Keren dan Rapi ---
        const response = 
            `📊 **STATISTIK DAN PROFIL ANDA** 👤\n` +
            `===============================\n\n` +
            
            `**1. 📝 PROFIL ANDA**\n` +
            `• Nama Depan: **${firstName}**\n` +
            `• Username: \`@${username}\`\n` +
            `• ID Telegram: \`${userId}\`\n` +
            `• Status: **${statusIcon}**\n\n` +
            
            `**2. 🌐 STATISTIK BOT**\n` +
            `• Total Pengguna: **${totalUsers}** Chat Tersimpan\n` +
            `• ID Chat Saat Ini: \`${chatId}\`\n` +
            `• Nama Bot: \`${settings.BOT_NAME || 'rezzXai'}\`\n` +
            
            `\n===============================\n` +
            `_Terima kasih telah menggunakan ${settings.BOT_NAME}!_`;

        await bot.sendMessage(chatId, response, { parse_mode: 'Markdown' });
    }
};