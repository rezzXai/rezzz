// File: cases/ai.js

// Impor library Gemini
const { GoogleGenAI } = require('@google/genai');
const settings = require('../setting'); // Impor settings.js

// PENTING: Mengakses API Key dengan aman sesuai struktur settings.js Anda
// Menggunakan optional chaining (?) dan fallback ke array kosong (|| [])
const geminiApiKeys = settings?.global?.APIKeys?.geminiApikey || [];

// Fungsi untuk memilih API Key secara acak
function getRandomApiKey() {
    if (!geminiApiKeys || geminiApiKeys.length === 0) {
        return null;
    }
    const randomIndex = Math.floor(Math.random() * geminiApiKeys.length);
    return geminiApiKeys[randomIndex];
}

module.exports = {
    keyword: 'ai',
    keywordAliases: ['ask', 'tanya'], 
    
    handler: async (bot, msg, settings) => {
        const chatId = msg.chat.id;
        const text = msg.text.trim();
        const parts = text.split(/\s+/);
        
        const apiKey = getRandomApiKey();

        if (!apiKey) {
            return bot.sendMessage(chatId, "❌ ERROR: Tidak ditemukan API Key Gemini di settings.js. Pastikan variabel 'geminiApikey' ada di settings.global.APIKeys.", { reply_to_message_id: msg.message_id });
        }
        
        if (parts.length < 2) {
            return bot.sendMessage(chatId, 
                `❌ Format salah.\n\nGunakan: \`/ai <Pertanyaan Anda>\`\n\n*Contoh:* \`/ai Siapa nama penemu telepon?\``, 
                { parse_mode: 'Markdown', reply_to_message_id: msg.message_id });
        }

        const prompt = parts.slice(1).join(' '); // Ambil semua teks setelah /ai

        const loadingMsg = await bot.sendMessage(chatId, "💡 AI sedang berpikir, mohon tunggu...");
        
        try {
            // Inisialisasi Gemini dengan API Key yang dipilih
            const ai = new GoogleGenAI({ apiKey });
            
            // Panggil API Gemini
            const response = await ai.models.generateContent({
                model: 'gemini-2.5-flash', // Model yang cepat dan efisien
                contents: [{ role: "user", parts: [{ text: prompt }] }]
            });
            
            // Hapus pesan loading
            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
            
            // Mengganti karakter HTML entitas &nbsp; ke spasi
            let aiResponse = response.text.replace(/&nbsp;/g, ' '); 

            // Kirim Jawaban
            await bot.sendMessage(chatId, `🤖 **Jawaban AI:**\n\n${aiResponse}`, { 
                parse_mode: 'Markdown', 
                reply_to_message_id: msg.message_id 
            });

        } catch (e) {
            console.error("🔴 Error saat memanggil Gemini API:", e);
            await bot.deleteMessage(chatId, loadingMsg.message_id).catch(() => {});
            
            let errorMessage = "❌ Gagal mendapatkan jawaban dari AI. Mungkin API Key sudah limit, atau ada masalah jaringan.";
            
            if (e.message.includes('API key not valid')) {
                 errorMessage = "❌ Gagal: API Key Gemini tidak valid atau sudah dicabut. Segera ganti!";
            }

            bot.sendMessage(chatId, errorMessage, { reply_to_message_id: msg.message_id });
        }
    }
};