const axios = require('axios');

module.exports = {

    keyword: 'listtoken',

    handler: async (bot, msg, settings) => {

        const chatId = msg.chat.id;

        const userId = msg.from.id;

        // 1. KEAMANAN: Hanya Owner Pusat yang bisa akses

        if (!global.githubOwners || !global.githubOwners.includes(String(userId))) {

            return bot.sendMessage(chatId, "<blockquote><b>❌ AKSES DITOLAK</b>\nFitur ini khusus Owner Pusat.</blockquote>", { parse_mode: 'HTML' });

        }

        bot.sendMessage(chatId, "⏳ Mengambil daftar token...", { parse_mode: 'Markdown' });

        try {

            // 2. AMBIL DATA DARI GITHUB

            const { data } = await axios.get(settings.LICENSE_RAW);

            const listToken = data.tokens || [];

            if (listToken.length === 0) {

                return bot.sendMessage(chatId, "<blockquote>❌ DAFTAR KOSONG\nTidak ada token yang terdaftar.</blockquote>", { parse_mode: 'HTML' });

            }

            // 3. MENYUSUN PESAN DENGAN BALUTAN BLOCKQUOTE PER TOKEN

            let header = `📑 <b>DATABASE TOKEN AKTIF</b>\nTotal: ${listToken.length} Token\n\n`;

            

            let isiToken = listToken.map((token, index) => {

                // Menggunakan tag HTML <blockquote> untuk balutan kotak

                return `<blockquote><b>Token #${index + 1}</b>\n<code>${token}</code></blockquote>`;

            }).join('\n');

            let footer = `\n<i>Gunakan /deltoken [nomor] untuk menghapus.</i>`;

            // Kirim dengan parse_mode HTML agar tag <blockquote> terbaca

            return bot.sendMessage(chatId, header + isiToken + footer, { parse_mode: 'HTML' });

        } catch (error) {

            console.error("Error ListToken GitHub:", error.message);

            return bot.sendMessage(chatId, "❌ Gagal mengambil data dari GitHub.");

        }

    }

};