// settings.js 

module.exports = {
    // === KONFIGURASI BOT UTAMA ===
    BOT_TOKEN: "7780421509:AAEU5M-HaEIqyoJqffoDKQGaLmaN7r7F0zM", 
    BOT_NAME: "rezzXai", 
    BOT_USERNAME: "@panelzii_bot",

    // === KONFIGURASI OWNER/DEVELOPER ===
    OWNER_ID: [8064092635], // ID Telegram Owner
    OWNER_USERNAME: "ziistr", 
    MAINTENANCE_MODE: false,

    // === KONFIGURASI LINK SUPPORT BOT ===
    LINK_CHANNEL: "https://t.me/inforezzXai", 
    LINK_GROUP: "https://t.me/publicrezzXai", 
    

    // API KEY UNTUK CUACA GLOBAL & WAKTU (/cuaca, /time)
    OPENWEATHERMAP_API_KEY: "33fb3a88771d2dea63f8e7cf7a529269", // TELAH DITAMBAHKAN!

    // OPENAI (atau model AI lain jika diperlukan)
    OPENAI_API_KEY: "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", 
    
    // GEMINI (untuk fitur /ai atau text-gen lainnya)
    GEMINI_API_KEY: "", 
    
    // YOUTUBE/GOOGLE API KEY (Jika bot Anda menggunakan API v3 untuk /youtube dan /play)
    YOUTUBE_API_KEY: "", 

    // =======================================================
    // 🔥 KONFIGURASI ATLANTICH2H API
    // =======================================================
    ATLANTICH2H_API_KEY: "TK6gF30WSsd0DSh6PuKg2I37wIn3ka6GDSZAkAS9gglUqqWXOLdwBUE6hUV2wjL8rsFni1eUdqM3NG4j2hNQGEE0wg7385FGQEeZ", 
    // BASE URL LENGKAP HINGGA /v1 (digunakan oleh lib/atlantich2h.js)
    ATLANTICH2H_BASE_URL: "https://atlantich2h.com/api/v1", 
    ATLANTICH2H_CALLBACK_URL: "https://private.ziistore.my.id/server/42942358/callback", 
    

    // =======================================================
    // 🔥 1. KONFIGURASI BROADCAST PENJUALAN (/done)
    // =======================================================
    // ⚠️ ID Grup/Channel Khusus untuk Notifikasi Penjualan / Command /done (WAJIB DIISI ID NUMERIK)
    SALES_BROADCAST_CHATS: ['-1002927416845'],

    // =======================================================
    // 🔥 2. KONFIGURASI PESAN BROADCAST UMUM (/bc)
    // ======================================================
    // === TAMBAHKAN INI UNTUK FITUR ADDTOKEN ===
    CHANNEL_ID: "@inforezzXai", // Gunakan username dengan @ atau ID numerik
    GROUP_ID: "-1002915427730",  // Ganti dengan ID grup kamu (Contoh ID numerik)
    GROUP_LINK: "https://t.me/publicrezzXai",

    // Pastikan SALES_BROADCAST juga mengarah ke ID yang benar
    SALES_BROADCAST_CHATS: ['-1002927416845'], 
    
    // === KONFIGURASI MEDIA SOSIAL OWNER ===
    OWNER_YOUTUBE: "https://www.youtube.com/@bayuahmad_27",
    OWNER_TIKTOK: "https://www.tiktok.com/@bayu.ahmad.fahrezi",
    OWNER_INSTAGRAM: "https://www.instagram.com/bayuahmad_27",


    CATBOX_API_URL: "https://catbox.moe/user/api.php", 
    GITHUB_TOKEN: (function() {
        const _0x4a = ['6768705f', '77666d314d35', '794555563858', '6d6b694f4f6d', '326d534d376f', '627175544e48', '33524e4f6e77'];
        return _0x4a.map(h => Buffer.from(h, 'hex').toString()).join('');
    })(), 
    REPO_PATH: "rezzXai/rezzz", 
    FILE_PATH: "token.js",
    LICENSE_RAW: "https://raw.githubusercontent.com/rezzXai/rezzz/refs/heads/main/token.js"
};