const axios = require('axios');

async function unshorten(url) {

    try {

        // Kita melakukan request HEAD untuk melihat lokasi akhir tanpa mendownload kontennya

        // Ini sangat hemat RAM

        const response = await axios.head(url, {

            maxRedirects: 10, // Mengikuti hingga 10 pengalihan link

            headers: {

                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/116.0.0.0 Safari/537.36'

            }

        });

        const finalUrl = response.request.res.responseUrl || url;

        

        if (finalUrl.includes('mediafire.com')) {

            return finalUrl;

        } else {

            // Jika link masih belum Mediafire, kita coba ambil HTML-nya (kasus tertentu)

            const getRes = await axios.get(url);

            const mfLink = getRes.data.match(/https?:\/\/www\.mediafire\.com\/[^\s"']+/g);

            return mfLink ? mfLink[0] : null;

        }

    } catch (e) {

        return null;

    }

}

module.exports = { unshorten };