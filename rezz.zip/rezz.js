// =================================================================
// REZZ.JS - VERSI FINAL DENGAN HIDETAG PERSISTEN (BAGIAN 1 DARI 2)
// =================================================================
const TelegramBot = require('node-telegram-bot-api');
const fs = require('fs');
const path = require('path');
const express = require('express'); 
const bodyParser = require('body-parser'); 
const axios = require('axios'); // <--- DISISIPKAN
const { initializeStokDB } = require('./lib/stokdb'); 
const { initAdzanSystem } = require('./lib/adzan');
const { loadData, loadTransactions } = require('./dataHandler'); 
const { loadMemberData, saveMemberData } = require('./lib/memberdb'); // <--- IMPORT MEMBER DB
const { loadSewa, removeSewa } = require('./lib/sewadb'); // <--- IMPORT SEWA DB


// === LOAD PACKAGE.JSON ===
let packageJson;
try {
    packageJson = require('./package.json');
} catch (e) {
    console.error("🔴 GAGAL MEMUAT package.json: Pastikan file ada dan formatnya benar.");
    packageJson = { author: 'Author Tidak Ditemukan', version: 'v1.0' };
}
// ===================

// --- INISIALISASI DATABASE ---
initializeStokDB(); 



// --- LOAD SETTINGS ---
const settings = require('./setting'); 


// =======================================================
// 🔥 === FUNGSI GLOBAL HELPER (WAJIB DIDEFINISIKAN AWAL) ===
// =======================================================

/**
 * Cek apakah user adalah owner bot.
 */
global.isOwner = (userId) => {
    const ownerIds = Array.isArray(settings.OWNER_ID) 
        ? settings.OWNER_ID 
        : [settings.OWNER_ID].filter(id => id !== undefined); 
        
    const userIdClean = String(userId).trim();
    return ownerIds.map(String).includes(userIdClean); 
};

// =======================================================
// 🛡️ LOGIKA VERIFIKASI LISENSI GITHUB (SISIPAN)
// =======================================================
(async () => {
    try {
        const { data } = await axios.get(settings.LICENSE_RAW);
        if (!data.tokens || !data.tokens.includes(settings.BOT_TOKEN)) {
            console.log("\n" + "=".repeat(45));
            console.log("✘ ERROR: TOKEN TIDAK TERDAFTAR!");
            console.log("Bot tidak dapat diaktifkan. Hubungi @ziistr");
            console.log("=".repeat(45) + "\n");
            process.exit(1);
        }
        global.githubOwners = data.owners.map(String);
        console.log("✅ [SYSTEM] Detect Succes.");
    } catch (e) {
        console.error("✘ [SYSTEM] Gagal memverifikasi lisensi (Koneksi Error).");
        process.exit(1);
    }
})();
// =======================================================

/**
 * Cek apakah user adalah admin di grup.
 */
global.isAdmin = async (bot, chatId, userId) => {
    try {
        const member = await bot.getChatMember(chatId, userId);
        return member.status === 'administrator' || member.status === 'creator';
    } catch (e) {
        return false;
    }
};

/**
 * Reset timer atau fungsi pendukung untuk chatowner
 */
global.resetChatTimer = (bot, chatId, ownerId) => {
    // Fungsi bantuan agar case chatowner tidak error saat memanggil global ini
    console.log(`[CHAT] Timer direset untuk Owner ${ownerId} di chat ${chatId}`);
};

// -----------------------------------------------------------

// =======================================================
// 💾 === LOGIKA PERSISTENSI DATA (STOK & GROUP SETTINGS) ===
// =======================================================

// Data Stok (dari /addstok, /delstok)
global.stock = loadData(); 
if (!global.stock || typeof global.stock !== 'object') { 
    global.stock = {}; 
}
console.log(`[DATA] Memuat ${global.stock ? Object.keys(global.stock).length : 0} item stok dari disk.`); 

// Data Transaksi
global.unconfirmedTransactions = loadTransactions(); 
if (!global.unconfirmedTransactions || typeof global.unconfirmedTransactions !== 'object') {
     global.unconfirmedTransactions = {};
}
console.log(`[DATA] Memuat ${global.unconfirmedTransactions ? Object.keys(global.unconfirmedTransactions).length : 0} transaksi tertunda.`);


// === VARIABEL GLOBAL LAINNYA (TERMASUK UNTUK HIDETAG) ===
global.allChatIds = new Set(); 

// *** LOGIKA KHUSUS HIDETAG ***
// Memuat data member persisten (Set<username>) dari memberdb.js saat startup
global.allChatMembers = loadMemberData(); 
console.log(`[DATA] Memuat data member dari ${Object.keys(global.allChatMembers).length} grup.`);


global.antilinkStatus = {}; 
global.antitagStatus = {}; 
global.antispamStatus = {}; 
global.antifotoStatus = {}; 
global.antivideoStatus = {}; 
global.welcomeStatus = {};     
global.welcomeText = {};       
global.outText = {};           

// --- STATUS BADWORD ---
global.badwordStatus = {};     
global.badwordsList = {};      

// --- STATUS ANTI-SPAM TEKS ---
const SPAM_THRESHOLD_COUNT = 3;   
const SPAM_TIME_LIMIT_MS = 2000;  
global.spamDetector = {}; 
// =======================================================

// =================================================================
// 🕒 === LOGIKA AUTO-CHECK MASA SEWA (Sewa Grup) === 🕒
// =================================================================
// Bot akan mengecek database sewa setiap 1 menit (60.000 ms)
setInterval(async () => {
    const allSewa = loadSewa();
    const now = Date.now();

    for (const sewa of allSewa) {
        // Jika waktu sekarang sudah melewati waktu expired
        if (now > sewa.expired) {
            try {
                // Memberikan peringatan ke grup sebelum keluar
                await bot.sendMessage(sewa.chatId, "⚠️ ᴍᴀsᴀ sᴇᴡᴀ ʙᴏᴛ ᴛᴇʟᴀʜ ʙᴇʀᴀᴋʜɪʀ [ʜᴜʙᴜɴɢɪ ᴏᴡɴᴇʀ ᴜɴᴛᴜᴋ ᴘᴇʀᴘᴀɴᴊᴀɴɢ].");
                
                // Bot keluar dari grup
                await bot.leaveChat(sewa.chatId);
                
                // Hapus data dari database agar tidak dicek lagi
                removeSewa(sewa.chatId);
                
                console.log(`[SEWA] Bot otomatis keluar dari grup ${sewa.chatId} karena masa sewa berakhir.`);
            } catch (e) {
                // Jika bot gagal keluar (misal sudah di-kick duluan), tetap hapus dari database
                removeSewa(sewa.chatId);
                console.error(`[SEWA] Error saat mencoba keluar dari grup ${sewa.chatId}:`, e.message);
            }
        }
    }
}, 60000); 
// =================================================================

// PENTING: Set interval untuk menyimpan data member secara berkala (setiap 5 menit)
setInterval(() => {
    saveMemberData(global.allChatMembers);
    console.log('[DB] Data member berhasil disimpan ke disk.');
}, 300000); // 300000 ms = 5 menit


// Inisialisasi Bot
const token = settings.BOT_TOKEN;
const bot = new TelegramBot(token, { polling: true });
initAdzanSystem(bot);


// =======================================================
// 🔗 === LOGIKA EXPRESS SERVER (WEBHOOK TRIPAY) ===
const app = express();
const crypto = require('crypto');
const PORT = process.env.PORT || 3000;

app.use(bodyParser.json());

// Pencegahan error 'replace' jika URL kosong
const rawCallback = settings.TRIPAY_CALLBACK_URL || '';
const CALLBACK_PATH = rawCallback.includes('http') ? new URL(rawCallback).pathname : '/callback';

app.post(CALLBACK_PATH, (req, res) => {
    const callbackSignature = req.headers['x-callback-signature'];
    const json = JSON.stringify(req.body);
    const signature = crypto.createHmac('sha256', settings.TRIPAY_PRIVATE_KEY || '')
        .update(json)
        .digest('hex');

    if (callbackSignature !== signature) {
        return res.status(403).send('Invalid Signature');
    }

    const data = req.body;
    if (data.status === 'PAID') {
        const parts = data.merchant_ref ? data.merchant_ref.split('-') : [];
        const chatId = parts[1]; // Mengambil ID dari DEP-ID-WAKTU
        const nominal = data.amount_received;

        if (chatId) {
            bot.sendMessage(chatId, 
                `💰 DEPOSIT BERHASIL!\n\nSaldo Rp ${nominal.toLocaleString('id-ID')} telah ditambahkan ke akun Anda.\nTerima kasih telah melakukan pengisian saldo.`, 
                { parse_mode: 'HTML' }
            ).catch(e => console.error("Notif Gagal:", e.message));
            
            // Panggil fungsi update saldo database kamu di sini
            // example: db.users[chatId].balance += nominal;
        }
    }
    res.status(200).json({ success: true });
});

app.listen(PORT, () => {
    console.log(`[EXPRESS] Webhook Server Running on Port ${PORT}`);
});


// =======================================================
// === LOGIKA PEMUATAN CASE FLEKSIBEL DARI FOLDER 'cases' ===
// =======================================================
const casesDir = path.join(__dirname, 'cases');
const handlers = [];

function getCaseFiles(dir) {
    let files = [];
    if (!fs.existsSync(dir)) return files; 
    
    const items = fs.readdirSync(dir);

    for (const item of items) {
        const fullPath = path.join(dir, item);
        const stat = fs.statSync(fullPath);

        if (stat.isDirectory()) {
            files = files.concat(getCaseFiles(fullPath));
        } else if (stat.isFile() && item.endsWith('.js')) {
            files.push(fullPath);
        }
    }
    return files;
}

const caseFiles = getCaseFiles(casesDir);

for (const fullPath of caseFiles) {
    try {
        const handler = require(fullPath); 
        
        handler.filePath = fullPath;

        if (handler.keyword || handler.handler || handler.textHandler || handler.callbackHandler) {
            
            if (handler.keyword && handler.handler) {
                handlers.push(handler);
                const fileName = path.basename(fullPath);
                console.log(`[LOAD] Case /${handler.keyword} (${fileName}) berhasil dimuat.`);
            } else {
                handlers.push(handler); 
                const fileName = path.basename(fullPath);
                console.log(`[LOAD] Utility/Text Handler ${fileName} berhasil dimuat.`);
            }
        } else {
            const fileName = path.basename(fullPath);
            console.warn(`[WARN] Case ${fileName} dilewati: Tidak memiliki handler yang valid.`);
        }
    } catch (e) {
        const fileName = path.basename(fullPath);
        console.error(`🔴 Gagal memuat file ${fileName}:`, e.message); 
    }
}
// =======================================================
// =================================================================
// REZZ.JS - VERSI FINAL DENGAN HIDETAG PERSISTEN (BAGIAN 2 DARI 2)
// =================================================================

// === EVENT LISTENER: NEW MEMBER MASUK ===
bot.on('new_chat_members', async (msg) => {
    const chatId = msg.chat.id;
    
    if (global.welcomeStatus[chatId] && global.welcomeText[chatId]) {
        // ... Logika Welcome Anda
    }
    
    // Logika Hidetag: Simpan username member baru (Jika ada)
     const newMembers = msg.new_chat_members;
     for (const member of newMembers) {
        if (member.username && msg.chat.type !== 'private') {
            if (!global.allChatMembers[chatId]) {
                global.allChatMembers[chatId] = new Set();
            }
            // Simpan username ke Set di memori (lowercase)
            global.allChatMembers[chatId].add(member.username.toLowerCase()); 
        }
     }
});


// === EVENT LISTENER: MEMBER KELUAR ===
bot.on('left_chat_member', async (msg) => {
    const chatId = msg.chat.id;
    const member = msg.left_chat_member;
    
    if (global.welcomeStatus[chatId] && global.outText[chatId]) {
        // ... Logika Out Anda
    }
    
    // Logika Hidetag: Hapus username member yang keluar
    if (member.username && msg.chat.type !== 'private') {
        if (global.allChatMembers[chatId]) {
             // Hapus dari Set di memori
             global.allChatMembers[chatId].delete(member.username.toLowerCase()); 
        }
    }
});


// === HANDLER PESAN (Semua Pesan Masuk) ===
bot.on('message', async (msg) => { 
    const chatId = msg.chat.id;
    const userId = msg.from.id; 
    const text = msg.text ? msg.text.trim() : ''; 
    const caption = msg.caption ? msg.caption.trim() : '';
    const chatType = msg.chat.type;
    const isOwnerUser = global.isOwner(userId);
    const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID;

    // ✅ FIX: Definisikan isMediaMessage di awal agar bisa digunakan di seluruh fungsi
    const isMediaMessage = !!(msg.photo || msg.video || msg.document || msg.sticker || msg.audio || msg.voice || msg.animation);

    // 1. Definisikan Command di awal agar bisa digunakan untuk pengecekan bentrok
    let command = null;
    if (text.startsWith('/')) {
        command = text.split(/\s+/)[0].toLowerCase().replace('/', ''); 
    }

    // --- FUNGSI HELPER PENERUS MEDIA ---
    const forwardMedia = async (targetId, messageObj, extraCaption = "", replyToId = null) => {
        const opt = { caption: extraCaption, parse_mode: 'HTML', reply_to_message_id: replyToId };
        if (messageObj.photo) return bot.sendPhoto(targetId, messageObj.photo[messageObj.photo.length - 1].file_id, opt);
        if (messageObj.video) return bot.sendVideo(targetId, messageObj.video.file_id, opt);
        if (messageObj.document) return bot.sendDocument(targetId, messageObj.document.file_id, opt);
        if (messageObj.audio) return bot.sendAudio(targetId, messageObj.audio.file_id, opt);
        if (messageObj.voice) return bot.sendVoice(targetId, messageObj.voice.file_id, opt);
        if (messageObj.sticker) return bot.sendSticker(targetId, messageObj.sticker.file_id, { reply_to_message_id: replyToId });
        if (messageObj.animation) return bot.sendAnimation(targetId, messageObj.animation.file_id, opt);
    };

    // 🔥 LOGIKA INTERAKTIF (Hanya jalan jika BUKAN command agar tidak bentrok) 🔥
    if (!command) {
        // ✅ BUYPANEL
        const buypanelH = handlers.find(h => h.keyword === 'buypanel');
        if (buypanelH && buypanelH.onMessage) {
            const sessionPath = path.join(__dirname, './database/session_order.json');
            if (fs.existsSync(sessionPath)) {
                let sessions = JSON.parse(fs.readFileSync(sessionPath));
                if (sessions[userId] && await buypanelH.onMessage(bot, msg, settings)) return;
            }
        }
        
        // ==========================================================
// ✅ TAMBAHKAN INI (BUY VPS SESSION CHECKER)
// ==========================================================
const buyvpsH = handlers.find(h => h.keyword === 'buyvps');
if (buyvpsH && buyvpsH.onMessage) {
    const sessVpsPath = path.join(__dirname, './database/session_vps.json'); // Pastikan path ini benar
    if (fs.existsSync(sessVpsPath)) {
        let vpsSessions = JSON.parse(fs.readFileSync(sessVpsPath));
        if (vpsSessions[userId] && await buyvpsH.onMessage(bot, msg, settings)) return;
    }
}
// ==========================================================
// ==========================================================
// ✅ TAMBAHKAN INI: DEPOSIT, BUY LIMIT, & PREMIUM PHOTO HANDLER
// ==========================================================
if (msg.photo && global.depositSession && global.depositSession[userId]) {
    const session = global.depositSession[userId];
    
    // Jika sesi sedang menunggu bukti foto
    if (session.status === 'AWAITING_PROOF') {
        const photoId = msg.photo[msg.photo.length - 1].file_id;
        
        // Update data sesi sebelum dikirim ke owner
        session.status = 'WAITING_CONFIRMATION';
        session.username = msg.from.username || msg.from.first_name;

        // 1. Beri feedback ke User
        await bot.sendMessage(chatId, "<blockquote>✅ <b>BUKTI TERKIRIM</b>\nMohon tunggu owner melakukan konfirmasi pesanan Anda.</blockquote>", { parse_mode: 'HTML' });

        // 2. Siapkan Keterangan untuk Owner (Ditambahkan Logika Label Premium)
        let tipeLabel;
        if (session.type === 'BUY_PREMIUM') {
            const durasi = session.days === 999 ? "PERMANEN" : `${session.days} HARI`;
            tipeLabel = `💎 PREMIUM LIMIT (${durasi})`;
        } else if (session.type === 'BUY_LIMIT') {
            tipeLabel = `➕ BELI ${session.qty} LIMIT`;
        } else {
            tipeLabel = `💰 DEPOSIT SALDO`;
        }

        const captionOwner = `<blockquote>🔔 <b>KONFIRMASI PEMBAYARAN</b>\n\n` +
                             `👤 User: @${session.username}\n` +
                             `🆔 ID: <code>${userId}</code>\n` +
                             `📝 Tipe: <b>${tipeLabel}</b>\n` +
                             `💰 Nominal: <b>Rp ${session.nominal.toLocaleString()}</b></blockquote>`;

        const keyboard = {
            inline_keyboard: [[
                { text: "✅ ACC", callback_data: `acc_depo_${userId}` },
                { text: "❌ TOLAK", callback_data: `rej_depo_${userId}` }
            ]]
        };

        // 3. Kirim ke Owner
        return bot.sendPhoto(ownerId, photoId, { 
            caption: captionOwner, 
            reply_markup: keyboard, 
            parse_mode: 'HTML' 
        });
    }
}

        // ✅ BUY RESSELLER
        const buyRessH = handlers.find(h => h.keyword === 'buyresspanel');
        if (buyRessH && buyRessH.onMessage) {
            const sessRessPath = path.join(__dirname, './database/session_ress.json');
            if (fs.existsSync(sessRessPath)) {
                let ressSessions = JSON.parse(fs.readFileSync(sessRessPath));
                if (ressSessions[userId] && await buyRessH.onMessage(bot, msg, settings)) return;
            }
        }

        // ✅ BUY SUBDOMAIN
        const subdoH = handlers.find(h => h.keyword === 'buysubdo');
        if (subdoH && subdoH.onMessage) {
            const sessSubPath = path.join(__dirname, './database/session_subdo.json');
            if (fs.existsSync(sessSubPath)) {
                let subSessions = JSON.parse(fs.readFileSync(sessSubPath));
                if (subSessions[userId] && await subdoH.onMessage(bot, msg, settings)) return;
            }
        }

        // ✅ AUTO-VOUCHER (WAJIB sebelum slot agar tidak dianggap angka biasa)
        if (global.userState && global.userState[chatId]?.action === 'WAITING_VOUCHER') {
            const voucherCode = text.trim().toUpperCase();
            delete global.userState[chatId];
            const stokHandler = require('./cases/stok'); 
            const fakeMsg = { ...msg, text: `/cek_voucher ${voucherCode}` };
            return stokHandler.handler(bot, fakeMsg, settings);
        }

        // ✅ SLOT (Angka murni)
        if (text && !isNaN(text)) {
            const slotH = handlers.find(h => h.keyword === 'slot');
            if (slotH) {
                await slotH.handler(bot, msg, settings);
                return;
            }
        }
    }

    // --- LOGIKA PESAN NON-COMMAND LAINNYA ---
    if (msg.photo && !msg.reply_to_message && !command) {
        const konfirmasi = require('./cases/konfirmasi'); 
        return await konfirmasi.onPhoto(bot, msg, settings);
    }

    if (text.includes('wings configure') && text.includes('--token')) {
        const nodeH = handlers.find(h => h.keyword === 'instalnode');
        if (nodeH?.textHandler && await nodeH.textHandler(bot, msg, settings).catch(() => false)) return;
    }

    global.allChatIds.add(chatId); 
    
    // --- PROTEKSI BAN SYSTEM ---
    const { isBanned } = require('./lib/bandb'); 
    if (isBanned(userId) && chatType !== 'private') {
        try { return await bot.deleteMessage(chatId, msg.message_id); } catch (e) {}
    }
    
    let userIsAdmin = false; 
    if (chatType !== 'private') {
        try { 
            const member = await bot.getChatMember(chatId, userId);
            userIsAdmin = ['administrator', 'creator'].includes(member.status);
        } catch (e) {}
    }

    // === LOGIKA COMMAND HANDLER (STOK, DLL) ===
    if (command) {
        const currentHandler = handlers.find(h => 
            h.keyword === command || (h.keywordAliases && h.keywordAliases.includes(command))
        );
        if (currentHandler) {
            try { return await currentHandler.handler(bot, msg, settings); } catch (e) { console.error(e); }
        }
    }

    // Keyword 'stok' tanpa slash
    if (!command && text.toLowerCase() === 'stok') {
        const stokH = handlers.find(h => h.keyword === 'stok');
        if (stokH) return stokH.handler(bot, msg, settings);
    }

    // --- LOGIKA CHAT DUA ARAH (REPLY) ---
    if (msg.reply_to_message) {
        const replyText = msg.reply_to_message.text || msg.reply_to_message.caption || "";
        const matchId = replyText.match(/(?:ID|🆔):\s*(\d+)/i);
        const matchMsg = replyText.match(/(?:MSG ID|📑):\s*(\d+)/i);

        if (matchId && matchId[1]) {
            const targetId = matchId[1];
            const targetMsgId = matchMsg ? matchMsg[1] : null;

            if (isOwnerUser) {
                try {
                    const head = `📩 <b>PESAN DARI OWNER</b>\n`;
                    const btn = { inline_keyboard: [[{ text: '✍️ Balas ke Owner', callback_data: `reply_user:${ownerId}` }]] };
                    if (text) {
                        await bot.sendMessage(targetId, `${head}<pre>${text}</pre>`, { parse_mode: 'HTML', reply_to_message_id: targetMsgId, reply_markup: btn });
                    } else {
                        await forwardMedia(targetId, msg, `${head}${caption ? `<pre>${caption}</pre>` : ""}`, targetMsgId);
                    }
                    return bot.sendMessage(chatId, `✅ Terkirim ke ID: <code>${targetId}</code>`, { parse_mode: 'HTML' });
                } catch (e) { return bot.sendMessage(chatId, `❌ Gagal mengirim.`); }
            } else {
                const info = `💬 <b>BALASAN USER</b>\n🆔 ID: <code>${userId}</code>\n📑 MSG ID: <code>${msg.message_id}</code>\n👤 Nama: <b>${msg.from.first_name}</b>`;
                if (text) {
                    await bot.sendMessage(ownerId, `${info}\n\n<pre>${text}</pre>`, { parse_mode: 'HTML', reply_markup: { inline_keyboard: [[{ text: '📩 Balas User', callback_data: `reply_user:${userId}` }]] } });
                } else { await forwardMedia(ownerId, msg, `${info}\n${caption ? `\n<pre>${caption}</pre>` : ""}`); }
                return bot.sendMessage(chatId, `✅ Balasan terkirim ke Owner.`);
            }
        }
    }

    // --- TERUSKAN PESAN PRIVATE ---
    if (!command && chatType === 'private' && !isOwnerUser) {
        const info = `📩 <b>PESAN BARU</b>\n🆔 ID: <code>${userId}</code>\n📑 MSG ID: <code>${msg.message_id}</code>\n👤 Nama: <b>${msg.from.first_name}</b>`;
        if (text) {
            await bot.sendMessage(ownerId, `${info}\n\n<pre>${text}</pre>`, { 
                parse_mode: 'HTML',
                reply_markup: { inline_keyboard: [[{ text: '📩 Balas Chat', callback_data: `reply_user:${userId}` }]] }
            });
        } else { await forwardMedia(ownerId, msg, `${info}${caption ? `\n<pre>${caption}</pre>` : ""}`); }
        return bot.sendMessage(chatId, `⏳ Pesan kamu telah diteruskan ke Owner.`);
    }
    
    // --- FITUR GRUP (HIDETAG, BADWORD, ANTISPAM, DLL) ---
    if (chatType !== 'private') {
        if (msg.from.username) {
            if (!global.allChatMembers[chatId]) global.allChatMembers[chatId] = new Set();
            global.allChatMembers[chatId].add(msg.from.username.toLowerCase()); 
        }

        // Anti Badword
        if (global.badwordStatus[chatId] && text && !isOwnerUser && !userIsAdmin) {
            const words = text.toLowerCase().split(/\s+|[.,;!?"']/g).filter(w => w.length > 0); 
            if (words.some(word => global.badwordsList[chatId]?.has(word))) {
                try {
                    await bot.deleteMessage(chatId, msg.message_id);
                    const sm = await bot.sendMessage(chatId, `🗑️ <b>Anti Badword Aktif</b>`, { parse_mode: 'HTML' });
                    setTimeout(() => bot.deleteMessage(chatId, sm.message_id).catch(() => {}), 5000);
                    return;
                } catch (e) {}
            }
        }

        // Anti Media (MENGGUNAKAN isMediaMessage YANG SUDAH DI-FIX)
        if (isMediaMessage && global.antifotoStatus[chatId] && !isOwnerUser && !userIsAdmin) {
            try {
                await bot.deleteMessage(chatId, msg.message_id);
                const sm = await bot.sendMessage(chatId, `⚠️ <b>Anti Media Aktif</b>`, { parse_mode: 'HTML' });
                setTimeout(() => bot.deleteMessage(chatId, sm.message_id).catch(() => {}), 5000);
                return;
            } catch (e) {}
        }

        // Anti Spam
        if (global.antispamStatus[chatId] && text && !command) {
            const currentTime = Date.now();
            if (!global.spamDetector[chatId]) global.spamDetector[chatId] = {};
            if (!global.spamDetector[chatId][userId]) global.spamDetector[chatId][userId] = [];
            let history = global.spamDetector[chatId][userId].filter(item => currentTime - item.timestamp < 3000);
            history.push({ text: text.toLowerCase(), timestamp: currentTime });
            global.spamDetector[chatId][userId] = history;
            if (!isOwnerUser && !userIsAdmin && history.filter(item => item.text === text.toLowerCase()).length >= 3) {
                try {
                    await bot.banChatMember(chatId, userId, { until_date: Math.floor(Date.now() / 1000) + 60 });
                    return bot.sendMessage(chatId, `🗑️ <b>Anti-Spam Detect!</b>`, { parse_mode: 'HTML' });
                } catch (e) {}
            }
        }
    }
    
    // --- AUTO REPLY & INTEGRASI LAIN ---
    if (!command && text && !msg.reply_to_message) {
        const arPath = './autoreplay.json';
        if (fs.existsSync(arPath)) {
            const arDb = JSON.parse(fs.readFileSync(arPath, 'utf-8'));
            const checkAr = arDb.find(x => x.key === text.toLowerCase());
            if (checkAr) return bot.sendMessage(chatId, checkAr.res);
        }
    }
    
    if (msg.text || msg.caption) {
        for (const handler of handlers.filter(h => h.textHandler)) {
             if (await handler.textHandler(bot, msg, settings, handlers).catch(() => false)) return;
        }
    }
});
// === HANDLER INLINE CALLBACK (VERSI FULL: ANTI-BENTROK) ===
bot.on('callback_query', async (callbackQuery) => { 
    const msg = callbackQuery.message; 
    const data = callbackQuery.data; 
    const chatId = msg.chat.id;
    const userId = callbackQuery.from.id; // Diperlukan untuk identifikasi sesi

    // Menghilangkan status loading pada tombol di Telegram
    await bot.answerCallbackQuery(callbackQuery.id).catch(() => {});

    // --- 1. PRIORITAS: UNIVERSAL HANDLER (ACC DEPO, BATAL DEPO, KONFIRMASI PEMBELIAN) ---
    const cbHandlers = handlers.filter(h => h && h.callbackHandler); 
    for (const handler of cbHandlers) {
        try {
            const handled = await handler.callbackHandler(bot, callbackQuery, settings);
            if (handled === true) return; 
        } catch (e) {
            console.error(`🔴 Error di callbackHandler: ${e.message}`);
        }
    }
    
    // ==========================================================
    // === TAMBAHAN UNTUK LIMIT TOKEN (TIDAK MENGHAPUS LOGIKA LAMA) ===
    // ==========================================================
    if (data === "check_join_status") {
        const addTokenH = handlers.find(h => h.keyword === 'addtoken');
        if (addTokenH) {
            await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
            return await addTokenH.handler(bot, { ...msg, from: callbackQuery.from, text: '/addtoken' }, settings);
        }
    }

    if (data.startsWith("buy_limit_")) {
        const qty = parseInt(data.split('_')[2]);
        const harga = qty * 1000;
        if (!global.depositSession) global.depositSession = {};
        global.depositSession[userId] = {
            type: 'BUY_LIMIT',
            nominal: harga,
            qty: qty,
            status: 'AWAITING_PROOF',
            username: callbackQuery.from.username || callbackQuery.from.first_name
        };
        await bot.deleteMessage(chatId, msg.message_id).catch(() => {});
        return bot.sendPhoto(chatId, './qris.jpg', {
            caption: `<blockquote>💳 <b>BELI ${qty} LIMIT ADD TOKEN</b>\n\nTotal: <b>Rp ${harga.toLocaleString()}</b>\n\nSilakan transfer ke QRIS dan <b>KIRIM FOTO BUKTI</b>.</blockquote>`,
            parse_mode: 'HTML',
            reply_markup: { inline_keyboard: [[{ text: "❌ BATAL", callback_data: `cancel_depo_${userId}` }]] }
        });
    }
    // ==========================================================

    // --- 2. LOGIKA KHUSUS: STOK DETAIL & PROSES PEMBAYARAN QRIS ---
    const qrisStokHandler = handlers.find(h => h && h.keyword === 'stok_detail');
    const isQrisAction = data.startsWith('stok_detail_') || 
                         data.startsWith('pay_saldo_') || 
                         data.startsWith('process_qris_') || 
                         data.startsWith('cancel_order_');

    if (isQrisAction && qrisStokHandler) {
        try {
            return await qrisStokHandler.handler(bot, { ...msg, callbackQuery, from: callbackQuery.from, text: data }, settings);
        } catch (e) {
            console.error(`🔴 Error di qrisStokHandler: ${e.message}`);
            return;
        }
    }

    // --- 3. LOGIKA KHUSUS: MENU UTAMA STOK & DAFTAR KATEGORI ---
    const stokHandler = handlers.find(h => h && h.keyword === 'stok');
    const isStokAction = data === 'stok' || 
                         data === '/stok' || 
                         data === 'back_to_stok_menu' || 
                         data.startsWith('show_cat_') || 
                         data.startsWith('list_prod_');

    if (isStokAction && stokHandler) {
        try {
            return await stokHandler.handler(bot, { ...msg, callbackQuery, from: callbackQuery.from, text: data }, settings);
        } catch (e) {
            console.error(`🔴 Error di stokHandler: ${e.message}`);
            return;
        }
    }

    // --- 4. SISTEM REPLI CHAT OWNER (DUA ARAH) ---
    if (data.startsWith('reply_user:')) {
        const rawData = data.split(':')[1]; 
        const [targetId, userMsgId] = rawData.split('|');
        return bot.sendMessage(chatId, `🆔 **ID:** \`${targetId}\`\n📑 **MSG ID:** \`${userMsgId || ''}\`\n\nSilakan **balas/reply** pesan ini untuk mengirim pesan ke user.`, {
            parse_mode: 'Markdown',
            reply_markup: { force_reply: true }
        });
    }

    // --- 5. PENCARIAN HANDLER UMUM (Keyword & Aliases) ---
    let generalHandler = handlers.find(h => {
        if (!h || typeof h.keyword !== 'string') return false;
        return h.keyword === data || (Array.isArray(h.keywordAliases) && h.keywordAliases.includes(data));
    });

    if (generalHandler && generalHandler.handler) {
        try {
            return await generalHandler.handler(bot, { ...msg, callbackQuery: callbackQuery, from: callbackQuery.from, text: data }, settings);
        } catch (error) {
            console.error(`🔴 Gagal memproses general callback ${data}:`, error.message);
            return;
        }
    } 
    
    // --- 6. CATCH-ALL (TERAKHIR: JIKA TIDAK ADA YANG COCOK) ---
    const devMsg = '<blockquote>⚠️ <b>MENU TIDAK DITEMUKAN</b>\nMenu ini masih dalam pengembangan atau sesi telah berakhir.</blockquote>';
    try {
        await bot.editMessageCaption(devMsg, { 
             chat_id: chatId,
             message_id: msg.message_id,
             parse_mode: 'HTML'
        }).catch(() => bot.sendMessage(chatId, devMsg, { parse_mode: 'HTML' }));
    } catch(e) {}
});


// === INISIALISASI DAN PESAN SAMBUTAN AWAL ===
bot.getMe().then(me => {
    const botUsername = `@${me.username}`;
    const ownerId = Array.isArray(settings.OWNER_ID) ? settings.OWNER_ID[0] : settings.OWNER_ID; 
    
    const authorName = packageJson.author || 'Author Tidak Ditemukan';
    const channelLink = settings.LINK_CHANNEL || '(Belum diset)';
    const groupLink = settings.LINK_GROUP || '(Belum diset)';

    console.log("=====================================");
    console.log("🚀 Rezz Bot telah berjalan...");
    console.log(`[EXPRESS] Webhook Server berjalan di port ${PORT}. Pastikan URL ${settings.ATLANTICH2H_CALLBACK_URL} mengarah ke port ini.`);
    console.log(`🤖 Bot Username: ${botUsername}`);
    console.log(`👤 Author: ${authorName}`);
    console.log(`📜 Total Handler Dimuat: ${handlers.length}`);
    console.log("=====================================");

    if (ownerId) {
        const ownerInfo = `[${authorName}](tg://user?id=${ownerId}) 👑`; 
        const channelLinkMarkdown = `[Channel](${channelLink}) 📢`;
        const groupLinkMarkdown = `[Group Support](${groupLink}) 👥`;
        
        const welcomeMessage = `
*🤖 Bot Berhasil Aktif! 🚀*
        
*Author:* ${ownerInfo} 
*Channel:* ${channelLinkMarkdown}
*Group:* ${groupLinkMarkdown}
        
*Terima kasih telah menggunakan Script RezzXAI v${packageJson.version || '1.0'}!* 🙏
        `;
        
        bot.sendMessage(ownerId, welcomeMessage, { parse_mode: 'Markdown' })
            .then(() => {
                console.log(`[INFO] Pesan sambutan berhasil dikirim ke Owner (${ownerId}).`);
            })
            .catch(error => {
                console.error(`[ERROR] Gagal mengirim pesan sambutan ke Owner (${ownerId}): ${error.message}`);
            });
    }

}).catch(e => {
    console.error(`🔴 GAGAL START BOT: ${e.message}`);
    console.log("Pastikan BOT_TOKEN di settings.js sudah benar.");
});

module.exports = bot;