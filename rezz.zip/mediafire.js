const axios = require('axios');

const cheerio = require('cheerio');

async function mediafireDl(url) {

    try {

        const res = await axios.get(url, {

            headers: {

                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/110.0.0.0 Safari/537.36'

            }

        });

        const $ = cheerio.load(res.data);

        

        // Mencari link download di tombol utama

        const link = $('#downloadButton').attr('href');

        const name = $('.dl-info .promo_caption').text() || $('div.filename').text() || 'file_mediafire';

        const size = $('.dl-info .promo_caption span').text() || $('.dl-file-info span').text() || 'Unknown';

        if (!link) throw new Error("Gagal mengekstrak direct link. Pastikan link tidak mati atau bermasalah.");

        return { 

            name: name.trim(), 

            size: size.trim(), 

            link 

        };

    } catch (e) {

        throw new Error("Link Mediafire tidak valid atau tidak dapat diakses.");

    }

}

module.exports = { mediafireDl };