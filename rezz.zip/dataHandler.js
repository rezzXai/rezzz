// dataHandler.js (ROOT FOLDER - FIXED TYPE ERROR)

const fs = require('fs');
const path = require('path');

// File untuk data stok
const DATA_FILE = path.join(__dirname, 'stock.json'); 
// File untuk data transaksi
const TRX_FILE = path.join(__dirname, 'transactions.json'); 

/**
 * Memuat data stok dari disk.
 * @returns {object} Objek stok atau objek kosong jika gagal.
 */
function loadData() {
    try {
        if (fs.existsSync(DATA_FILE)) {
            const data = fs.readFileSync(DATA_FILE, 'utf8');
            const trimmedData = data.trim();
            // PENTING: Jika file kosong, kembalikan objek kosong {}
            if (!trimmedData || trimmedData === 'null' || trimmedData === 'undefined') {
                 return {}; 
            }
            return JSON.parse(trimmedData);
        }
        return {}; 
    } catch (error) {
        console.error("Gagal memuat data stok dari disk:", error.message);
        return {}; // SELALU kembalikan objek kosong jika gagal
    }
}

function saveData(data) {
    try {
        global.stock = data; 
        const jsonString = JSON.stringify(data, null, 4); 
        fs.writeFileSync(DATA_FILE, jsonString, 'utf8');
    } catch (error) {
        console.error("Gagal menyimpan data stok ke disk:", error.message);
    }
}


function loadTransactions() {
    try {
        if (fs.existsSync(TRX_FILE)) {
            const data = fs.readFileSync(TRX_FILE, 'utf8');
            const trimmedData = data.trim();
            // PENTING: Jika file kosong, kembalikan objek kosong {}
            if (!trimmedData || trimmedData === 'null' || trimmedData === 'undefined') {
                 return {}; 
            }
            return JSON.parse(trimmedData);
        }
        return {};
    } catch (error) {
        console.error("Gagal memuat data transaksi:", error.message);
        return {};
    }
}

function saveTransactions(data) {
    try {
        global.unconfirmedTransactions = data; 
        const jsonString = JSON.stringify(data, null, 4); 
        fs.writeFileSync(TRX_FILE, jsonString, 'utf8');
    } catch (error) {
        console.error("Gagal menyimpan data transaksi ke disk:", error.message);
    }
}


module.exports = {
    loadData,
    saveData,
    loadTransactions,
    saveTransactions,
};