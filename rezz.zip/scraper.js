const Axios = require('axios');

async function tiktokdownload(url) {

    // --- SERVER 1: Tiklydown ---

    try {

        const res = await Axios.get(`https://api.tiklydown.eu.org/api/download?url=${encodeURIComponent(url)}`);

        if (res.data && res.data.video) {

            return {

                status: true,

                nowm: res.data.video.noWatermark,

                audio: res.data.music.play_url,

                title: res.data.title

            };

        }

    } catch (e) { console.log("Server 1 Gagal..."); }

    // --- SERVER 2: Tikhub ---

    try {

        const res = await Axios.get(`https://api.tikhub.io/download?url=${encodeURIComponent(url)}`);

        if (res.data && res.data.data) {

            return {

                status: true,

                nowm: res.data.data.video_url || res.data.data.no_watermark_url,

                audio: res.data.data.music_url,

                title: "TikTok Video"

            };

        }

    } catch (e) { console.log("Server 2 Gagal..."); }

    // --- SERVER 3: TikWM (Perbaikan Link) ---

    try {

        const res = await Axios.get(`https://www.tikwm.com/api/?url=${encodeURIComponent(url)}`);

        if (res.data && res.data.data) {

            const data = res.data.data;

            return {

                status: true,

                // Pastikan link tidak dobel https

                nowm: data.play.startsWith('http') ? data.play : `https://www.tikwm.com${data.play}`,

                audio: data.music.startsWith('http') ? data.music : `https://www.tikwm.com${data.music}`,

                title: data.title

            };

        }

    } catch (e) { console.log("Server 3 Gagal..."); }

    return { status: false };

}

// Menghindari error 'ssstik is not defined' dengan mengarahkan semua ke tiktokdownload

module.exports = {

    tiktokdownload,

    ssstik: tiktokdownload,

    musicallydown: tiktokdownload,

    keeptiktok: tiktokdownload,

    tiklydown: tiktokdownload,

    dlpanda: tiktokdownload

};